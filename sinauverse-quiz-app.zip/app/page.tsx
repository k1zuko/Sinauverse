import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardTitle } from "@/components/ui/card"
import { Sparkles, Users, Brain, Trophy } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl md:text-6xl dark:text-gray-50">
          Welcome to <span className="text-primary">Sinauverse</span>
        </h1>
        <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-5 sm:text-2xl dark:text-gray-400">
          Your ultimate platform for interactive quizzes and engaging learning experiences.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Button asChild size="lg">
            <Link href="/dashboard">Get Started</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/dashboard/public-quizzes">Explore Quizzes</Link>
          </Button>
        </div>
      </div>

      <div className="mt-16 w-full max-w-6xl">
        <h2 className="text-3xl font-bold text-center mb-10 text-gray-900 dark:text-gray-50">Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <Card className="flex flex-col items-center text-center p-6">
            <Sparkles className="h-12 w-12 text-primary mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Create Quizzes</CardTitle>
            <CardDescription>Design your own quizzes with multiple questions and answers.</CardDescription>
          </Card>
          <Card className="flex flex-col items-center text-center p-6">
            <Users className="h-12 w-12 text-primary mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Host Multiplayer</CardTitle>
            <CardDescription>Host live quiz sessions for friends or students.</CardDescription>
          </Card>
          <Card className="flex flex-col items-center text-center p-6">
            <Brain className="h-12 w-12 text-primary mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Solo Practice</CardTitle>
            <CardDescription>Practice alone to master your knowledge.</CardDescription>
          </Card>
          <Card className="flex flex-col items-center text-center p-6">
            <Trophy className="h-12 w-12 text-primary mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Track Progress</CardTitle>
            <CardDescription>View detailed analytics of your quiz performance.</CardDescription>
          </Card>
        </div>
      </div>
    </div>
  )
}
