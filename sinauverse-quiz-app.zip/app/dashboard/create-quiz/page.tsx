"use client"
import { useState, useEffect } from "react"
import Link from "next/link"

import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Sparkles } from "lucide-react" // Added Sparkles icon
import { QuestionAnswerForm } from "@/components/question-answer-form"
import { createQuiz, getQuizForEdit, updateQuiz } from "@/actions/quiz"
import { getQuizCategories } from "@/actions/category"
import { toast } from "@/hooks/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { generateQuizQuestions } from "@/actions/ai-quiz" // Import AI action
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog" // Import Dialog components

interface Answer {
  id?: string // Optional for new answers
  answer_text: string
  answer_image_url: string | null
  is_correct: boolean
}

interface Question {
  id?: string // Optional for new questions
  question_text: string
  question_image_url: string | null
  answers: Answer[]
}

interface Category {
  id: string
  name: string
}

export default function CreateQuizPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const quizId = searchParams.get("quizId")

  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [totalTimeMinutes, setTotalTimeMinutes] = useState(10)
  const [category, setCategory] = useState("") // Stores category name
  const [isPublic, setIsPublic] = useState(false)
  const [questions, setQuestions] = useState<Question[]>([])
  const [loading, setLoading] = useState(true) // Start loading for initial fetch
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [availableCategories, setAvailableCategories] = useState<Category[]>([])

  // AI Generation states
  const [aiTopic, setAiTopic] = useState("")
  const [isGeneratingAi, setIsGeneratingAi] = useState(false)
  const [aiGeneratedQuestions, setAiGeneratedQuestions] = useState<Question[]>([])
  const [isAiDialogOpen, setIsAiDialogOpen] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      // Fetch categories first
      const categoriesResult = await getQuizCategories()
      if (categoriesResult.success) {
        setAvailableCategories(categoriesResult.categories)
      } else {
        toast({
          title: "Error",
          description: categoriesResult.message,
          variant: "destructive",
        })
      }

      // Then fetch quiz data if editing
      if (quizId) {
        const result = await getQuizForEdit(quizId)
        if (result.success && result.quiz) {
          setTitle(result.quiz.title)
          setDescription(result.quiz.description || "")
          setTotalTimeMinutes(result.quiz.total_time_minutes || 10)
          setCategory(result.quiz.category || "") // Set category name
          setIsPublic(result.quiz.is_public || false)
          setQuestions(
            result.quiz.questions.map((q: any) => ({
              id: q.id,
              question_text: q.question_text,
              question_image_url: q.question_image_url,
              answers: q.answers.map((a: any) => ({
                id: a.id,
                answer_text: a.answer_text,
                answer_image_url: a.answer_image_url,
                is_correct: a.is_correct,
              })),
            })),
          )
        } else {
          toast({
            title: "Error",
            description: result.message || "Failed to load quiz for editing.",
            variant: "destructive",
          })
          router.push("/dashboard/my-quizzes") // Redirect if quiz not found or error
        }
      }
      setLoading(false)
    }
    fetchData()
  }, [quizId, router])

  const addQuestion = () => {
    const newQuestion: Question = {
      id: crypto.randomUUID(), // Use UUID for client-side keying, will be ignored on insert
      question_text: "",
      question_image_url: null,
      answers: [
        { id: crypto.randomUUID(), answer_text: "", answer_image_url: null, is_correct: false },
        { id: crypto.randomUUID(), answer_text: "", answer_image_url: null, is_correct: false },
      ],
    }
    setQuestions([...questions, newQuestion])
  }

  const updateQuestion = (updatedQuestion: Question) => {
    setQuestions(questions.map((q) => (q.id === updatedQuestion.id ? updatedQuestion : q)))
  }

  const removeQuestion = (questionId: string) => {
    setQuestions(questions.filter((q) => q.id !== questionId))
  }

  const handleGenerateAiQuestions = async () => {
    setIsGeneratingAi(true)
    setAiGeneratedQuestions([]) // Clear previous results
    const result = await generateQuizQuestions(aiTopic)
    if (result.success && result.questions) {
      // Add client-side UUIDs to generated questions and answers
      const formattedQuestions = result.questions.map((q) => ({
        id: crypto.randomUUID(),
        question_text: q.question_text,
        question_image_url: null, // AI doesn't generate images
        answers: q.answers.map((a) => ({
          id: crypto.randomUUID(),
          answer_text: a.answer_text,
          answer_image_url: null, // AI doesn't generate images
          is_correct: a.is_correct,
        })),
      }))
      setAiGeneratedQuestions(formattedQuestions)
      toast({
        title: "AI Generation Success",
        description: result.message,
      })
    } else {
      toast({
        title: "AI Generation Failed",
        description: result.message,
        variant: "destructive",
      })
    }
    setIsGeneratingAi(false)
  }

  const addAiQuestionsToQuiz = () => {
    setQuestions((prevQuestions) => [...prevQuestions, ...aiGeneratedQuestions])
    setAiGeneratedQuestions([]) // Clear generated questions after adding
    setIsAiDialogOpen(false) // Close the dialog
    toast({
      title: "Questions Added",
      description: `${aiGeneratedQuestions.length} AI-generated questions added to your quiz.`,
    })
  }

  const handleSubmit = async (status: "draft" | "published") => {
    setIsSubmitting(true)

    // Basic validation
    if (!title.trim() || !description.trim() || questions.length === 0 || !category) {
      toast({
        title: "Validation Error",
        description: "Please fill in quiz title, description, category, and add at least one question.",
        variant: "destructive",
      })
      setIsSubmitting(false)
      return
    }

    // Validate questions and answers
    for (const q of questions) {
      if (!q.question_text.trim()) {
        toast({
          title: "Validation Error",
          description: "All questions must have text.",
          variant: "destructive",
        })
        setIsSubmitting(false)
        return
      }
      if (q.answers.length < 2) {
        toast({
          title: "Validation Error",
          description: "Each question must have at least two answers.",
          variant: "destructive",
        })
        setIsSubmitting(false)
        return
      }
      if (!q.answers.some((a) => a.is_correct)) {
        toast({
          title: "Validation Error",
          description: "Each question must have at least one correct answer.",
          variant: "destructive",
        })
        setIsSubmitting(false)
        return
      }
      for (const a of q.answers) {
        if (!a.answer_text.trim()) {
          toast({
            title: "Validation Error",
            description: "All answers must have text.",
            variant: "destructive",
          })
          setIsSubmitting(false)
          return
        }
      }
    }

    const quizData = {
      title,
      description,
      total_time_minutes: totalTimeMinutes,
      category: category, // Use the selected category name
      is_public: isPublic,
      status,
      questions: questions.map((q) => ({
        id: q.id, // Pass ID for updates, null for new
        question_text: q.question_text,
        question_image_url: q.question_image_url,
        answers: q.answers.map((a) => ({
          id: a.id, // Pass ID for updates, null for new
          answer_text: a.answer_text,
          answer_image_url: a.answer_image_url,
          is_correct: a.is_correct,
        })),
      })),
    } as any // Cast to any to allow optional IDs for new items

    let result
    if (quizId) {
      result = await updateQuiz(quizId, quizData)
    } else {
      result = await createQuiz(quizData)
    }

    if (result.success) {
      toast({
        title: "Success",
        description: result.message,
      })
      router.push("/dashboard/my-quizzes") // Redirect to my quizzes page
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setIsSubmitting(false)
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/3 mb-6" />
        <Card className="mb-6">
          <CardHeader>
            <Skeleton className="h-6 w-1/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent className="grid gap-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-20 w-full" />
            <div className="grid grid-cols-2 gap-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
            <Skeleton className="h-8 w-full" />
          </CardContent>
        </Card>
        <Skeleton className="h-8 w-1/4 mb-4" />
        <Skeleton className="h-48 w-full mb-6" />
        <Skeleton className="h-10 w-full mb-6" />
        <div className="flex justify-end gap-4">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-10 w-32" />
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">{quizId ? "Edit Quiz" : "Create New Quiz"}</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Quiz Details</CardTitle>
          <CardDescription>Provide general information about your quiz.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="title">Quiz Title</Label>
            <Input
              id="title"
              placeholder="e.g., Introduction to React"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="A brief overview of the quiz content."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="total-time">Total Quiz Time (minutes)</Label>
              <Input
                id="total-time"
                type="number"
                min="1"
                value={totalTimeMinutes}
                onChange={(e) => setTotalTimeMinutes(Number.parseInt(e.target.value))}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="category">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {availableCategories.length === 0 ? (
                    <SelectItem value="no-categories" disabled>
                      No categories available. Create one in Settings.
                    </SelectItem>
                  ) : (
                    availableCategories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.name}>
                        {cat.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              {availableCategories.length === 0 && (
                <p className="text-sm text-muted-foreground mt-2">
                  No categories found. Go to{" "}
                  <Link href="/dashboard/settings/categories" className="underline">
                    Settings &gt; Categories
                  </Link>{" "}
                  to add some.
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center justify-between space-x-2">
            <Label htmlFor="public-quiz">Public Quiz</Label>
            <Switch
              id="public-quiz"
              checked={isPublic}
              onCheckedChange={setIsPublic}
              aria-label="Toggle quiz visibility to public"
            />
            <span className="text-sm text-muted-foreground">
              {isPublic ? "Visible to all users" : "Private (only accessible via code)"}
            </span>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold">Questions</h2>
        <Dialog open={isAiDialogOpen} onOpenChange={setIsAiDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="bg-transparent">
              <Sparkles className="mr-2 h-4 w-4" /> Generate with AI
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Generate Questions with AI</DialogTitle>
              <DialogDescription>
                Enter a topic, and AI will generate multiple-choice questions for your quiz.
                <br />
                <span className="text-red-500">Note: AI generation uses external API calls and may incur costs.</span>
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="ai-topic">Topic</Label>
                <Textarea
                  id="ai-topic"
                  placeholder="e.g., Basic JavaScript concepts, History of the Internet, World Geography"
                  value={aiTopic}
                  onChange={(e) => setAiTopic(e.target.value)}
                  rows={3}
                />
              </div>
              <Button onClick={handleGenerateAiQuestions} disabled={isGeneratingAi || !aiTopic.trim()}>
                {isGeneratingAi ? "Generating..." : "Generate Questions"}
              </Button>

              {aiGeneratedQuestions.length > 0 && (
                <div className="mt-4 max-h-60 overflow-y-auto border rounded-md p-2">
                  <h3 className="font-semibold mb-2">Generated Questions:</h3>
                  {aiGeneratedQuestions.map((q, index) => (
                    <div key={q.id} className="mb-3 p-2 border-b last:border-b-0">
                      <p className="font-medium">
                        {index + 1}. {q.question_text}
                      </p>
                      <ul className="list-disc list-inside text-sm text-muted-foreground">
                        {q.answers.map((a, aIndex) => (
                          <li key={aIndex} className={a.is_correct ? "text-green-600" : ""}>
                            {a.answer_text} {a.is_correct && "(Correct)"}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button onClick={addAiQuestionsToQuiz} disabled={aiGeneratedQuestions.length === 0 || isGeneratingAi}>
                Add {aiGeneratedQuestions.length} Questions to Quiz
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {questions.length === 0 && (
        <p className="text-muted-foreground mb-4">
          No questions added yet. Click "Add Question" or "Generate with AI" to start.
        </p>
      )}

      {questions.map((q) => (
        <QuestionAnswerForm key={q.id} question={q} onUpdate={updateQuestion} onRemove={() => removeQuestion(q.id)} />
      ))}

      <Button type="button" variant="outline" onClick={addQuestion} className="w-full mb-6 bg-transparent">
        <Plus className="mr-2 h-4 w-4" /> Add Question Manually
      </Button>

      <div className="flex justify-end gap-4">
        <Button variant="secondary" onClick={() => handleSubmit("draft")} disabled={isSubmitting}>
          {isSubmitting ? "Saving Draft..." : "Save Draft"}
        </Button>
        <Button onClick={() => handleSubmit("published")} disabled={isSubmitting}>
          {isSubmitting ? "Publishing..." : "Publish Quiz"}
        </Button>
      </div>
    </div>
  )
}
