"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { joinQuizSession } from "@/actions/quiz"
import { toast } from "@/hooks/use-toast"

export default function JoinQuizPage() {
  const [quizCode, setQuizCode] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleJoinQuiz = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    if (!quizCode.trim()) {
      toast({
        title: "Input Error",
        description: "Please enter a quiz code.",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    const result = await joinQuizSession(quizCode.trim())

    if (result.success) {
      toast({
        title: "Success",
        description: result.message,
      })
      router.push(`/dashboard/join-quiz/${result.sessionCode}/waiting-room`)
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setLoading(false)
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">Join a Quiz</CardTitle>
          <CardDescription>Enter the quiz code provided by the host to join a session.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleJoinQuiz} className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="quiz-code">Quiz Code</Label>
              <Input
                id="quiz-code"
                placeholder="e.g., ABC123"
                required
                value={quizCode}
                onChange={(e) => setQuizCode(e.target.value.toUpperCase())}
                maxLength={6}
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Joining..." : "Join Quiz"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
