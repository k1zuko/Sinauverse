"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Trophy, Home, Share2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { ShareButton } from "@/components/share-button"
import { Skeleton } from "@/components/ui/skeleton"
import { Loader2 } from "lucide-react" // Import Loader2

interface Participant {
  id: string
  user_id: string
  username: string
  full_name: string | null
  avatar_url: string | null
  score: number
  finished_quiz: boolean
}

interface QuizSession {
  id: string
  quiz_id: string
  host_id: string
  session_code: string
  status: "waiting" | "in_progress" | "finished" | "cancelled"
  quizzes: {
    title: string
  }
  quiz_participants: Participant[]
}

export default function LeaderboardPage() {
  const params = useParams()
  const quizCode = params.quizCode as string
  const router = useRouter()
  const supabase = createBrowserClient()

  const [session, setSession] = useState<QuizSession | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchLeaderboard = async () => {
      setLoading(true)
      const { data, error: sessionError } = await supabase
        .from("quiz_sessions")
        .select(
          `
          id,
          quiz_id,
          host_id,
          session_code,
          status,
          quizzes(title),
          quiz_participants(id, user_id, username, full_name, avatar_url, score, finished_quiz)
        `,
        )
        .eq("session_code", quizCode)
        .single()

      if (sessionError || !data || !data.quizzes) {
        console.error("Error fetching session for leaderboard:", sessionError?.message)
        setError("Quiz session not found or invalid code.")
        toast({
          title: "Error",
          description: "Quiz session not found or invalid code.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      // Sort participants by score in descending order
      const sortedParticipants = data.quiz_participants.sort((a, b) => b.score - a.score)
      setSession({ ...data, quiz_participants: sortedParticipants } as QuizSession)
      setLoading(false)
    }

    fetchLeaderboard()

    // Real-time subscription for session status (in case host force-stops or quiz finishes naturally)
    const channel = supabase
      .channel(`leaderboard_updates:${quizCode}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "quiz_sessions",
          filter: `session_code=eq.${quizCode}`,
        },
        (payload) => {
          const newStatus = (payload.new as any).status
          if (newStatus === "finished" || newStatus === "cancelled") {
            // Re-fetch to ensure final scores are displayed
            fetchLeaderboard()
          }
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*", // Listen for INSERT, UPDATE, DELETE on participants
          schema: "public",
          table: "quiz_participants",
          filter: `session_id=eq.${session?.id}`, // Filter by session ID once available
        },
        (payload) => {
          // Re-fetch participants to get the latest list and scores
          fetchLeaderboard()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [quizCode, router, supabase, session?.id])

  if (loading) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <Skeleton className="h-8 w-3/4 mx-auto mb-2" />
            <Skeleton className="h-5 w-1/2 mx-auto" />
          </CardHeader>
          <CardContent className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
            <Skeleton className="h-48 w-full mb-4" />
            <div className="flex justify-center gap-4">
              <Skeleton className="h-10 w-32" />
              <Skeleton className="h-10 w-32" />
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CardTitle className="text-2xl text-red-500">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error}</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const shareUrl = typeof window !== "undefined" ? `${window.location.origin}/dashboard/join-quiz?code=${quizCode}` : ""

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-8">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <Trophy className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
          <CardTitle className="text-3xl">Leaderboard: {session?.quizzes?.title}</CardTitle>
          <CardDescription className="text-lg font-semibold">
            Quiz Code: <span className="font-bold text-primary">{quizCode}</span>
          </CardDescription>
          <CardDescription className="text-md capitalize">Status: {session?.status.replace("_", " ")}</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]">Rank</TableHead>
                <TableHead>Participant</TableHead>
                <TableHead className="text-right">Score</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {session?.quiz_participants.map((participant, index) => (
                <TableRow key={participant.id} className={index === 0 ? "bg-yellow-100 dark:bg-yellow-900" : ""}>
                  <TableCell className="font-medium text-lg">{index + 1}</TableCell>
                  <TableCell className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={participant.avatar_url || "/placeholder-user.jpg"} />
                      <AvatarFallback>{participant.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{participant.full_name || participant.username}</span>
                  </TableCell>
                  <TableCell className="text-right text-lg font-bold">{participant.score}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
            <Button onClick={() => router.push("/dashboard")} className="w-full sm:w-auto">
              <Home className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
            <ShareButton
              title={`Join my quiz: ${session?.quizzes?.title}`}
              text={`I just finished a quiz on Sinauverse! Join the fun with code: ${quizCode}`}
              url={shareUrl}
            >
              <Share2 className="mr-2 h-4 w-4" /> Share Quiz
            </ShareButton>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
