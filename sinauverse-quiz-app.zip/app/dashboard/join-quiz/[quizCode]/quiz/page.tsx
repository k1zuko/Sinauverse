"use client"

import { Skeleton } from "@/components/ui/skeleton"

import { useEffect, useState, useCallback } from "react"
import { useParams, useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { submitParticipantAnswer, finishQuizForParticipant } from "@/actions/quiz"
import Image from "next/image"
import { Loader2 } from "lucide-react"

interface Question {
  id: string
  question_text: string
  question_image_url: string | null
  answers: Array<{
    id: string
    answer_text: string
    answer_image_url: string | null
    is_correct: boolean
  }>
}

interface QuizSession {
  id: string
  quiz_id: string
  host_id: string
  session_code: string
  status: "waiting" | "in_progress" | "finished" | "cancelled"
  current_question_index: number
  started_at: string
  quizzes: {
    title: string
    total_time_minutes: number
    questions: Question[]
  }
}

export default function ParticipantQuizPage() {
  const params = useParams()
  const quizCode = params.quizCode as string
  const router = useRouter()
  const supabase = createBrowserClient()

  const [session, setSession] = useState<QuizSession | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [submittingAnswer, setSubmittingAnswer] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(0) // in seconds
  const [quizStartedTime, setQuizStartedTime] = useState<number | null>(null)
  const [questionStartTime, setQuestionStartTime] = useState<number | null>(null)

  const fetchSession = useCallback(async () => {
    setLoading(true)
    const { data, error } = await supabase
      .from("quiz_sessions")
      .select(
        `
        id,
        quiz_id,
        host_id,
        session_code,
        status,
        current_question_index,
        started_at,
        quizzes(
          title,
          total_time_minutes,
          questions(
            id,
            question_text,
            question_image_url,
            answers(
              id,
              answer_text,
              answer_image_url,
              is_correct
            )
          )
        )
      `,
      )
      .eq("session_code", quizCode)
      .single()

    if (error || !data || !data.quizzes) {
      console.error("Error fetching session:", error?.message)
      toast({
        title: "Error",
        description: "Quiz session not found or an error occurred.",
        variant: "destructive",
      })
      router.push("/dashboard/join-quiz")
      return
    }

    const fetchedSession = data as QuizSession
    setSession(fetchedSession)
    setCurrentQuestionIndex(fetchedSession.current_question_index)

    if (fetchedSession.status === "in_progress") {
      const totalQuizTimeMs = fetchedSession.quizzes.total_time_minutes * 60 * 1000
      const startedAtMs = new Date(fetchedSession.started_at).getTime()
      setQuizStartedTime(startedAtMs)
      setQuestionStartTime(Date.now()) // Mark start of current question
      const elapsedMs = Date.now() - startedAtMs
      const remainingMs = Math.max(0, totalQuizTimeMs - elapsedMs)
      setTimeRemaining(Math.floor(remainingMs / 1000))
    } else if (fetchedSession.status === "finished" || fetchedSession.status === "cancelled") {
      router.push(`/dashboard/join-quiz/${quizCode}/leaderboard`)
      return
    } else if (fetchedSession.status === "waiting") {
      router.push(`/dashboard/join-quiz/${quizCode}/waiting-room`)
      return
    }
    setLoading(false)
  }, [quizCode, router, supabase])

  useEffect(() => {
    fetchSession()

    const channel = supabase
      .channel(`session_updates:${quizCode}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "quiz_sessions",
          filter: `session_code=eq.${quizCode}`,
        },
        (payload) => {
          const newSessionData = payload.new as QuizSession
          setSession(newSessionData)
          if (newSessionData.status === "finished" || newSessionData.status === "cancelled") {
            toast({ title: "Quiz Ended!", description: "The quiz has ended." })
            router.push(`/dashboard/join-quiz/${quizCode}/leaderboard`)
          } else if (newSessionData.current_question_index !== currentQuestionIndex) {
            // Host moved to next question
            setCurrentQuestionIndex(newSessionData.current_question_index)
            setSelectedAnswer(null) // Reset selected answer for new question
            setQuestionStartTime(Date.now()) // Reset question start time
            toast({ title: "Next Question!", description: "The host moved to the next question." })
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [quizCode, router, supabase, fetchSession, currentQuestionIndex])

  useEffect(() => {
    if (session?.status === "in_progress" && quizStartedTime !== null) {
      const timer = setInterval(() => {
        const totalQuizTimeMs = session.quizzes.total_time_minutes * 60 * 1000
        const elapsedMs = Date.now() - quizStartedTime
        const remainingMs = Math.max(0, totalQuizTimeMs - elapsedMs)
        setTimeRemaining(Math.floor(remainingMs / 1000))

        if (remainingMs <= 0) {
          clearInterval(timer)
          toast({ title: "Time's Up!", description: "The quiz time has ended." })
          // Automatically finish quiz for participant if time runs out
          finishQuizForParticipant(session.id).then(() => {
            router.push(`/dashboard/join-quiz/${quizCode}/leaderboard`)
          })
        }
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [session, quizStartedTime, quizCode, router])

  const handleAnswerSubmit = async () => {
    if (!session || selectedAnswer === null || questionStartTime === null) return

    setSubmittingAnswer(true)
    const currentQuestion = session.quizzes.questions[currentQuestionIndex]
    const timeTakenMs = Date.now() - questionStartTime

    const result = await submitParticipantAnswer(session.id, currentQuestion.id, selectedAnswer, timeTakenMs)

    if (result.success) {
      toast({
        title: result.isCorrect ? "Correct!" : "Incorrect.",
        description: result.message,
        variant: result.isCorrect ? "default" : "destructive",
      })
      // Do not automatically move to next question in multiplayer, host controls it.
      // For solo mode, this logic would be different.
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setSubmittingAnswer(false)
  }

  if (loading || !session) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <Skeleton className="h-8 w-3/4 mx-auto mb-2" />
            <Skeleton className="h-5 w-1/2 mx-auto" />
          </CardHeader>
          <CardContent className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
            <Skeleton className="h-4 w-1/3 mx-auto mb-8" />
            <Skeleton className="h-48 w-full mb-4" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    )
  }

  const currentQuestion = session.quizzes.questions[currentQuestionIndex]
  const totalQuestions = session.quizzes.questions.length
  const progressValue = ((currentQuestionIndex + 1) / totalQuestions) * 100

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-8">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="flex justify-between items-center mb-4">
            <CardTitle className="text-2xl">Quiz: {session.quizzes.title}</CardTitle>
            <div className="text-lg font-semibold text-primary">Time Left: {formatTime(timeRemaining)}</div>
          </div>
          <Progress value={progressValue} className="w-full mb-4" />
          <CardDescription className="text-lg">
            Question {currentQuestionIndex + 1} of {totalQuestions}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-4">{currentQuestion.question_text}</h2>
            {currentQuestion.question_image_url && (
              <div className="relative w-full h-48 mb-4">
                <Image
                  src={currentQuestion.question_image_url || "/placeholder.svg"}
                  alt="Question Image"
                  fill
                  style={{ objectFit: "contain" }}
                  className="rounded-md"
                />
              </div>
            )}
            <RadioGroup value={selectedAnswer || ""} onValueChange={setSelectedAnswer}>
              {currentQuestion.answers.map((answer) => (
                <div key={answer.id} className="flex items-center space-x-2 p-3 border rounded-md mb-2">
                  <RadioGroupItem value={answer.id} id={`answer-${answer.id}`} />
                  <Label htmlFor={`answer-${answer.id}`} className="flex-1 cursor-pointer">
                    {answer.answer_text}
                    {answer.answer_image_url && (
                      <Image
                        src={answer.answer_image_url || "/placeholder.svg"}
                        alt="Answer Image"
                        width={100}
                        height={100}
                        className="ml-2 inline-block rounded-md"
                      />
                    )}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
          <Button
            onClick={handleAnswerSubmit}
            className="w-full"
            disabled={selectedAnswer === null || submittingAnswer}
          >
            {submittingAnswer ? "Submitting..." : "Submit Answer"}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
