"use client"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

interface Participant {
  id: string
  user_id: string
  username: string
  full_name: string | null
  avatar_url: string | null
}

export default function WaitingRoomPage() {
  const params = useParams()
  const quizCode = params.quizCode as string
  const router = useRouter()
  const supabase = createBrowserClient()

  const [session, setSession] = useState<any>(null)
  const [participants, setParticipants] = useState<Participant[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchSessionAndParticipants = async () => {
      setLoading(true)
      const { data, error: sessionError } = await supabase
        .from("quiz_sessions")
        .select(
          `
          id,
          status,
          quiz_id,
          quizzes(title),
          quiz_participants(id, user_id, username, full_name, avatar_url)
        `,
        )
        .eq("session_code", quizCode)
        .single()

      if (sessionError || !data) {
        console.error("Error fetching session:", sessionError?.message)
        setError("Quiz session not found or invalid code.")
        toast({
          title: "Error",
          description: "Quiz session not found or invalid code.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      setSession(data)
      setParticipants(data.quiz_participants || [])
      setLoading(false)

      if (data.status === "in_progress") {
        router.push(`/dashboard/join-quiz/${quizCode}/quiz`)
      } else if (data.status === "finished" || data.status === "cancelled") {
        router.push(`/dashboard/join-quiz/${quizCode}/leaderboard`)
      }
    }

    fetchSessionAndParticipants()

    // Set up real-time subscription for session status and participants
    const channel = supabase
      .channel(`session:${quizCode}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "quiz_sessions",
          filter: `session_code=eq.${quizCode}`,
        },
        (payload) => {
          const newStatus = (payload.new as any).status
          if (newStatus === "in_progress") {
            toast({ title: "Quiz Started!", description: "The host has started the quiz." })
            router.push(`/dashboard/join-quiz/${quizCode}/quiz`)
          } else if (newStatus === "finished" || newStatus === "cancelled") {
            toast({ title: "Quiz Ended!", description: "The quiz has ended." })
            router.push(`/dashboard/join-quiz/${quizCode}/leaderboard`)
          }
          setSession((prev: any) => ({ ...prev, status: newStatus }))
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*", // Listen for INSERT, UPDATE, DELETE
          schema: "public",
          table: "quiz_participants",
          filter: `session_id=eq.${session?.id}`, // Filter by session ID once available
        },
        async (payload) => {
          // Re-fetch participants to get the latest list
          const { data, error: participantsError } = await supabase
            .from("quiz_sessions")
            .select("quiz_participants(id, user_id, username, full_name, avatar_url)")
            .eq("session_code", quizCode)
            .single()

          if (participantsError) {
            console.error("Error fetching updated participants:", participantsError.message)
          } else if (data) {
            setParticipants(data.quiz_participants || [])
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [quizCode, router, supabase, session?.id]) // Add session.id to dependency array

  if (loading) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <Skeleton className="h-8 w-3/4 mx-auto mb-2" />
            <Skeleton className="h-5 w-1/2 mx-auto" />
          </CardHeader>
          <CardContent className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
            <Skeleton className="h-4 w-1/3 mx-auto mb-8" />
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="flex flex-col items-center gap-2">
                  <Skeleton className="h-16 w-16 rounded-full" />
                  <Skeleton className="h-4 w-20" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CardTitle className="text-2xl text-red-500">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error}</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl">{session?.quizzes?.title || "Quiz Session"}</CardTitle>
          <CardDescription>
            Quiz Code: <span className="font-bold text-primary text-lg">{quizCode}</span>
          </CardDescription>
          <CardDescription className="text-lg font-semibold">Waiting for the host to start the quiz...</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground mb-8">
            Participants joined: <span className="font-bold">{participants.length}</span>
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {participants.map((participant) => (
              <div key={participant.id} className="flex flex-col items-center gap-2">
                <Avatar className="h-16 w-16 border-2 border-primary">
                  <AvatarImage src={participant.avatar_url || "/placeholder-user.jpg"} />
                  <AvatarFallback>{participant.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium truncate w-full px-1">
                  {participant.full_name || participant.username}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
