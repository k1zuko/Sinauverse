"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Plus, Edit, Trash2, Loader2 } from "lucide-react"
import { createCategory, getQuizCategories, updateCategory, deleteCategory } from "@/actions/category"
import { toast } from "@/hooks/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface Category {
  id: string
  name: string
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [newCategoryName, setNewCategoryName] = useState("")
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [deletingCategoryId, setDeletingCategoryId] = useState<string | null>(null)

  useEffect(() => {
    fetchCategories()
  }, [])

  const fetchCategories = async () => {
    setLoading(true)
    const result = await getQuizCategories()
    if (result.success) {
      setCategories(result.categories)
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setLoading(false)
  }

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    const result = await createCategory(newCategoryName)
    if (result.success) {
      toast({ title: "Success", description: result.message })
      setNewCategoryName("")
      fetchCategories() // Re-fetch to update list
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setIsSubmitting(false)
  }

  const handleUpdateCategory = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingCategory) return

    setIsSubmitting(true)
    const result = await updateCategory(editingCategory.id, editingCategory.name)
    if (result.success) {
      toast({ title: "Success", description: result.message })
      setEditingCategory(null)
      fetchCategories() // Re-fetch to update list
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setIsSubmitting(false)
  }

  const handleDeleteCategory = async (id: string) => {
    setDeletingCategoryId(id)
    const result = await deleteCategory(id)
    if (result.success) {
      toast({ title: "Success", description: result.message })
      fetchCategories() // Re-fetch to update list
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setDeletingCategoryId(null)
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/3 mb-6" />
        <Card className="mb-6">
          <CardHeader>
            <Skeleton className="h-6 w-1/4 mb-2" />
          </CardHeader>
          <CardContent className="flex gap-2">
            <Skeleton className="h-10 flex-1" />
            <Skeleton className="h-10 w-24" />
          </CardContent>
        </Card>
        <Skeleton className="h-8 w-1/4 mb-4" />
        <div className="grid gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="flex items-center justify-between p-4">
                <Skeleton className="h-6 w-1/3" />
                <div className="flex gap-2">
                  <Skeleton className="h-9 w-9" />
                  <Skeleton className="h-9 w-9" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Manage Quiz Categories</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Create New Category</CardTitle>
          <CardDescription>Add a new category for your quizzes.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateCategory} className="flex gap-2">
            <Input
              placeholder="e.g., Science, History, Programming"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              required
              disabled={isSubmitting}
            />
            <Button type="submit" disabled={isSubmitting || !newCategoryName.trim()}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
              Add
            </Button>
          </form>
        </CardContent>
      </Card>

      <h2 className="text-2xl font-bold mb-4">Existing Categories</h2>
      {categories.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <p className="text-lg text-muted-foreground">No categories created yet.</p>
            <p className="text-sm text-muted-foreground">Start by adding your first category above!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {categories.map((category) => (
            <Card key={category.id}>
              <CardContent className="flex items-center justify-between p-4">
                {editingCategory?.id === category.id ? (
                  <form onSubmit={handleUpdateCategory} className="flex-1 flex gap-2 items-center">
                    <Input
                      value={editingCategory.name}
                      onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                      required
                      disabled={isSubmitting}
                    />
                    <Button type="submit" size="sm" disabled={isSubmitting || !editingCategory.name.trim()}>
                      {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingCategory(null)}
                      disabled={isSubmitting}
                    >
                      Cancel
                    </Button>
                  </form>
                ) : (
                  <span className="text-lg font-medium">{category.name}</span>
                )}
                <div className="flex gap-2">
                  {editingCategory?.id !== category.id && (
                    <>
                      <Button variant="outline" size="icon" onClick={() => setEditingCategory(category)}>
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Edit Category</span>
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="icon" disabled={deletingCategoryId === category.id}>
                            {deletingCategoryId === category.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Trash2 className="h-4 w-4" />
                            )}
                            <span className="sr-only">Delete Category</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. This will permanently delete the category "{category.name}"
                              and it will no longer be available for quizzes.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDeleteCategory(category.id)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
