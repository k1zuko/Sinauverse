"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createBrowserClient } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/hooks/use-toast"
import { updateUserProfile } from "@/actions/profile"
import { Skeleton } from "@/components/ui/skeleton"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { UploadCloud, Trash2, ImageIcon } from "lucide-react"
import Link from "next/link"

export default function SettingsPage() {
  const supabase = createBrowserClient()
  const [fullName, setFullName] = useState("")
  const [username, setUsername] = useState("")
  const [website, setWebsite] = useState("")
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)

  useEffect(() => {
    const fetchUserProfile = async () => {
      setLoading(true)
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser()

      if (userError || !user) {
        toast({
          title: "Error",
          description: "Please log in to view settings.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      // Fetch from public.users table for full_name, username, website, and avatar_url
      const { data: profile, error: profileError } = await supabase
        .from("users")
        .select("full_name, username, website, avatar_url")
        .eq("id", user.id)
        .single()

      if (profileError) {
        console.error("Error fetching profile:", profileError.message)
        toast({
          title: "Error",
          description: "Failed to load profile data.",
          variant: "destructive",
        })
      } else if (profile) {
        setFullName(profile.full_name || "")
        setUsername(profile.username || "")
        setWebsite(profile.website || "")
        setAvatarUrl(profile.avatar_url || null)
      } else {
        // Fallback to auth.user metadata if public.users entry not found
        setFullName(user.user_metadata?.full_name || "")
        setUsername(user.user_metadata?.username || "")
        setWebsite(user.user_metadata?.website || "")
        setAvatarUrl(user.user_metadata?.avatar_url || null)
      }
      setLoading(false)
    }

    fetchUserProfile()
  }, [supabase])

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingAvatar(true)
    const formData = new FormData()
    formData.append("file", file)

    const { data: result } = await supabase.storage.from("avatars").upload(file.name, formData)
    if (result) {
      const { data: publicUrl } = await supabase.storage.from("avatars").getPublicUrl(result.path)
      setAvatarUrl(publicUrl.publicUrl)
      toast({ title: "Avatar Uploaded", description: "Your new avatar has been uploaded." })
    } else {
      toast({ title: "Upload Failed", description: "Failed to upload avatar.", variant: "destructive" })
    }
    setUploadingAvatar(false)
  }

  const handleRemoveAvatar = async () => {
    if (!avatarUrl) return
    setUploadingAvatar(true) // Use this state to show loading for deletion too
    const { data: result } = await supabase.storage.from("avatars").remove([avatarUrl])
    if (result) {
      setAvatarUrl(null)
      toast({ title: "Avatar Removed", description: "Your avatar has been removed." })
    } else {
      toast({ title: "Removal Failed", description: "Failed to remove avatar.", variant: "destructive" })
    }
    setUploadingAvatar(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    const result = await updateUserProfile({ full_name: fullName, username, website, avatar_url: avatarUrl })

    if (result.success) {
      toast({
        title: "Success",
        description: result.message,
      })
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setIsSubmitting(false)
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/3 mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-1/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent className="grid gap-4">
              <Skeleton className="h-24 w-24 rounded-full mx-auto" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-1/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent className="grid gap-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>Update your personal details and avatar.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="grid gap-4">
              <div className="flex flex-col items-center gap-4">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={avatarUrl || "/placeholder-user.jpg"} alt="User Avatar" />
                  <AvatarFallback>
                    {fullName.charAt(0).toUpperCase() || username.charAt(0).toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex gap-2">
                  {avatarUrl ? (
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={handleRemoveAvatar}
                      disabled={uploadingAvatar}
                    >
                      <Trash2 className="mr-2 h-4 w-4" /> Remove Avatar
                    </Button>
                  ) : (
                    <Label
                      htmlFor="avatar-upload"
                      className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-3 cursor-pointer"
                    >
                      {uploadingAvatar ? (
                        <div className="flex items-center gap-2">
                          <UploadCloud className="h-4 w-4 animate-bounce" /> Uploading...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <ImageIcon className="h-4 w-4" /> Upload Avatar
                        </div>
                      )}
                      <Input
                        id="avatar-upload"
                        type="file"
                        className="sr-only"
                        accept="image/*"
                        onChange={handleAvatarUpload}
                        disabled={uploadingAvatar}
                      />
                    </Label>
                  )}
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="full-name">Full Name</Label>
                <Input
                  id="full-name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="John Doe"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="johndoe"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  placeholder="https://yourwebsite.com"
                />
              </div>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Saving..." : "Save Profile"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quiz Management</CardTitle>
            <CardDescription>Manage your quiz categories and other settings.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Button asChild variant="outline" className="w-full bg-transparent">
              <Link href="/dashboard/settings/categories">Manage Categories</Link>
            </Button>
            {/* Add other quiz management settings here */}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
