"use client"

import { useEffect, useState } from "react"
import { createServerClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/hooks/use-toast"
import { format } from "date-fns"
import { Edit, Trash2, BarChart, Users, Brain, Loader2 } from "lucide-react"
import Link from "next/link"
import { deleteQuiz, createQuizSession } from "@/actions/quiz"
import { useRouter } from "next/navigation"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"

interface Quiz {
  id: string
  title: string
  description: string | null
  category: string | null
  is_public: boolean
  status: "draft" | "published"
  created_at: string
  created_by: string
}

export default function MyQuizzesPage() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([])
  const [loading, setLoading] = useState(true)
  const [deletingQuizId, setDeletingQuizId] = useState<string | null>(null)
  const [creatingSession, setCreatingSession] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchMyQuizzes() {
      setLoading(true)
      const supabase = createServerClient()
      const { data: userData, error: userError } = await supabase.auth.getUser()

      if (userError || !userData.user) {
        toast({
          title: "Authentication Error",
          description: "Please log in to view your quizzes.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      const { data, error } = await supabase
        .from("quizzes")
        .select("id, title, description, category, is_public, status, created_at, created_by")
        .eq("created_by", userData.user.id)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching my quizzes:", error.message)
        toast({
          title: "Error",
          description: "Failed to load your quizzes.",
          variant: "destructive",
        })
      } else {
        setQuizzes(data || [])
      }
      setLoading(false)
    }

    fetchMyQuizzes()
  }, [])

  const handleDeleteQuiz = async (quizId: string) => {
    setDeletingQuizId(quizId)
    const result = await deleteQuiz(quizId)
    if (result.success) {
      toast({ title: "Success", description: result.message })
      setQuizzes(quizzes.filter((q) => q.id !== quizId))
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setDeletingQuizId(null)
  }

  const handleCreateSession = async (
    quizId: string,
    mode: "solo" | "multiplayer",
    quizStatus: "draft" | "published",
  ) => {
    if (quizStatus === "draft") {
      toast({
        title: "Cannot Start Draft Quiz",
        description: "Please publish the quiz before starting a session.",
        variant: "destructive",
      })
      return
    }

    setCreatingSession(quizId)
    const result = await createQuizSession(quizId, mode)
    if (result.success && result.sessionId && result.sessionCode) {
      toast({ title: "Session Created!", description: result.message })
      if (mode === "solo") {
        router.push(`/dashboard/solo-quiz/${quizId}`)
      } else {
        router.push(`/dashboard/host-quiz/${result.sessionId}/session`)
      }
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setCreatingSession(null)
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/3 mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <div className="flex justify-between pt-4">
                  <Skeleton className="h-9 w-24" />
                  <Skeleton className="h-9 w-24" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">My Quizzes</h1>

      {quizzes.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <p className="text-lg text-muted-foreground">You haven't created any quizzes yet.</p>
            <p className="text-sm text-muted-foreground">Start building your first quiz now!</p>
            <div className="mt-6">
              <Button asChild>
                <Link href="/dashboard/create-quiz">Create New Quiz</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => (
            <Card key={quiz.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle>{quiz.title}</CardTitle>
                  <Badge variant={quiz.status === "published" ? "default" : "secondary"} className="capitalize">
                    {quiz.status}
                  </Badge>
                </div>
                <CardDescription className="line-clamp-2">
                  {quiz.description || "No description provided."}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Category: <span className="font-medium">{quiz.category || "Uncategorized"}</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  Created on: {format(new Date(quiz.created_at), "MMM dd, yyyy")}
                </p>
                <div className="flex flex-wrap gap-2 justify-between items-center pt-4">
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/dashboard/create-quiz?quizId=${quiz.id}`}>
                      <Edit className="mr-2 h-4 w-4" /> Edit
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/dashboard/my-quizzes/${quiz.id}/analytics`}>
                      <BarChart className="mr-2 h-4 w-4" /> Analytics
                    </Link>
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm" disabled={deletingQuizId === quiz.id}>
                        {deletingQuizId === quiz.id ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <Trash2 className="mr-2 h-4 w-4" />
                        )}
                        Delete
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently delete your quiz and all associated data.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDeleteQuiz(quiz.id)}>Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                <div className="flex flex-wrap gap-2 justify-between items-center pt-4 border-t mt-4 pt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCreateSession(quiz.id, "solo", quiz.status)}
                    disabled={creatingSession === quiz.id || quiz.status === "draft"}
                  >
                    <Brain className="mr-2 h-4 w-4" />
                    {creatingSession === quiz.id ? <Loader2 className="animate-spin" /> : "Start Solo"}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleCreateSession(quiz.id, "multiplayer", quiz.status)}
                    disabled={creatingSession === quiz.id || quiz.status === "draft"}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    {creatingSession === quiz.id ? <Loader2 className="animate-spin" /> : "Host Multiplayer"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
