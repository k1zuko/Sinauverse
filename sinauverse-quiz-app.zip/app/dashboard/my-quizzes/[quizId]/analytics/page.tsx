"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { getQuizAnalytics, getSessionAnalyticsDetails } from "@/actions/quiz"
import { toast } from "@/hooks/use-toast"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { format } from "date-fns"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sparkles } from "lucide-react" // Import Sparkles component

interface QuizAnalyticsData {
  success: boolean
  message: string
  quiz: {
    id: string
    title: string
    description: string
    questions: Array<{ id: string; question_text: string }>
  } | null
  totalPlays: number
  totalParticipants: number
  totalFinishedParticipants: number
  averageScorePerParticipant: number
  sessions: Array<{
    id: string
    created_at: string
    status: string
    mode: string
    quiz_participants: Array<{
      id: string
      user_id: string
      username: string
      full_name: string
      score: number
      finished_quiz: boolean
      participant_answers: Array<{
        is_correct: boolean
        question_id: string
        time_taken_ms: number
      }>
    }>
  }>
}

interface SessionAnalyticsDetails {
  success: boolean
  message: string
  session: {
    id: string
    created_at: string
    status: string
    mode: string
    quizzes: {
      id: string
      title: string
      questions: Array<{
        id: string
        question_text: string
        answers: Array<{ id: string; answer_text: string; is_correct: boolean }>
      }>
    }
  } | null
  participants: Array<{
    id: string
    user_id: string
    username: string
    full_name: string
    avatar_url: string | null
    score: number
    finished_quiz: boolean
    participant_answers: Array<{
      is_correct: boolean
      question_id: string
      selected_answer_id: string
      time_taken_ms: number
    }>
  }>
  questionStats: Array<{
    questionId: string
    questionText: string
    correctCount: number
    incorrectCount: number
    averageTimeMs: number
    answerDistribution: Array<{
      answerId: string
      answerText: string
      isCorrect: boolean
      count: number
    }>
  }>
}

export default function QuizAnalyticsPage() {
  const params = useParams()
  const quizId = params.quizId as string
  const [analyticsData, setAnalyticsData] = useState<QuizAnalyticsData | null>(null)
  const [sessionDetails, setSessionDetails] = useState<SessionAnalyticsDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null)

  useEffect(() => {
    async function fetchAnalytics() {
      setLoading(true)
      const result = await getQuizAnalytics(quizId)
      if (result.success && result.quiz) {
        setAnalyticsData(result as QuizAnalyticsData)
        if (result.sessions.length > 0) {
          setSelectedSessionId(result.sessions[0].id) // Select the most recent session by default
        }
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to load quiz analytics.",
          variant: "destructive",
        })
      }
      setLoading(false)
    }
    fetchAnalytics()
  }, [quizId])

  useEffect(() => {
    async function fetchSessionDetails() {
      if (selectedSessionId) {
        const result = await getSessionAnalyticsDetails(selectedSessionId)
        if (result.success && result.session) {
          setSessionDetails(result as SessionAnalyticsDetails)
        } else {
          toast({
            title: "Error",
            description: result.message || "Failed to load session details.",
            variant: "destructive",
          })
          setSessionDetails(null)
        }
      } else {
        setSessionDetails(null)
      }
    }
    fetchSessionDetails()
  }, [selectedSessionId])

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/2 mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-64 w-full mb-8" />
        <Skeleton className="h-64 w-full" />
      </div>
    )
  }

  if (!analyticsData?.quiz) {
    return (
      <div className="container mx-auto py-8 text-center text-muted-foreground">
        <p>No analytics available for this quiz or quiz not found.</p>
      </div>
    )
  }

  const { quiz, totalPlays, totalParticipants, totalFinishedParticipants, averageScorePerParticipant, sessions } =
    analyticsData

  // Prepare data for charts
  const sessionPlayData = sessions
    .map((session) => ({
      date: format(new Date(session.created_at), "MMM dd"),
      participants: session.quiz_participants.length,
    }))
    .reverse() // Show chronologically

  const questionAccuracyData =
    sessionDetails?.questionStats.map((q) => ({
      name: q.questionText,
      correct: q.correctCount,
      incorrect: q.incorrectCount,
    })) || []

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#AF19FF", "#FF19AF"] // For answer distribution

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-2">Quiz Analytics: {quiz.title}</h1>
      <p className="text-muted-foreground mb-6">{quiz.description}</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Plays</CardTitle>
            <Sparkles className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalPlays}</div>
            <p className="text-xs text-muted-foreground">Number of times this quiz has been hosted.</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Participants</CardTitle>
            <Sparkles className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalParticipants}</div>
            <p className="text-xs text-muted-foreground">Across all sessions.</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Score</CardTitle>
            <Sparkles className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageScorePerParticipant.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Average score per participant.</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Session Plays Over Time</CardTitle>
          <CardDescription>Number of participants per quiz session over time.</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              participants: {
                label: "Participants",
                color: "hsl(var(--primary))",
              },
            }}
            className="h-[300px] w-full"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sessionPlayData}>
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  tickMargin={10}
                  axisLine={false}
                  tickFormatter={(value) => value.slice(0, 6)}
                />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="participants" fill="var(--color-participants)" radius={8} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Session Details</CardTitle>
          <CardDescription>Select a session to view detailed analytics.</CardDescription>
        </CardHeader>
        <CardContent>
          <Select onValueChange={setSelectedSessionId} value={selectedSessionId || ""}>
            <SelectTrigger className="w-full md:w-[300px] mb-4">
              <SelectValue placeholder="Select a session" />
            </SelectTrigger>
            <SelectContent>
              {sessions.length === 0 ? (
                <SelectItem value="no-sessions" disabled>
                  No sessions available for this quiz.
                </SelectItem>
              ) : (
                sessions.map((session) => (
                  <SelectItem key={session.id} value={session.id}>
                    {format(new Date(session.created_at), "MMM dd, yyyy HH:mm")} - {session.mode} ({session.status})
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>

          {sessionDetails && (
            <div className="grid gap-6 mt-4">
              <h3 className="text-xl font-semibold">Session Overview</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardDescription>Session ID</CardDescription>
                    <CardTitle className="text-lg">{sessionDetails.session?.id.substring(0, 8)}...</CardTitle>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardDescription>Started At</CardDescription>
                    <CardTitle className="text-lg">
                      {sessionDetails.session?.created_at
                        ? format(new Date(sessionDetails.session.created_at), "MMM dd, yyyy HH:mm")
                        : "N/A"}
                    </CardTitle>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardDescription>Status</CardDescription>
                    <CardTitle className="text-lg capitalize">{sessionDetails.session?.status}</CardTitle>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardDescription>Mode</CardDescription>
                    <CardTitle className="text-lg capitalize">{sessionDetails.session?.mode}</CardTitle>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardDescription>Total Participants</CardDescription>
                    <CardTitle className="text-lg">{sessionDetails.participants.length}</CardTitle>
                  </CardHeader>
                </Card>
              </div>

              <h3 className="text-xl font-semibold mt-4">Participant Scores</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Participant</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sessionDetails.participants.map((participant) => (
                    <TableRow key={participant.id}>
                      <TableCell className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={participant.avatar_url || "/placeholder-user.jpg"} />
                          <AvatarFallback>{participant.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                        </Avatar>
                        {participant.full_name || participant.username}
                      </TableCell>
                      <TableCell>{participant.score}</TableCell>
                      <TableCell>
                        <Badge variant={participant.finished_quiz ? "default" : "secondary"}>
                          {participant.finished_quiz ? "Finished" : "In Progress"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <h3 className="text-xl font-semibold mt-4">Question Performance</h3>
              {questionAccuracyData.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {sessionDetails.questionStats.map((qStat, index) => (
                    <Card key={qStat.questionId}>
                      <CardHeader>
                        <CardTitle className="text-base">
                          Question {index + 1}: {qStat.questionText}
                        </CardTitle>
                        <CardDescription>
                          Correct: {qStat.correctCount}, Incorrect: {qStat.incorrectCount}
                          <br />
                          Avg Time: {(qStat.averageTimeMs / 1000).toFixed(2)}s
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ChartContainer
                          config={{
                            correct: { label: "Correct", color: "hsl(var(--chart-1))" },
                            incorrect: { label: "Incorrect", color: "hsl(var(--chart-2))" },
                          }}
                          className="h-[200px] w-full"
                        >
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              data={[{ name: "Answers", correct: qStat.correctCount, incorrect: qStat.incorrectCount }]}
                            >
                              <CartesianGrid vertical={false} />
                              <XAxis dataKey="name" hide />
                              <YAxis />
                              <ChartTooltip content={<ChartTooltipContent />} />
                              <Legend />
                              <Bar dataKey="correct" fill="var(--color-correct)" radius={8} />
                              <Bar dataKey="incorrect" fill="var(--color-incorrect)" radius={8} />
                            </BarChart>
                          </ResponsiveContainer>
                        </ChartContainer>

                        <h4 className="font-semibold mt-4 mb-2">Answer Distribution:</h4>
                        <ChartContainer
                          config={qStat.answerDistribution.reduce(
                            (acc, ans, idx) => ({
                              ...acc,
                              [`answer${idx}`]: { label: ans.answerText, color: COLORS[idx % COLORS.length] },
                            }),
                            {},
                          )}
                          className="h-[200px] w-full"
                        >
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={qStat.answerDistribution}
                                dataKey="count"
                                nameKey="answerText"
                                cx="50%"
                                cy="50%"
                                outerRadius={80}
                                labelLine={false}
                                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                              >
                                {qStat.answerDistribution.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <ChartTooltip content={<ChartTooltipContent />} />
                              <Legend />
                            </PieChart>
                          </ResponsiveContainer>
                        </ChartContainer>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No answer data available for this session.</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
