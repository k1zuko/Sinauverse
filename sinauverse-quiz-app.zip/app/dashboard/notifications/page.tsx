"use client"

import { useEffect, useState, useCallback } from "react"
import { getNotifications, markNotificationAsRead, markAllNotificationsAsRead } from "@/actions/notification"
import { toast } from "@/hooks/use-toast"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { format } from "date-fns"
import { CheckCircle2, MailOpen, BellOff } from "lucide-react"
import Link from "next/link"
import { Skeleton } from "@/components/ui/skeleton"

interface Notification {
  id: string
  title: string
  message: string
  link: string | null
  read_at: string | null
  created_at: string
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [isMarking, setIsMarking] = useState(false)

  const fetchAllNotifications = useCallback(async () => {
    setLoading(true)
    const result = await getNotifications()
    if (result.success) {
      // Fetch all notifications, not just recent ones for the bell
      // The getNotifications action currently limits to 10. For a full page, you might want to remove the limit or implement pagination.
      // For now, we'll use the existing action.
      setNotifications(result.notifications)
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchAllNotifications()
  }, [fetchAllNotifications])

  const handleMarkAsRead = async (id: string) => {
    setIsMarking(true)
    const result = await markNotificationAsRead(id)
    if (result.success) {
      toast({ title: "Success", description: "Notification marked as read." })
      fetchAllNotifications()
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setIsMarking(false)
  }

  const handleMarkAllAsRead = async () => {
    setIsMarking(true)
    const result = await markAllNotificationsAsRead()
    if (result.success) {
      toast({ title: "Success", description: "All notifications marked as read." })
      fetchAllNotifications()
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setIsMarking(false)
  }

  const unreadNotifications = notifications.filter((n) => !n.read_at).length

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/3 mb-6" />
        <div className="flex justify-end mb-4">
          <Skeleton className="h-9 w-36" />
        </div>
        <div className="grid gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-full" />
              </CardHeader>
              <CardContent className="flex justify-between items-center">
                <Skeleton className="h-4 w-1/4" />
                <Skeleton className="h-8 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Your Notifications</h1>

      <div className="flex justify-end mb-4">
        {unreadNotifications > 0 && (
          <Button onClick={handleMarkAllAsRead} disabled={isMarking}>
            <MailOpen className="mr-2 h-4 w-4" /> Mark All as Read
          </Button>
        )}
      </div>

      {notifications.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent className="flex flex-col items-center justify-center">
            <BellOff className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg text-muted-foreground">You don't have any notifications yet.</p>
            <p className="text-sm text-muted-foreground">Check back later for updates!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {notifications.map((notification) => (
            <Card key={notification.id} className={notification.read_at ? "bg-muted/50" : "border-primary"}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-lg">
                  {notification.title}
                  {!notification.read_at && <span className="text-sm font-normal text-primary">New!</span>}
                </CardTitle>
                <CardDescription>{notification.message}</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-between items-center text-sm text-muted-foreground">
                <span>{format(new Date(notification.created_at), "MMM dd, yyyy HH:mm")}</span>
                <div className="flex gap-2">
                  {notification.link && (
                    <Button variant="outline" size="sm" asChild>
                      <Link href={notification.link}>View Details</Link>
                    </Button>
                  )}
                  {!notification.read_at && (
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => handleMarkAsRead(notification.id)}
                      disabled={isMarking}
                    >
                      <CheckCircle2 className="mr-2 h-4 w-4" /> Mark as Read
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
