"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Trophy, Home, RefreshCw } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { Skeleton } from "@/components/ui/skeleton"

interface ParticipantAnswer {
  is_correct: boolean
  question_id: string
  selected_answer_id: string
  time_taken_ms: number
  questions: {
    question_text: string
    answers: Array<{
      id: string
      answer_text: string
      is_correct: boolean
    }>
  }
}

interface Participant {
  id: string
  user_id: string
  username: string
  full_name: string | null
  score: number
  participant_answers: ParticipantAnswer[]
}

interface QuizSession {
  id: string
  quiz_id: string
  host_id: string
  session_code: string
  status: "waiting" | "in_progress" | "finished" | "cancelled"
  quizzes: {
    title: string
    questions: Array<{
      id: string
      question_text: string
      answers: Array<{
        id: string
        answer_text: string
        is_correct: boolean
      }>
    }>
  }
  quiz_participants: Participant[]
}

export default function SoloQuizSummaryPage() {
  const params = useParams()
  const quizId = params.quizId as string // This is the quizId, not sessionId
  const router = useRouter()
  const supabase = createBrowserClient()

  const [session, setSession] = useState<QuizSession | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [userParticipant, setUserParticipant] = useState<Participant | null>(null)

  useEffect(() => {
    const fetchSummary = async () => {
      setLoading(true)
      const { data: userData, error: userError } = await supabase.auth.getUser()
      if (userError || !userData.user) {
        toast({
          title: "Authentication Error",
          description: "Please log in to view quiz summary.",
          variant: "destructive",
        })
        router.push("/login")
        return
      }

      // Find the most recent finished solo session for this quiz and user
      const { data, error: sessionError } = await supabase
        .from("quiz_sessions")
        .select(
          `
          id,
          quiz_id,
          host_id,
          session_code,
          status,
          quizzes(
            title,
            questions(
              id,
              question_text,
              answers(id, answer_text, is_correct)
            )
          ),
          quiz_participants(
            id,
            user_id,
            username,
            full_name,
            score,
            participant_answers(
              is_correct,
              question_id,
              selected_answer_id,
              time_taken_ms,
              questions(question_text, answers(id, answer_text, is_correct))
            )
          )
        `,
        )
        .eq("quiz_id", quizId)
        .eq("host_id", userData.user.id) // Host is the user for solo quizzes
        .eq("mode", "solo")
        .eq("status", "finished")
        .order("created_at", { ascending: false })
        .limit(1)
        .single()

      if (sessionError || !data || !data.quizzes) {
        console.error("Error fetching solo session summary:", sessionError?.message)
        setError("Quiz summary not found or quiz not completed.")
        toast({
          title: "Error",
          description: "Quiz summary not found or quiz not completed.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      setSession(data as QuizSession)
      // Find the current user's participant data
      const currentUserParticipant = (data as QuizSession).quiz_participants.find(
        (p) => p.user_id === userData.user?.id,
      )
      setUserParticipant(currentUserParticipant || null)
      setLoading(false)
    }

    fetchSummary()
  }, [quizId, router, supabase])

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/2 mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    )
  }

  if (error || !session || !userParticipant) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CardTitle className="text-2xl text-red-500">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error || "Could not load quiz summary."}</p>
            <Button onClick={() => router.push("/dashboard")} className="mt-4">
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const totalQuestions = session.quizzes.questions.length
  const correctAnswers = userParticipant.score
  const incorrectAnswers = totalQuestions - correctAnswers
  const percentageCorrect = totalQuestions > 0 ? (correctAnswers / totalQuestions) * 100 : 0

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Quiz Summary: {session.quizzes.title}</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Your Score</CardTitle>
            <Trophy className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {userParticipant.score} / {totalQuestions}
            </div>
            <p className="text-xs text-muted-foreground">{percentageCorrect.toFixed(0)}% Correct</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Performance</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">Correct: {correctAnswers}</div>
            <div className="text-2xl font-bold text-red-500">Incorrect: {incorrectAnswers}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Your Answers</CardTitle>
          <CardDescription>Review your answers for each question.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Question</TableHead>
                <TableHead>Your Answer</TableHead>
                <TableHead>Correct Answer</TableHead>
                <TableHead className="text-right">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {session.quizzes.questions.map((question, index) => {
                const participantAnswer = userParticipant.participant_answers.find(
                  (ans) => ans.question_id === question.id,
                )
                const selectedAnswerText = participantAnswer
                  ? question.answers.find((a) => a.id === participantAnswer.selected_answer_id)?.answer_text || "N/A"
                  : "Not Answered"
                const correctAnswerText = question.answers.find((a) => a.is_correct)?.answer_text || "N/A"

                return (
                  <TableRow key={question.id}>
                    <TableCell className="font-medium">
                      {index + 1}. {question.question_text}
                    </TableCell>
                    <TableCell className={participantAnswer?.is_correct === false ? "text-red-500" : ""}>
                      {selectedAnswerText}
                    </TableCell>
                    <TableCell className="text-green-500">{correctAnswerText}</TableCell>
                    <TableCell className="text-right">
                      {participantAnswer ? (
                        participantAnswer.is_correct ? (
                          <span className="text-green-500">Correct</span>
                        ) : (
                          <span className="text-red-500">Incorrect</span>
                        )
                      ) : (
                        <span className="text-muted-foreground">Skipped</span>
                      )}
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Button onClick={() => router.push("/dashboard")}>
          <Home className="mr-2 h-4 w-4" /> Back to Dashboard
        </Button>
      </div>
    </div>
  )
}
