"use client"

import { Skeleton } from "@/components/ui/skeleton"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { submitParticipantAnswer, finishQuizForParticipant } from "@/actions/quiz"
import Image from "next/image"
import { Loader2 } from "lucide-react"

interface Question {
  id: string
  question_text: string
  question_image_url: string | null
  answers: Array<{
    id: string
    answer_text: string
    answer_image_url: string | null
    is_correct: boolean
  }>
}

interface QuizSession {
  id: string
  quiz_id: string
  host_id: string
  session_code: string
  status: "waiting" | "in_progress" | "finished" | "cancelled"
  current_question_index: number
  started_at: string
  quizzes: {
    title: string
    total_time_minutes: number
    questions: Question[]
  }
}

export default function SoloQuizPage() {
  const params = useParams()
  const quizId = params.quizId as string // This is the quizId, not sessionId for solo mode
  const router = useRouter()
  const supabase = createBrowserClient()

  const [session, setSession] = useState<QuizSession | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [submittingAnswer, setSubmittingAnswer] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(0) // in seconds
  const [questionStartTime, setQuestionStartTime] = useState<number | null>(null)

  // State to hold the actual session ID once created/fetched
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null)

  useEffect(() => {
    const fetchOrCreateSession = async () => {
      setLoading(true)
      // In solo mode, a session is created and immediately started by the user.
      // We need to find the active solo session for this quiz and user, or create one.
      const { data: userSessionData, error: userSessionError } = await supabase.auth.getUser()
      if (userSessionError || !userSessionData.user) {
        toast({
          title: "Authentication Error",
          description: "Please log in to start a solo quiz.",
          variant: "destructive",
        })
        router.push("/login")
        return
      }

      // Try to find an existing in-progress solo session for this quiz and user
      const { data: existingSession, error: existingSessionError } = await supabase
        .from("quiz_sessions")
        .select(
          `
          id,
          quiz_id,
          host_id,
          session_code,
          status,
          current_question_index,
          started_at,
          quizzes(
            title,
            total_time_minutes,
            questions(
              id,
              question_text,
              question_image_url,
              answers(
                id,
                answer_text,
                answer_image_url,
                is_correct
              )
            )
          )
        `,
        )
        .eq("quiz_id", quizId)
        .eq("host_id", userSessionData.user.id)
        .eq("mode", "solo")
        .in("status", ["in_progress", "waiting"]) // Allow resuming if still waiting or in progress
        .order("created_at", { ascending: false })
        .limit(1)
        .single()

      let fetchedSession: QuizSession | null = null

      if (existingSession && existingSession.status === "in_progress") {
        fetchedSession = existingSession as QuizSession
        toast({ title: "Resuming Quiz", description: "Resuming your solo quiz session." })
      } else if (existingSession && existingSession.status === "waiting") {
        // If a waiting session exists, try to start it
        const startResult = await supabase
          .from("quiz_sessions")
          .update({ status: "in_progress", started_at: new Date().toISOString(), current_question_index: 0 })
          .eq("id", existingSession.id)
          .select(`
            id,
            quiz_id,
            host_id,
            session_code,
            status,
            current_question_index,
            started_at,
            quizzes(
              title,
              total_time_minutes,
              questions(
                id,
                question_text,
                question_image_url,
                answers(
                  id,
                  answer_text,
                  answer_image_url,
                  is_correct
                )
              )
            )
          `)
          .single()
        if (startResult.error || !startResult.data) {
          console.error("Error starting existing solo session:", startResult.error?.message)
          toast({ title: "Error", description: "Failed to start existing solo quiz session.", variant: "destructive" })
          router.push("/dashboard")
          return
        }
        fetchedSession = startResult.data as QuizSession
        toast({ title: "Quiz Started!", description: "Your solo quiz session has begun." })
      } else {
        // No active solo session found, create a new one
        const createResult = await supabase
          .from("quiz_sessions")
          .insert({
            quiz_id: quizId,
            host_id: userSessionData.user.id,
            session_code: Math.random().toString(36).substring(2, 8).toUpperCase(), // Generate a random code
            status: "in_progress", // Start immediately for solo
            mode: "solo",
            started_at: new Date().toISOString(),
            current_question_index: 0,
          })
          .select(
            `
            id,
            quiz_id,
            host_id,
            session_code,
            status,
            current_question_index,
            started_at,
            quizzes(
              title,
              total_time_minutes,
              questions(
                id,
                question_text,
                question_image_url,
                answers(
                  id,
                  answer_text,
                  answer_image_url,
                  is_correct
                )
              )
            )
          `,
          )
          .single()

        if (createResult.error || !createResult.data || !createResult.data.quizzes) {
          console.error("Error creating solo session:", createResult.error?.message)
          toast({
            title: "Error",
            description: "Failed to create solo quiz session.",
            variant: "destructive",
          })
          router.push("/dashboard")
          return
        }
        fetchedSession = createResult.data as QuizSession

        // Also add the user as a participant for the new solo session
        const { data: profile, error: profileError } = await supabase
          .from("users")
          .select("username, full_name, avatar_url")
          .eq("id", userSessionData.user.id)
          .single()

        if (profileError || !profile) {
          console.error("User profile not found for solo session participant:", profileError?.message)
          toast({ title: "Error", description: "Failed to load user profile for solo quiz.", variant: "destructive" })
          router.push("/dashboard")
          return
        }

        const { error: participantError } = await supabase.from("quiz_participants").insert({
          session_id: fetchedSession.id,
          user_id: userSessionData.user.id,
          username: profile.username || userSessionData.user.email?.split("@")[0],
          full_name: profile.full_name,
          avatar_url: profile.avatar_url,
        })

        if (participantError) {
          console.error("Error adding participant to solo session:", participantError.message)
          toast({
            title: "Error",
            description: "Failed to add you as a participant to the solo quiz.",
            variant: "destructive",
          })
          router.push("/dashboard")
          return
        }
      }

      if (fetchedSession) {
        setSession(fetchedSession)
        setCurrentSessionId(fetchedSession.id) // Store the actual session ID
        setCurrentQuestionIndex(fetchedSession.current_question_index)
        setQuestionStartTime(Date.now()) // Mark start of current question
        const totalQuizTimeMs = fetchedSession.quizzes.total_time_minutes * 60 * 1000
        const startedAtMs = new Date(fetchedSession.started_at!).getTime()
        const elapsedMs = Date.now() - startedAtMs
        const remainingMs = Math.max(0, totalQuizTimeMs - elapsedMs)
        setTimeRemaining(Math.floor(remainingMs / 1000))
      }
      setLoading(false)
    }

    fetchOrCreateSession()

    // No real-time subscription needed for solo quiz as it's self-contained
  }, [quizId, router, supabase])

  useEffect(() => {
    if (session?.status === "in_progress" && session.started_at !== null) {
      const timer = setInterval(() => {
        const totalQuizTimeMs = session.quizzes.total_time_minutes * 60 * 1000
        const startedAtMs = new Date(session.started_at).getTime()
        const elapsedMs = Date.now() - startedAtMs
        const remainingMs = Math.max(0, totalQuizTimeMs - elapsedMs)
        setTimeRemaining(Math.floor(remainingMs / 1000))

        if (remainingMs <= 0) {
          clearInterval(timer)
          toast({ title: "Time's Up!", description: "The quiz time has ended." })
          // Automatically finish quiz for participant if time runs out
          if (currentSessionId) {
            finishQuizForParticipant(currentSessionId).then(() => {
              router.push(`/dashboard/solo-quiz/${quizId}/summary`)
            })
          }
        }
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [session, quizId, router, currentSessionId])

  const handleAnswerSubmit = async () => {
    if (!session || selectedAnswer === null || questionStartTime === null || !currentSessionId) return

    setSubmittingAnswer(true)
    const currentQuestion = session.quizzes.questions[currentQuestionIndex]
    const timeTakenMs = Date.now() - questionStartTime

    const result = await submitParticipantAnswer(currentSessionId, currentQuestion.id, selectedAnswer, timeTakenMs)

    if (result.success) {
      toast({
        title: result.isCorrect ? "Correct!" : "Incorrect.",
        description: result.message,
        variant: result.isCorrect ? "default" : "destructive",
      })

      // Move to next question automatically in solo mode
      const nextQuestionIndex = currentQuestionIndex + 1
      if (nextQuestionIndex < session.quizzes.questions.length) {
        setCurrentQuestionIndex(nextQuestionIndex)
        setSelectedAnswer(null) // Reset selected answer for new question
        setQuestionStartTime(Date.now()) // Reset question start time
      } else {
        // All questions answered, finish quiz
        const finishResult = await finishQuizForParticipant(currentSessionId)
        if (finishResult.success) {
          router.push(`/dashboard/solo-quiz/${quizId}/summary`)
        } else {
          toast({ title: "Error", description: finishResult.message, variant: "destructive" })
        }
      }
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
    setSubmittingAnswer(false)
  }

  if (loading || !session) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <Skeleton className="h-8 w-3/4 mx-auto mb-2" />
            <Skeleton className="h-5 w-1/2 mx-auto" />
          </CardHeader>
          <CardContent className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
            <Skeleton className="h-48 w-full mb-4" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    )
  }

  const currentQuestion = session.quizzes.questions[currentQuestionIndex]
  const totalQuestions = session.quizzes.questions.length
  const progressValue = ((currentQuestionIndex + 1) / totalQuestions) * 100

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-8">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="flex justify-between items-center mb-4">
            <CardTitle className="text-2xl">Quiz: {session.quizzes.title}</CardTitle>
            <div className="text-lg font-semibold text-primary">Time Left: {formatTime(timeRemaining)}</div>
          </div>
          <Progress value={progressValue} className="w-full mb-4" />
          <CardDescription className="text-lg">
            Question {currentQuestionIndex + 1} of {totalQuestions}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-4">{currentQuestion.question_text}</h2>
            {currentQuestion.question_image_url && (
              <div className="relative w-full h-48 mb-4">
                <Image
                  src={currentQuestion.question_image_url || "/placeholder.svg"}
                  alt="Question Image"
                  fill
                  style={{ objectFit: "contain" }}
                  className="rounded-md"
                />
              </div>
            )}
            <RadioGroup value={selectedAnswer || ""} onValueChange={setSelectedAnswer}>
              {currentQuestion.answers.map((answer) => (
                <div key={answer.id} className="flex items-center space-x-2 p-3 border rounded-md mb-2">
                  <RadioGroupItem value={answer.id} id={`answer-${answer.id}`} />
                  <Label htmlFor={`answer-${answer.id}`} className="flex-1 cursor-pointer">
                    {answer.answer_text}
                    {answer.answer_image_url && (
                      <Image
                        src={answer.answer_image_url || "/placeholder.svg"}
                        alt="Answer Image"
                        width={100}
                        height={100}
                        className="ml-2 inline-block rounded-md"
                      />
                    )}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
          <Button
            onClick={handleAnswerSubmit}
            className="w-full"
            disabled={selectedAnswer === null || submittingAnswer}
          >
            {submittingAnswer ? "Submitting..." : "Submit Answer"}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
