"use client"

import { Skeleton } from "@/components/ui/skeleton"

import { useEffect, useState, useCallback } from "react"
import { useParams, useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { startQuizSession, forceStopQuizSession, updateQuizSessionQuestionIndex } from "@/actions/quiz"
import { ShareButton } from "@/components/share-button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Play, StopCircle, ChevronRight, ChevronLeft, Share2 } from "lucide-react"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"

interface Question {
  id: string
  question_text: string
  question_image_url: string | null
  answers: Array<{
    id: string
    answer_text: string
    answer_image_url: string | null
    is_correct: boolean
  }>
}

interface Participant {
  id: string
  user_id: string
  username: string
  full_name: string | null
  avatar_url: string | null
  score: number
  finished_quiz: boolean
}

interface QuizSession {
  id: string
  quiz_id: string
  host_id: string
  session_code: string
  status: "waiting" | "in_progress" | "finished" | "cancelled"
  current_question_index: number
  started_at: string | null
  quizzes: {
    title: string
    total_time_minutes: number
    questions: Question[]
  }
  quiz_participants: Participant[]
}

export default function HostQuizSessionPage() {
  const params = useParams()
  const sessionId = params.quizId as string // quizId is actually sessionId here
  const router = useRouter()
  const supabase = createBrowserClient()

  const [session, setSession] = useState<QuizSession | null>(null)
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(0) // in seconds
  const [quizStartedTime, setQuizStartedTime] = useState<number | null>(null)

  const fetchSession = useCallback(async () => {
    setLoading(true)
    const { data, error } = await supabase
      .from("quiz_sessions")
      .select(
        `
        id,
        quiz_id,
        host_id,
        session_code,
        status,
        current_question_index,
        started_at,
        quizzes(
          title,
          total_time_minutes,
          questions(
            id,
            question_text,
            question_image_url,
            answers(
              id,
              answer_text,
              answer_image_url,
              is_correct
            )
          )
        ),
        quiz_participants(id, user_id, username, full_name, avatar_url, score, finished_quiz)
      `,
      )
      .eq("id", sessionId)
      .single()

    if (error || !data || !data.quizzes) {
      console.error("Error fetching session:", error?.message)
      toast({
        title: "Error",
        description: "Quiz session not found or an error occurred.",
        variant: "destructive",
      })
      router.push("/dashboard/host-quiz")
      return
    }

    const fetchedSession = data as QuizSession
    setSession(fetchedSession)
    setLoading(false)

    if (fetchedSession.status === "in_progress" && fetchedSession.started_at) {
      const totalQuizTimeMs = fetchedSession.quizzes.total_time_minutes * 60 * 1000
      const startedAtMs = new Date(fetchedSession.started_at).getTime()
      setQuizStartedTime(startedAtMs)
      const elapsedMs = Date.now() - startedAtMs
      const remainingMs = Math.max(0, totalQuizTimeMs - elapsedMs)
      setTimeRemaining(Math.floor(remainingMs / 1000))
    } else if (fetchedSession.status === "finished" || fetchedSession.status === "cancelled") {
      router.push(`/dashboard/join-quiz/${fetchedSession.session_code}/leaderboard`)
    }
  }, [sessionId, router, supabase])

  useEffect(() => {
    fetchSession()

    const channel = supabase
      .channel(`session_host:${sessionId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "quiz_sessions",
          filter: `id=eq.${sessionId}`,
        },
        (payload) => {
          const newSessionData = payload.new as QuizSession
          setSession(newSessionData)
          if (newSessionData.status === "finished" || newSessionData.status === "cancelled") {
            toast({ title: "Session Ended!", description: "The quiz session has concluded." })
            router.push(`/dashboard/join-quiz/${newSessionData.session_code}/leaderboard`)
          } else if (newSessionData.status === "in_progress" && newSessionData.started_at && quizStartedTime === null) {
            // Quiz just started
            setQuizStartedTime(new Date(newSessionData.started_at).getTime())
          }
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*", // Listen for INSERT, UPDATE, DELETE
          schema: "public",
          table: "quiz_participants",
          filter: `session_id=eq.${sessionId}`,
        },
        async (payload) => {
          // Re-fetch participants to get the latest list and scores
          const { data, error: participantsError } = await supabase
            .from("quiz_sessions")
            .select("quiz_participants(id, user_id, username, full_name, avatar_url, score, finished_quiz)")
            .eq("id", sessionId)
            .single()

          if (participantsError) {
            console.error("Error fetching updated participants:", participantsError.message)
          } else if (data) {
            setSession((prev: any) => ({ ...prev, quiz_participants: data.quiz_participants }))
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [sessionId, router, supabase, fetchSession, quizStartedTime])

  useEffect(() => {
    if (session?.status === "in_progress" && quizStartedTime !== null) {
      const timer = setInterval(() => {
        const totalQuizTimeMs = session.quizzes.total_time_minutes * 60 * 1000
        const elapsedMs = Date.now() - quizStartedTime
        const remainingMs = Math.max(0, totalQuizTimeMs - elapsedMs)
        setTimeRemaining(Math.floor(remainingMs / 1000))

        if (remainingMs <= 0) {
          clearInterval(timer)
          handleForceStopQuiz() // Automatically stop quiz if time runs out
        }
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [session, quizStartedTime])

  const handleStartQuiz = async () => {
    if (!session) return
    setActionLoading(true)
    const result = await startQuizSession(session.id)
    if (result.success) {
      toast({ title: "Success", description: result.message })
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setActionLoading(false)
  }

  const handleForceStopQuiz = async () => {
    if (!session) return
    setActionLoading(true)
    const result = await forceStopQuizSession(session.id)
    if (result.success) {
      toast({ title: "Success", description: result.message })
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setActionLoading(false)
  }

  const handleNextQuestion = async () => {
    if (!session) return
    setActionLoading(true)
    const nextIndex = session.current_question_index + 1
    if (nextIndex < session.quizzes.questions.length) {
      const result = await updateQuizSessionQuestionIndex(session.id, nextIndex)
      if (result.success) {
        toast({ title: "Success", description: "Moved to next question." })
      } else {
        toast({ title: "Error", description: result.message, variant: "destructive" })
      }
    } else {
      // All questions answered, finish quiz
      await handleForceStopQuiz()
    }
    setActionLoading(false)
  }

  const handlePreviousQuestion = async () => {
    if (!session) return
    setActionLoading(true)
    const prevIndex = session.current_question_index - 1
    if (prevIndex >= 0) {
      const result = await updateQuizSessionQuestionIndex(session.id, prevIndex)
      if (result.success) {
        toast({ title: "Success", description: "Moved to previous question." })
      } else {
        toast({ title: "Error", description: result.message, variant: "destructive" })
      }
    } else {
      toast({ title: "Info", description: "Already at the first question." })
    }
    setActionLoading(false)
  }

  if (loading || !session) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/2 mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Skeleton className="h-48" />
          <Skeleton className="h-48" />
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    )
  }

  const currentQuestion = session.quizzes.questions[session.current_question_index]
  const totalQuestions = session.quizzes.questions.length
  const progressValue = ((session.current_question_index + 1) / totalQuestions) * 100

  const shareUrl =
    typeof window !== "undefined" ? `${window.location.origin}/dashboard/join-quiz?code=${session.session_code}` : ""

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Host Session: {session.quizzes.title}</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Session Details
              <Badge variant="secondary" className="capitalize">
                {session.status.replace("_", " ")}
              </Badge>
            </CardTitle>
            <CardDescription>Share this code with participants.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            <p className="text-5xl font-bold text-primary tracking-widest">{session.session_code}</p>
            <ShareButton
              title={`Join my quiz: ${session.quizzes.title}`}
              text={`Join my quiz session on Sinauverse! Code: ${session.session_code}`}
              url={shareUrl}
            >
              <Share2 className="mr-2 h-4 w-4" /> Share Session Code
            </ShareButton>
            {session.status === "waiting" && (
              <Button
                onClick={handleStartQuiz}
                disabled={actionLoading || session.quiz_participants.length === 0}
                className="w-full"
              >
                <Play className="mr-2 h-4 w-4" /> Start Quiz
              </Button>
            )}
            {session.status === "in_progress" && (
              <Button onClick={handleForceStopQuiz} disabled={actionLoading} variant="destructive" className="w-full">
                <StopCircle className="mr-2 h-4 w-4" /> End Quiz Session
              </Button>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Participants ({session.quiz_participants.length})
              {session.status === "in_progress" && quizStartedTime !== null && (
                <span className="text-lg font-semibold text-primary">Time Left: {formatTime(timeRemaining)}</span>
              )}
            </CardTitle>
            <CardDescription>Participants currently in the waiting room or playing.</CardDescription>
          </CardHeader>
          <CardContent>
            {session.quiz_participants.length === 0 ? (
              <p className="text-muted-foreground text-center">No participants yet. Share the code!</p>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4 max-h-48 overflow-y-auto">
                {session.quiz_participants.map((participant) => (
                  <div key={participant.id} className="flex flex-col items-center gap-1">
                    <Avatar className="h-12 w-12 border-2 border-muted-foreground">
                      <AvatarImage src={participant.avatar_url || "/placeholder-user.jpg"} />
                      <AvatarFallback>{participant.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs font-medium truncate w-full text-center">
                      {participant.full_name || participant.username}
                    </span>
                    {session.status === "in_progress" && (
                      <Badge variant="outline" className="text-xs">
                        Score: {participant.score}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {session.status === "in_progress" && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Current Question</CardTitle>
            <CardDescription>
              Question {session.current_question_index + 1} of {totalQuestions}
            </CardDescription>
            <Progress value={progressValue} className="w-full mt-2" />
          </CardHeader>
          <CardContent>
            <h2 className="text-xl font-semibold mb-4">{currentQuestion.question_text}</h2>
            {currentQuestion.question_image_url && (
              <div className="relative w-full h-48 mb-4">
                <Image
                  src={currentQuestion.question_image_url || "/placeholder.svg"}
                  alt="Question Image"
                  fill
                  style={{ objectFit: "contain" }}
                  className="rounded-md"
                />
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentQuestion.answers.map((answer) => (
                <div
                  key={answer.id}
                  className={`p-3 border rounded-md ${answer.is_correct ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}`}
                >
                  <p className="font-medium">{answer.answer_text}</p>
                  {answer.answer_image_url && (
                    <Image
                      src={answer.answer_image_url || "/placeholder.svg"}
                      alt="Answer Image"
                      width={80}
                      height={80}
                      className="mt-2 rounded-md"
                    />
                  )}
                  <span className={`text-sm ${answer.is_correct ? "text-green-600" : "text-red-600"}`}>
                    {answer.is_correct ? "Correct Answer" : "Incorrect Answer"}
                  </span>
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-6">
              <Button
                onClick={handlePreviousQuestion}
                disabled={actionLoading || session.current_question_index === 0}
                variant="outline"
              >
                <ChevronLeft className="mr-2 h-4 w-4" /> Previous Question
              </Button>
              <Button
                onClick={handleNextQuestion}
                disabled={actionLoading || session.current_question_index >= totalQuestions - 1}
              >
                Next Question <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
