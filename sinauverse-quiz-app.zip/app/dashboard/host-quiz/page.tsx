"use client"

import { useEffect, useState } from "react"
import { createServerClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/hooks/use-toast"
import { format } from "date-fns"
import { Users, Brain, Loader2 } from "lucide-react"
import Link from "next/link"
import { createQuizSession } from "@/actions/quiz"
import { useRouter } from "next/navigation"

interface Quiz {
  id: string
  title: string
  description: string | null
  category: string | null
  is_public: boolean
  status: "draft" | "published"
  created_at: string
  created_by: string
  users: {
    username: string | null
    full_name: string | null
  } | null
}

export default function HostQuizPage() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([])
  const [loading, setLoading] = useState(true)
  const [creatingSession, setCreatingSession] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchMyPublishedQuizzes() {
      setLoading(true)
      const supabase = createServerClient()
      const { data: userData, error: userError } = await supabase.auth.getUser()

      if (userError || !userData.user) {
        toast({
          title: "Authentication Error",
          description: "Please log in to view your quizzes.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      const { data, error } = await supabase
        .from("quizzes")
        .select(
          "id, title, description, category, is_public, status, created_at, created_by, users(username, full_name)",
        )
        .eq("created_by", userData.user.id)
        .eq("status", "published") // Only show published quizzes for hosting
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching my published quizzes:", error.message)
        toast({
          title: "Error",
          description: "Failed to load your published quizzes.",
          variant: "destructive",
        })
      } else {
        setQuizzes(data || [])
      }
      setLoading(false)
    }

    fetchMyPublishedQuizzes()
  }, [])

  const handleCreateSession = async (quizId: string, mode: "solo" | "multiplayer") => {
    setCreatingSession(quizId)
    const result = await createQuizSession(quizId, mode)
    if (result.success && result.sessionId && result.sessionCode) {
      toast({ title: "Session Created!", description: result.message })
      if (mode === "solo") {
        router.push(`/dashboard/solo-quiz/${quizId}`)
      } else {
        router.push(`/dashboard/host-quiz/${result.sessionId}/session`)
      }
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setCreatingSession(null)
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/3 mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <div className="flex justify-between pt-4">
                  <Skeleton className="h-9 w-24" />
                  <Skeleton className="h-9 w-24" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Host a Quiz</h1>

      {quizzes.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <p className="text-lg text-muted-foreground">You haven't published any quizzes yet.</p>
            <p className="text-sm text-muted-foreground">Only published quizzes can be hosted.</p>
            <div className="mt-6">
              <Button asChild>
                <Link href="/dashboard/create-quiz">Create New Quiz</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => (
            <Card key={quiz.id}>
              <CardHeader>
                <CardTitle>{quiz.title}</CardTitle>
                <CardDescription className="line-clamp-2">
                  {quiz.description || "No description provided."}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Category: <span className="font-medium">{quiz.category || "Uncategorized"}</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  Created on: {format(new Date(quiz.created_at), "MMM dd, yyyy")}
                </p>
                <div className="flex justify-between items-center pt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCreateSession(quiz.id, "solo")}
                    disabled={creatingSession === quiz.id}
                  >
                    <Brain className="mr-2 h-4 w-4" />
                    {creatingSession === quiz.id ? <Loader2 className="animate-spin" /> : "Start Solo"}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleCreateSession(quiz.id, "multiplayer")}
                    disabled={creatingSession === quiz.id}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    {creatingSession === quiz.id ? <Loader2 className="animate-spin" /> : "Host Multiplayer"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
