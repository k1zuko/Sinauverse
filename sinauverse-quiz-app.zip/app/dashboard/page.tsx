import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { createServerClient } from "@/lib/supabase"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { UserAvatar } from "@/components/user-avatar"
import { getRandomPublicQuiz } from "@/actions/quiz" // Import new action
import { Play } from "lucide-react"

export default async function DashboardPage() {
  const cookieStore = cookies()
  const supabase = createServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const username = user.user_metadata?.username || user.email?.split("@")[0] || "User"
  const fullName = user.user_metadata?.full_name || "Sinauverse User"
  const avatarUrl = user.user_metadata?.avatar_url || `https://api.dicebear.com/8.x/fun-emoji/svg?seed=${username}`

  const { quiz: quizOfTheDay } = await getRandomPublicQuiz()

  return (
    <div className="grid gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Welcome, {fullName}!</h1>
        <UserAvatar src={avatarUrl} alt={username} fallback={username.charAt(0).toUpperCase()} className="h-12 w-12" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="flex flex-col items-center justify-center p-6 text-center">
          <CardHeader>
            <CardTitle>Create New Quiz</CardTitle>
            <CardDescription>Design your own quizzes with custom questions and settings.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild size="lg">
              <Link href="/dashboard/create-quiz">Create Quiz</Link>
            </Button>
          </CardContent>
        </Card>
        <Card className="flex flex-col items-center justify-center p-6 text-center">
          <CardHeader>
            <CardTitle>Join a Quiz</CardTitle>
            <CardDescription>Enter a code to participate in a live quiz session.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild size="lg">
              <Link href="/dashboard/join-quiz">Join Quiz</Link>
            </Button>
          </CardContent>
        </Card>
        <Card className="flex flex-col items-center justify-center p-6 text-center">
          <CardHeader>
            <CardTitle>Host a Quiz</CardTitle>
            <CardDescription>Select one of your quizzes to host a session for others.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild size="lg">
              <Link href="/dashboard/host-quiz">Host Quiz</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {quizOfTheDay && (
        <Card className="border-primary border-2">
          <CardHeader>
            <CardTitle className="text-2xl text-primary">Quiz of the Day!</CardTitle>
            <CardDescription>Try out this popular quiz from the community.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-2">
            <h3 className="text-xl font-semibold">{quizOfTheDay.title}</h3>
            <p className="text-muted-foreground line-clamp-2">{quizOfTheDay.description}</p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              Category: {quizOfTheDay.category || "N/A"} | Created by:{" "}
              {quizOfTheDay.users?.full_name || quizOfTheDay.users?.username || "Unknown"}
            </div>
            <Button asChild className="mt-4 w-full">
              <Link href={`/dashboard/join-quiz?code=${quizOfTheDay.id}`}>
                <Play className="mr-2 h-4 w-4" /> Play Now
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>My Quizzes</CardTitle>
            <CardDescription>Your created quizzes, drafts, and published ones.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              View all your quizzes{" "}
              <Link href="/dashboard/my-quizzes" className="underline">
                here
              </Link>
              .
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Public Quizzes</CardTitle>
            <CardDescription>Explore quizzes shared by other users.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Browse all public quizzes{" "}
              <Link href="/dashboard/public-quizzes" className="underline">
                here
              </Link>
              .
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Quizzes</CardTitle>
          <CardDescription>Quizzes you have recently joined or hosted.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            See your recent activity{" "}
            <Link href="/dashboard/recent-quizzes" className="underline">
              here
            </Link>
            .
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
