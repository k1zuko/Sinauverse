"use client"

import { useEffect, useState } from "react"
import { createServerClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/hooks/use-toast"
import { format } from "date-fns"
import { Users, Brain } from "lucide-react"
import Link from "next/link"
import { createQuizSession, getRandomPublicQuiz } from "@/actions/quiz"
import { useRouter, useSearchParams } from "next/navigation"

interface Quiz {
  id: string
  title: string
  description: string | null
  category: string | null
  is_public: boolean
  created_at: string
  created_by: string
  users: {
    username: string | null
    full_name: string | null
  } | null
}

export default function PublicQuizzesPage() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([])
  const [loading, setLoading] = useState(true)
  const [creatingSession, setCreatingSession] = useState<string | null>(null)
  const [randomQuizLoading, setRandomQuizLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const preselectedQuizId = searchParams.get("quizId")

  useEffect(() => {
    async function fetchPublicQuizzes() {
      setLoading(true)
      const supabase = createServerClient()
      const { data, error } = await supabase
        .from("quizzes")
        .select("id, title, description, category, is_public, created_at, created_by, users(username, full_name)")
        .eq("is_public", true)
        .eq("status", "published")
        .order("created_at", { ascending: false })
        .limit(20) // Fetch up to 20 public quizzes

      if (error) {
        console.error("Error fetching public quizzes:", error.message)
        toast({
          title: "Error",
          description: "Failed to load public quizzes.",
          variant: "destructive",
        })
      } else {
        setQuizzes(data || [])
      }
      setLoading(false)
    }

    fetchPublicQuizzes()
  }, [])

  useEffect(() => {
    if (preselectedQuizId && quizzes.length > 0) {
      const quizToScrollTo = document.getElementById(`quiz-${preselectedQuizId}`)
      if (quizToScrollTo) {
        quizToScrollTo.scrollIntoView({ behavior: "smooth", block: "center" })
        // Optionally highlight it for a moment
        quizToScrollTo.classList.add("ring-4", "ring-primary", "ring-opacity-50")
        setTimeout(() => {
          quizToScrollTo.classList.remove("ring-4", "ring-primary", "ring-opacity-50")
        }, 2000)
      }
    }
  }, [preselectedQuizId, quizzes])

  const handleCreateSession = async (quizId: string, mode: "solo" | "multiplayer") => {
    setCreatingSession(quizId)
    const result = await createQuizSession(quizId, mode)
    if (result.success && result.sessionId && result.sessionCode) {
      toast({ title: "Session Created!", description: result.message })
      if (mode === "solo") {
        router.push(`/dashboard/solo-quiz/${quizId}`)
      } else {
        router.push(`/dashboard/host-quiz/${result.sessionId}/session`)
      }
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive" })
    }
    setCreatingSession(null)
  }

  const handlePlayRandomQuiz = async () => {
    setRandomQuizLoading(true)
    const result = await getRandomPublicQuiz()
    if (result.success && result.quiz) {
      toast({ title: "Random Quiz Found!", description: `Starting quiz: ${result.quiz.title}` })
      // Automatically start a solo session for the random quiz
      await handleCreateSession(result.quiz.id, "solo")
    } else {
      toast({ title: "No Quizzes", description: result.message, variant: "destructive" })
    }
    setRandomQuizLoading(false)
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <Skeleton className="h-10 w-1/3 mb-6" />
        <Skeleton className="h-10 w-48 mb-8" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <div className="flex justify-between pt-4">
                  <Skeleton className="h-9 w-24" />
                  <Skeleton className="h-9 w-24" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Public Quizzes</h1>

      <div className="mb-8">
        <Button onClick={handlePlayRandomQuiz} disabled={randomQuizLoading}>
          {randomQuizLoading ? "Finding Quiz..." : "Play Random Quiz"}
        </Button>
      </div>

      {quizzes.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <p className="text-lg text-muted-foreground">No public quizzes available yet.</p>
            <p className="text-sm text-muted-foreground">Be the first to publish one!</p>
            <div className="mt-6">
              <Button asChild>
                <Link href="/dashboard/create-quiz">Create New Quiz</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => (
            <Card key={quiz.id} id={`quiz-${quiz.id}`}>
              <CardHeader>
                <CardTitle>{quiz.title}</CardTitle>
                <CardDescription className="line-clamp-2">
                  {quiz.description || "No description provided."}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Category: <span className="font-medium">{quiz.category || "Uncategorized"}</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  Created by:{" "}
                  <span className="font-medium">{quiz.users?.full_name || quiz.users?.username || "Unknown"}</span> on{" "}
                  {format(new Date(quiz.created_at), "MMM dd, yyyy")}
                </p>
                <div className="flex justify-between items-center pt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCreateSession(quiz.id, "solo")}
                    disabled={creatingSession === quiz.id}
                  >
                    <Brain className="mr-2 h-4 w-4" />
                    {creatingSession === quiz.id ? "Starting Solo..." : "Start Solo"}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleCreateSession(quiz.id, "multiplayer")}
                    disabled={creatingSession === quiz.id}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    {creatingSession === quiz.id ? "Hosting..." : "Host Multiplayer"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
