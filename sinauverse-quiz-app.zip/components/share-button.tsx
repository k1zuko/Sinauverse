"use client"

import { Button } from "@/components/ui/button"
import { Share2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface ShareButtonProps {
  url: string
  title: string
  buttonText?: string
}

export function ShareButton({ url, title, buttonText = "Share" }: ShareButtonProps) {
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          url: url,
        })
        toast({ title: "Shared!", description: "Quiz link shared successfully." })
      } catch (error) {
        console.error("Error sharing:", error)
        toast({ title: "Share Cancelled", description: "Sharing was cancelled or failed.", variant: "destructive" })
      }
    } else {
      // Fallback for browsers that don't support Web Share API
      try {
        await navigator.clipboard.writeText(url)
        toast({ title: "Copied!", description: "Quiz link copied to clipboard." })
      } catch (err) {
        console.error("Failed to copy:", err)
        toast({ title: "Copy Failed", description: "Could not copy link to clipboard.", variant: "destructive" })
      }
    }
  }

  return (
    <Button onClick={handleShare} variant="outline" size="sm">
      <Share2 className="mr-2 h-4 w-4" /> {buttonText}
    </Button>
  )
}
