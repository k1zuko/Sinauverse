"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Trash2, ImageIcon, UploadCloud, Plus } from "lucide-react"
import { uploadImage, deleteImage } from "@/actions/storage"
import { toast } from "@/hooks/use-toast"
import Image from "next/image"

interface Answer {
  id?: string
  answer_text: string
  answer_image_url: string | null
  is_correct: boolean
}

interface Question {
  id?: string
  question_text: string
  question_image_url: string | null
  answers: Answer[]
}

interface QuestionAnswerFormProps {
  question: Question
  onUpdate: (updatedQuestion: Question) => void
  onRemove: () => void
}

export function QuestionAnswerForm({ question, onUpdate, onRemove }: QuestionAnswerFormProps) {
  const [questionText, setQuestionText] = useState(question.question_text)
  const [questionImageUrl, setQuestionImageUrl] = useState(question.question_image_url)
  const [answers, setAnswers] = useState<Answer[]>(question.answers)
  const [uploadingQuestionImage, setUploadingQuestionImage] = useState(false)
  const [uploadingAnswerImage, setUploadingAnswerImage] = useState<Record<string, boolean>>({})

  useEffect(() => {
    setQuestionText(question.question_text)
    setQuestionImageUrl(question.question_image_url)
    setAnswers(question.answers)
  }, [question])

  const handleQuestionTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value
    setQuestionText(newText)
    onUpdate({ ...question, question_text: newText })
  }

  const handleAnswerTextChange = (index: number, text: string) => {
    const newAnswers = answers.map((ans, i) => (i === index ? { ...ans, answer_text: text } : ans))
    setAnswers(newAnswers)
    onUpdate({ ...question, answers: newAnswers })
  }

  const handleCorrectAnswerChange = (index: number, checked: boolean) => {
    const newAnswers = answers.map(
      (ans, i) => (i === index ? { ...ans, is_correct: checked } : { ...ans, is_correct: false }), // Only one correct answer
    )
    setAnswers(newAnswers)
    onUpdate({ ...question, answers: newAnswers })
  }

  const addAnswer = () => {
    const newAnswers = [
      ...answers,
      { id: crypto.randomUUID(), answer_text: "", answer_image_url: null, is_correct: false },
    ]
    setAnswers(newAnswers)
    onUpdate({ ...question, answers: newAnswers })
  }

  const removeAnswer = (index: number) => {
    const newAnswers = answers.filter((_, i) => i !== index)
    setAnswers(newAnswers)
    onUpdate({ ...question, answers: newAnswers })
  }

  const handleQuestionImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingQuestionImage(true)
    const formData = new FormData()
    formData.append("file", file)

    const result = await uploadImage(formData, "quiz_images")
    if (result.success && result.url) {
      setQuestionImageUrl(result.url)
      onUpdate({ ...question, question_image_url: result.url })
      toast({ title: "Image Uploaded", description: "Question image uploaded successfully." })
    } else {
      toast({ title: "Upload Failed", description: result.message, variant: "destructive" })
    }
    setUploadingQuestionImage(false)
  }

  const handleRemoveQuestionImage = async () => {
    if (!questionImageUrl) return
    setUploadingQuestionImage(true) // Use this state to show loading for deletion too
    const result = await deleteImage(questionImageUrl, "quiz_images")
    if (result.success) {
      setQuestionImageUrl(null)
      onUpdate({ ...question, question_image_url: null })
      toast({ title: "Image Removed", description: "Question image removed successfully." })
    } else {
      toast({ title: "Removal Failed", description: result.message, variant: "destructive" })
    }
    setUploadingQuestionImage(false)
  }

  const handleAnswerImageUpload = async (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingAnswerImage((prev) => ({ ...prev, [index]: true }))
    const formData = new FormData()
    formData.append("file", file)

    const result = await uploadImage(formData, "quiz_images")
    if (result.success && result.url) {
      const newAnswers = answers.map((ans, i) => (i === index ? { ...ans, answer_image_url: result.url } : ans))
      setAnswers(newAnswers)
      onUpdate({ ...question, answers: newAnswers })
      toast({ title: "Image Uploaded", description: "Answer image uploaded successfully." })
    } else {
      toast({ title: "Upload Failed", description: result.message, variant: "destructive" })
    }
    setUploadingAnswerImage((prev) => ({ ...prev, [index]: false }))
  }

  const handleRemoveAnswerImage = async (index: number) => {
    const imageUrl = answers[index].answer_image_url
    if (!imageUrl) return

    setUploadingAnswerImage((prev) => ({ ...prev, [index]: true }))
    const result = await deleteImage(imageUrl, "quiz_images")
    if (result.success) {
      const newAnswers = answers.map((ans, i) => (i === index ? { ...ans, answer_image_url: null } : ans))
      setAnswers(newAnswers)
      onUpdate({ ...question, answers: newAnswers })
      toast({ title: "Image Removed", description: "Answer image removed successfully." })
    } else {
      toast({ title: "Removal Failed", description: result.message, variant: "destructive" })
    }
    setUploadingAnswerImage((prev) => ({ ...prev, [index]: false }))
  }

  return (
    <Card className="mb-6">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Question</CardTitle>
        <Button variant="destructive" size="icon" onClick={onRemove}>
          <Trash2 className="h-4 w-4" />
          <span className="sr-only">Remove Question</span>
        </Button>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor={`question-text-${question.id}`}>Question Text</Label>
          <Textarea
            id={`question-text-${question.id}`}
            placeholder="Enter your question here"
            value={questionText}
            onChange={handleQuestionTextChange}
            required
          />
        </div>
        <div className="grid gap-2">
          <Label>Question Image (Optional)</Label>
          {questionImageUrl ? (
            <div className="relative w-32 h-32 border rounded-md overflow-hidden">
              <Image
                src={questionImageUrl || "/placeholder.svg"}
                alt="Question Image"
                fill
                style={{ objectFit: "cover" }}
              />
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-1 right-1 h-6 w-6"
                onClick={handleRemoveQuestionImage}
                disabled={uploadingQuestionImage}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <Label
              htmlFor={`question-image-upload-${question.id}`}
              className="flex items-center justify-center h-24 w-full border-2 border-dashed rounded-md cursor-pointer hover:bg-muted"
            >
              {uploadingQuestionImage ? (
                <div className="flex items-center gap-2">
                  <UploadCloud className="h-4 w-4 animate-bounce" /> Uploading...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4" /> Upload Image
                </div>
              )}
              <Input
                id={`question-image-upload-${question.id}`}
                type="file"
                className="sr-only"
                accept="image/*"
                onChange={handleQuestionImageUpload}
                disabled={uploadingQuestionImage}
              />
            </Label>
          )}
        </div>

        <h3 className="text-lg font-semibold mt-4">Answers</h3>
        {answers.map((answer, index) => (
          <Card key={answer.id} className="p-4">
            <div className="flex items-center justify-between mb-2">
              <Label htmlFor={`answer-text-${answer.id}`}>Answer {index + 1}</Label>
              <div className="flex items-center gap-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`is-correct-${answer.id}`}
                    checked={answer.is_correct}
                    onCheckedChange={(checked) => handleCorrectAnswerChange(index, checked as boolean)}
                  />
                  <Label htmlFor={`is-correct-${answer.id}`}>Correct</Label>
                </div>
                <Button variant="ghost" size="icon" onClick={() => removeAnswer(index)} disabled={answers.length <= 2}>
                  <Trash2 className="h-4 w-4" />
                  <span className="sr-only">Remove Answer</span>
                </Button>
              </div>
            </div>
            <Textarea
              id={`answer-text-${answer.id}`}
              placeholder="Enter answer text"
              value={answer.answer_text}
              onChange={(e) => handleAnswerTextChange(index, e.target.value)}
              required
              className="mb-2"
            />
            <div className="grid gap-2">
              <Label>Answer Image (Optional)</Label>
              {answer.answer_image_url ? (
                <div className="relative w-24 h-24 border rounded-md overflow-hidden">
                  <Image
                    src={answer.answer_image_url || "/placeholder.svg"}
                    alt="Answer Image"
                    fill
                    style={{ objectFit: "cover" }}
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-1 right-1 h-5 w-5"
                    onClick={() => handleRemoveAnswerImage(index)}
                    disabled={uploadingAnswerImage[index]}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <Label
                  htmlFor={`answer-image-upload-${answer.id}`}
                  className="flex items-center justify-center h-16 w-full border-2 border-dashed rounded-md cursor-pointer hover:bg-muted text-sm"
                >
                  {uploadingAnswerImage[index] ? (
                    <div className="flex items-center gap-2">
                      <UploadCloud className="h-3 w-3 animate-bounce" /> Uploading...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <ImageIcon className="h-3 w-3" /> Upload Image
                    </div>
                  )}
                  <Input
                    id={`answer-image-upload-${answer.id}`}
                    type="file"
                    className="sr-only"
                    accept="image/*"
                    onChange={(e) => handleAnswerImageUpload(index, e)}
                    disabled={uploadingAnswerImage[index]}
                  />
                </Label>
              )}
            </div>
          </Card>
        ))}
        <Button type="button" variant="outline" onClick={addAnswer} className="w-full bg-transparent">
          <Plus className="mr-2 h-4 w-4" /> Add Answer
        </Button>
      </CardContent>
    </Card>
  )
}
