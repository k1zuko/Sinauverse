"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { createBrowserClient } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"

interface AuthFormProps {
  type: "login" | "register"
}

export function AuthForm({ type }: AuthFormProps) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createBrowserClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    let result
    if (type === "login") {
      result = await supabase.auth.signInWithPassword({ email, password })
    } else {
      result = await supabase.auth.signUp({ email, password })
    }

    if (result.error) {
      toast({
        title: "Authentication Error",
        description: result.error.message,
        variant: "destructive",
      })
    } else if (type === "register" && result.data.user && !result.data.session) {
      toast({
        title: "Registration Successful",
        description: "Please check your email to confirm your account.",
      })
    } else {
      toast({
        title: "Success",
        description: `${type === "login" ? "Logged in" : "Registered"} successfully!`,
      })
      router.push("/dashboard")
    }
    setLoading(false)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-2xl">{type === "login" ? "Login" : "Register"}</CardTitle>
        <CardDescription>
          {type === "login" ? "Enter your credentials to access your account." : "Create a new account to get started."}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="m@example.com"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading
              ? type === "login"
                ? "Logging in..."
                : "Registering..."
              : type === "login"
                ? "Login"
                : "Register"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
