"use client"

import * as React from "react"
import Link from "next/link"
import { Bell } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  getNotifications,
  getUnreadNotificationCount,
  markNotificationAsRead,
  markAllNotificationsAsRead,
} from "@/actions/notification"
import { toast } from "@/hooks/use-toast"

interface Notification {
  id: string
  title: string
  message: string
  link: string | null
  read_at: string | null
  created_at: string
}

export function NotificationBell() {
  const [notifications, setNotifications] = React.useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = React.useState(0)
  const [isLoading, setIsLoading] = React.useState(true)

  const fetchNotifications = React.useCallback(async () => {
    setIsLoading(true)
    const [notificationsResult, unreadCountResult] = await Promise.all([
      getNotifications(),
      getUnreadNotificationCount(),
    ])

    if (notificationsResult.success) {
      setNotifications(notificationsResult.notifications)
    } else {
      toast({
        title: "Error",
        description: notificationsResult.message,
        variant: "destructive",
      })
    }

    if (unreadCountResult.success) {
      setUnreadCount(unreadCountResult.count)
    } else {
      toast({
        title: "Error",
        description: unreadCountResult.message,
        variant: "destructive",
      })
    }
    setIsLoading(false)
  }, [])

  React.useEffect(() => {
    fetchNotifications()
    // Optionally, set up a polling mechanism for real-time updates
    const interval = setInterval(fetchNotifications, 30000) // Poll every 30 seconds
    return () => clearInterval(interval)
  }, [fetchNotifications])

  const handleMarkAsRead = async (id: string) => {
    const result = await markNotificationAsRead(id)
    if (result.success) {
      fetchNotifications() // Re-fetch to update state and count
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
  }

  const handleMarkAllAsRead = async () => {
    const result = await markAllNotificationsAsRead()
    if (result.success) {
      fetchNotifications() // Re-fetch to update state and count
    } else {
      toast({
        title: "Error",
        description: result.message,
        variant: "destructive",
      })
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount}
            </Badge>
          )}
          <span className="sr-only">View notifications</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <div className="flex items-center justify-between p-2">
          <h4 className="font-medium">Notifications</h4>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={handleMarkAllAsRead} disabled={isLoading}>
              Mark all as read
            </Button>
          )}
        </div>
        <DropdownMenuSeparator />
        <ScrollArea className="h-[300px]">
          {isLoading ? (
            <div className="p-4 text-center text-sm text-muted-foreground">Loading notifications...</div>
          ) : notifications.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">No new notifications.</div>
          ) : (
            notifications.map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                className="flex flex-col items-start space-y-1 p-2 cursor-pointer"
                onSelect={(e) => {
                  // Prevent closing dropdown if it's a link, let Link handle navigation
                  if (notification.link) {
                    e.preventDefault()
                    // Mark as read when clicked, then navigate
                    handleMarkAsRead(notification.id).then(() => {
                      window.location.href = notification.link!
                    })
                  } else {
                    handleMarkAsRead(notification.id)
                  }
                }}
              >
                <div className="flex w-full items-center justify-between">
                  <span className="text-sm font-medium">{notification.title}</span>
                  {!notification.read_at && <Badge className="h-2 w-2 p-0" variant="destructive" title="Unread" />}
                </div>
                <p className="text-xs text-muted-foreground">{notification.message}</p>
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                </span>
                {notification.link && (
                  <Link href={notification.link} className="text-xs text-primary hover:underline mt-1" prefetch={false}>
                    View Details
                  </Link>
                )}
              </DropdownMenuItem>
            ))
          )}
        </ScrollArea>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/dashboard/notifications" className="w-full text-center">
            View All Notifications
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
