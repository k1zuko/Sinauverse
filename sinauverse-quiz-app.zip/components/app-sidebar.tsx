import { Calendar, Home, Inbox, Search, Settings, PlusCircle, Users, BookOpen, ListTree } from "lucide-react" // Import ListTree
import Link from "next/link"
import { cookies } from "next/headers"
import { createServerClient } from "@/lib/supabase"
import { UserAvatar } from "@/components/user-avatar"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"

// Menu items.
const mainItems = [
  {
    title: "Dashboard",
    url: "/dashboard",
    icon: Home,
  },
  {
    title: "My Quizzes",
    url: "/dashboard/my-quizzes",
    icon: BookOpen,
  },
  {
    title: "Public Quizzes",
    url: "/dashboard/public-quizzes",
    icon: Users,
  },
  {
    title: "Recent Quizzes",
    url: "/dashboard/recent-quizzes",
    icon: Calendar,
  },
]

const quizActions = [
  {
    title: "Create Quiz",
    url: "/dashboard/create-quiz",
    icon: PlusCircle,
  },
  {
    title: "Join Quiz",
    url: "/dashboard/join-quiz",
    icon: Inbox,
  },
  {
    title: "Host Quiz",
    url: "/dashboard/host-quiz",
    icon: Search,
  },
]

export async function AppSidebar() {
  const cookieStore = cookies()
  const supabase = createServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  const defaultOpen = cookieStore.get("sidebar:state")?.value === "true"

  return (
    <Sidebar defaultOpen={defaultOpen}>
      <SidebarHeader>
        <Link href="/dashboard" className="flex items-center gap-2 font-semibold text-xl">
          <span className="text-primary">Sinauverse</span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <Link href={item.url}>
                      <item.icon />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        <SidebarGroup>
          <SidebarGroupLabel>Quiz Actions</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {quizActions.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <Link href={item.url}>
                      <item.icon />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/dashboard/settings">
                <Settings />
                <span>Settings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/dashboard/settings/categories">
                <ListTree />
                <span>Categories</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          {user && (
            <SidebarMenuItem>
              <SidebarMenuButton>
                <UserAvatar
                  src={user.user_metadata?.avatar_url || null}
                  alt={user.user_metadata?.username || user.email || "User"}
                  fallback={
                    user.user_metadata?.username?.charAt(0).toUpperCase() || user.email?.charAt(0).toUpperCase() || "U"
                  }
                  className="h-6 w-6"
                />
                <span>{user.user_metadata?.username || user.email}</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          )}
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
