"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase"
import { createNotification } from "../actions/notification" // Import createNotification

interface QuestionData {
  question_text: string
  question_image_url?: string | null
  answers: Array<{
    answer_text: string
    answer_image_url?: string | null
    is_correct: boolean
    id?: string
  }>
  id?: string
}

interface QuizFormData {
  title: string
  description: string
  total_time_minutes: number
  category: string
  is_public: boolean
  status: "draft" | "published"
  questions: QuestionData[]
}

export async function createQuiz(formData: QuizFormData) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    console.error("Authentication error:", userError?.message)
    redirect("/login") // Redirect to login if not authenticated
  }

  try {
    // 1. Insert quiz details
    const { data: quiz, error: quizError } = await supabase
      .from("quizzes")
      .insert({
        title: formData.title,
        description: formData.description,
        total_time_minutes: formData.total_time_minutes,
        category: formData.category,
        is_public: formData.is_public,
        status: formData.status,
        created_by: user.id,
      })
      .select()
      .single()

    if (quizError) throw quizError

    // 2. Insert questions and answers
    for (const questionData of formData.questions) {
      const { data: question, error: questionError } = await supabase
        .from("questions")
        .insert({
          quiz_id: quiz.id,
          question_text: questionData.question_text,
          question_image_url: questionData.question_image_url,
        })
        .select()
        .single()

      if (questionError) throw questionError

      const answersToInsert = questionData.answers.map((answer) => ({
        question_id: question.id,
        answer_text: answer.answer_text,
        answer_image_url: answer.answer_image_url,
        is_correct: answer.is_correct,
      }))

      const { error: answersError } = await supabase.from("answers").insert(answersToInsert)

      if (answersError) throw answersError
    }

    // Create notification for quiz creation
    await createNotification({
      userId: user.id,
      title: `Quiz ${formData.status === "published" ? "Published" : "Saved as Draft"}!`,
      message: `Your quiz "${formData.title}" has been ${formData.status === "published" ? "published" : "saved as a draft"}.`,
      link: `/dashboard/my-quizzes`,
    })

    revalidatePath("/dashboard/my-quizzes") // Revalidate the 'My Quizzes' page
    return { success: true, message: `Quiz ${formData.status} successfully!`, quizId: quiz.id }
  } catch (error: any) {
    console.error("Error creating quiz:", error.message)
    return { success: false, message: `Failed to create quiz: ${error.message}` }
  }
}

export async function deleteQuiz(quizId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    // Get quiz title for notification before deleting
    const { data: quizTitleData, error: quizTitleError } = await supabase
      .from("quizzes")
      .select("title")
      .eq("id", quizId)
      .single()

    if (quizTitleError) throw quizTitleError

    const { error } = await supabase.from("quizzes").delete().eq("id", quizId).eq("created_by", user.id) // Ensure only the owner can delete

    if (error) throw error

    // Create notification for quiz deletion
    await createNotification({
      userId: user.id,
      title: "Quiz Deleted",
      message: `Your quiz "${quizTitleData?.title || "Unknown Quiz"}" has been successfully deleted.`,
    })

    revalidatePath("/dashboard/my-quizzes")
    return { success: true, message: "Quiz deleted successfully." }
  } catch (error: any) {
    console.error("Error deleting quiz:", error.message)
    return { success: false, message: `Failed to delete quiz: ${error.message}` }
  }
}

// Function to fetch quiz for editing
export async function getQuizForEdit(quizId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    redirect("/login")
  }

  try {
    const { data: quiz, error: quizError } = await supabase
      .from("quizzes")
      .select(
        `
        id,
        title,
        description,
        total_time_minutes,
        category,
        is_public,
        status,
        questions (
          id,
          question_text,
          question_image_url,
          answers (
            id,
            answer_text,
            answer_image_url,
            is_correct
          )
        )
      `,
      )
      .eq("id", quizId)
      .eq("created_by", user.id)
      .single()

    if (quizError) throw quizError

    return { success: true, quiz }
  } catch (error: any) {
    console.error("Error fetching quiz for edit:", error.message)
    return { success: false, message: `Failed to fetch quiz: ${error.message}` }
  }
}

// Function to update an existing quiz
export async function updateQuiz(quizId: string, formData: QuizFormData) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    redirect("/login")
  }

  try {
    // 1. Update quiz details
    const { error: quizError } = await supabase
      .from("quizzes")
      .update({
        title: formData.title,
        description: formData.description,
        total_time_minutes: formData.total_time_minutes,
        category: formData.category,
        is_public: formData.is_public,
        status: formData.status,
      })
      .eq("id", quizId)
      .eq("created_by", user.id) // Ensure only the owner can update

    if (quizError) throw quizError

    // 2. Handle questions: delete old, insert new, update existing
    const existingQuestionIds = new Set(formData.questions.map((q) => q.id).filter(Boolean))

    // Delete questions that are no longer in the form
    const { data: currentQuestions, error: currentQuestionsError } = await supabase
      .from("questions")
      .select("id")
      .eq("quiz_id", quizId)

    if (currentQuestionsError) throw currentQuestionsError

    const questionsToDelete = currentQuestions.filter((q) => !existingQuestionIds.has(q.id))
    if (questionsToDelete.length > 0) {
      const { error: deleteQuestionsError } = await supabase
        .from("questions")
        .delete()
        .in(
          "id",
          questionsToDelete.map((q) => q.id),
        )
      if (deleteQuestionsError) throw deleteQuestionsError
    }

    for (const questionData of formData.questions) {
      if (questionData.id) {
        // Update existing question
        const { error: updateQuestionError } = await supabase
          .from("questions")
          .update({
            question_text: questionData.question_text,
            question_image_url: questionData.question_image_url,
          })
          .eq("id", questionData.id)
          .eq("quiz_id", quizId) // Ensure question belongs to this quiz

        if (updateQuestionError) throw updateQuestionError

        // Handle answers for existing question
        const existingAnswerIds = new Set(questionData.answers.map((a) => a.id).filter(Boolean))

        const { data: currentAnswers, error: currentAnswersError } = await supabase
          .from("answers")
          .select("id")
          .eq("question_id", questionData.id)

        if (currentAnswersError) throw currentAnswersError

        const answersToDelete = currentAnswers.filter((a) => !existingAnswerIds.has(a.id))
        if (answersToDelete.length > 0) {
          const { error: deleteAnswersError } = await supabase
            .from("answers")
            .delete()
            .in(
              "id",
              answersToDelete.map((a) => a.id),
            )
          if (deleteAnswersError) throw deleteAnswersError
        }

        for (const answerData of questionData.answers) {
          if (answerData.id) {
            // Update existing answer
            const { error: updateAnswerError } = await supabase
              .from("answers")
              .update({
                answer_text: answerData.answer_text,
                answer_image_url: answerData.answer_image_url,
                is_correct: answerData.is_correct,
              })
              .eq("id", answerData.id)
              .eq("question_id", questionData.id)
            if (updateAnswerError) throw updateAnswerError
          } else {
            // Insert new answer
            const { error: insertAnswerError } = await supabase.from("answers").insert({
              question_id: questionData.id,
              answer_text: answerData.answer_text,
              answer_image_url: answerData.answer_image_url,
              is_correct: answerData.is_correct,
            })
            if (insertAnswerError) throw insertAnswerError
          }
        }
      } else {
        // Insert new question
        const { data: newQuestion, error: insertQuestionError } = await supabase
          .from("questions")
          .insert({
            quiz_id: quizId,
            question_text: questionData.question_text,
            question_image_url: questionData.question_image_url,
          })
          .select()
          .single()

        if (insertQuestionError) throw insertQuestionError

        const answersToInsert = questionData.answers.map((answer) => ({
          question_id: newQuestion.id,
          answer_text: answer.answer_text,
          answer_image_url: answer.answer_image_url,
          is_correct: answer.is_correct,
        }))

        const { error: insertAnswersError } = await supabase.from("answers").insert(answersToInsert)
        if (insertAnswersError) throw insertAnswersError
      }
    }

    // Create notification for quiz update
    await createNotification({
      userId: user.id,
      title: `Quiz ${formData.status === "published" ? "Published" : "Updated"}!`,
      message: `Your quiz "${formData.title}" has been ${formData.status === "published" ? "published" : "updated"}.`,
      link: `/dashboard/my-quizzes`,
    })

    revalidatePath("/dashboard/my-quizzes")
    return { success: true, message: `Quiz ${formData.status} successfully!` }
  } catch (error: any) {
    console.error("Error updating quiz:", error.message)
    return { success: false, message: `Failed to update quiz: ${error.message}` }
  }
}

// Function to generate a unique session code
async function generateUniqueSessionCode(supabase: ReturnType<typeof createServerClient>): Promise<string> {
  let code: string
  let isUnique = false
  do {
    code = Math.random().toString(36).substring(2, 8).toUpperCase() // 6-character alphanumeric code
    const { data, error } = await supabase.from("quiz_sessions").select("id").eq("session_code", code).single()
    if (!data && !error) {
      // If no data and no error, it's unique
      isUnique = true
    }
  } while (!isUnique)
  return code
}

export async function createQuizSession(quizId: string, mode: "solo" | "multiplayer") {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    // Check if the user owns the quiz
    const { data: quiz, error: quizFetchError } = await supabase
      .from("quizzes")
      .select("id, title, created_by, status")
      .eq("id", quizId)
      .eq("created_by", user.id)
      .single()

    if (quizFetchError || !quiz) {
      throw new Error("Quiz not found or you don't have permission to host it.")
    }
    if (quiz.status !== "published") {
      throw new Error("Only published quizzes can be hosted.")
    }

    const sessionCode = await generateUniqueSessionCode(supabase)

    const { data: session, error: sessionError } = await supabase
      .from("quiz_sessions")
      .insert({
        quiz_id: quizId,
        host_id: user.id,
        session_code: sessionCode,
        status: "waiting",
        mode: mode,
      })
      .select()
      .single()

    if (sessionError) throw sessionError

    // For solo mode, automatically add the user as a participant
    if (mode === "solo") {
      const { data: profile, error: profileError } = await supabase
        .from("users")
        .select("username, full_name, avatar_url")
        .eq("id", user.id)
        .single()

      if (profileError || !profile) {
        throw new Error("User profile not found for solo session.")
      }

      const { error: participantError } = await supabase.from("quiz_participants").insert({
        session_id: session.id,
        user_id: user.id,
        username: profile.username || user.email?.split("@")[0],
        full_name: profile.full_name,
        avatar_url: profile.avatar_url,
      })

      if (participantError) throw participantError

      // Also automatically start the solo session
      const { error: startError } = await supabase
        .from("quiz_sessions")
        .update({ status: "in_progress", started_at: new Date().toISOString(), current_question_index: 0 })
        .eq("id", session.id)

      if (startError) throw startError

      // Notification for solo quiz start
      await createNotification({
        userId: user.id,
        title: "Solo Quiz Started!",
        message: `Your solo quiz session for "${quiz.title}" has begun. Good luck!`,
        link: `/dashboard/solo-quiz/${quizId}`,
      })
    } else {
      // Notification for multiplayer session created
      await createNotification({
        userId: user.id,
        title: "Multiplayer Session Created!",
        message: `Your quiz "${quiz.title}" is ready to host. Share code: ${session.session_code}`,
        link: `/dashboard/host-quiz/${session.id}/session`,
      })
    }

    revalidatePath("/dashboard/host-quiz")
    return { success: true, message: "Quiz session created!", sessionCode: session.session_code, sessionId: session.id }
  } catch (error: any) {
    console.error("Error creating quiz session:", error.message)
    return { success: false, message: `Failed to create quiz session: ${error.message}` }
  }
}

export async function joinQuizSession(sessionCode: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    // Find the session
    const { data: session, error: sessionError } = await supabase
      .from("quiz_sessions")
      .select("id, status, quiz_id, host_id, mode, quizzes(title)")
      .eq("session_code", sessionCode)
      .single()

    if (sessionError || !session) {
      throw new Error("Invalid or expired quiz code.")
    }

    if (session.mode === "solo") {
      throw new Error("This is a solo quiz session and cannot be joined by others.")
    }

    if (session.status !== "waiting") {
      throw new Error("This quiz session is not open for joining.")
    }

    // Get user's profile data
    const { data: profile, error: profileError } = await supabase
      .from("users")
      .select("username, full_name, avatar_url")
      .eq("id", user.id)
      .single()

    if (profileError || !profile) {
      throw new Error("User profile not found.")
    }

    // Check if user is already a participant in this session
    const { data: existingParticipant, error: existingParticipantError } = await supabase
      .from("quiz_participants")
      .select("id")
      .eq("session_id", session.id)
      .eq("user_id", user.id)
      .single()

    if (existingParticipantError && existingParticipantError.code !== "PGRST116") {
      // PGRST116 means no rows found
      throw existingParticipantError
    }

    if (existingParticipant) {
      return {
        success: true,
        message: "Already joined session.",
        sessionId: session.id,
        sessionCode: session.session_code,
      }
    }

    // Add participant to the session
    const { error: participantError } = await supabase.from("quiz_participants").insert({
      session_id: session.id,
      user_id: user.id,
      username: profile.username || user.email?.split("@")[0],
      full_name: profile.full_name,
      avatar_url: profile.avatar_url,
    })

    if (participantError) throw participantError

    // Notify host about new participant
    await createNotification({
      userId: session.host_id,
      title: "New Participant Joined!",
      message: `${profile.full_name || profile.username} has joined your quiz session "${session.quizzes?.title}".`,
      link: `/dashboard/host-quiz/${session.id}/session`,
    })

    // Notify participant about joining
    await createNotification({
      userId: user.id,
      title: "Quiz Joined!",
      message: `You have successfully joined "${session.quizzes?.title}". Waiting for host to start.`,
      link: `/dashboard/join-quiz/${session.session_code}/waiting-room`,
    })

    revalidatePath(`/dashboard/join-quiz/${sessionCode}/waiting-room`)
    return {
      success: true,
      message: "Successfully joined quiz session!",
      sessionId: session.id,
      sessionCode: session.session_code,
    }
  } catch (error: any) {
    console.error("Error joining quiz session:", error.message)
    return { success: false, message: `Failed to join quiz: ${error.message}` }
  }
}

export async function startQuizSession(sessionId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    const { data: session, error: sessionFetchError } = await supabase
      .from("quiz_sessions")
      .select("host_id, status, quiz_participants(user_id), quizzes(title)")
      .eq("id", sessionId)
      .single()

    if (sessionFetchError || !session || session.host_id !== user.id) {
      throw new Error("Session not found or you are not the host.")
    }
    if (session.status !== "waiting") {
      throw new Error("Quiz session is not in 'waiting' status.")
    }

    const { error } = await supabase
      .from("quiz_sessions")
      .update({ status: "in_progress", started_at: new Date().toISOString(), current_question_index: 0 })
      .eq("id", sessionId)

    if (error) throw error

    // Notify all participants that the quiz has started
    for (const participant of session.quiz_participants) {
      await createNotification({
        userId: participant.user_id,
        title: "Quiz Started!",
        message: `The quiz "${session.quizzes?.title}" has started. Good luck!`,
        link: `/dashboard/join-quiz/${session.session_code}/quiz`,
      })
    }

    revalidatePath(`/dashboard/host-quiz/${sessionId}/session`)
    return { success: true, message: "Quiz session started!" }
  } catch (error: any) {
    console.error("Error starting quiz session:", error.message)
    return { success: false, message: `Failed to start quiz: ${error.message}` }
  }
}

export async function forceStopQuizSession(sessionId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    const { data: session, error: sessionFetchError } = await supabase
      .from("quiz_sessions")
      .select("host_id, status, quiz_participants(user_id), quizzes(title)")
      .eq("id", sessionId)
      .single()

    if (sessionFetchError || !session || session.host_id !== user.id) {
      throw new Error("Session not found or you are not the host.")
    }
    if (session.status === "finished" || session.status === "cancelled") {
      throw new Error("Quiz session is already finished or cancelled.")
    }

    const { error } = await supabase
      .from("quiz_sessions")
      .update({ status: "finished", finished_at: new Date().toISOString() })
      .eq("id", sessionId)

    if (error) throw error

    // Notify all participants that the quiz has ended
    for (const participant of session.quiz_participants) {
      await createNotification({
        userId: participant.user_id,
        title: "Quiz Ended!",
        message: `The quiz "${session.quizzes?.title}" has been ended by the host. View results.`,
        link: `/dashboard/join-quiz/${session.session_code}/leaderboard`,
      })
    }

    revalidatePath(`/dashboard/host-quiz/${sessionId}/session`)
    return { success: true, message: "Quiz session force stopped!" }
  } catch (error: any) {
    console.error("Error force stopping quiz session:", error.message)
    return { success: false, message: `Failed to force stop quiz: ${error.message}` }
  }
}

export async function submitParticipantAnswer(
  sessionId: string,
  questionId: string,
  selectedAnswerId: string,
  timeTakenMs: number,
) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    // Get participant ID
    const { data: participant, error: participantError } = await supabase
      .from("quiz_participants")
      .select("id, session_id, score")
      .eq("user_id", user.id)
      .eq("session_id", sessionId)
      .single()

    if (participantError || !participant) {
      throw new Error("Participant not found in this session.")
    }

    // Check if the selected answer is correct
    const { data: answer, error: answerError } = await supabase
      .from("answers")
      .select("is_correct")
      .eq("id", selectedAnswerId)
      .eq("question_id", questionId)
      .single()

    if (answerError || !answer) {
      throw new Error("Invalid answer selected.")
    }

    const isCorrect = answer.is_correct

    // Insert participant answer
    const { error: insertError } = await supabase.from("participant_answers").insert({
      participant_id: participant.id,
      question_id: questionId,
      selected_answer_id: selectedAnswerId,
      is_correct: isCorrect,
      time_taken_ms: timeTakenMs,
    })

    if (insertError) throw insertError

    // Update participant score if correct
    if (isCorrect) {
      const { error: scoreError } = await supabase
        .from("quiz_participants")
        .update({ score: (participant.score || 0) + 1 }) // Assuming each correct answer adds 1 point
        .eq("id", participant.id)
      if (scoreError) throw scoreError
    }

    return { success: true, message: "Answer submitted.", isCorrect }
  } catch (error: any) {
    console.error("Error submitting answer:", error.message)
    return { success: false, message: `Failed to submit answer: ${error.message}` }
  }
}

export async function finishQuizForParticipant(sessionId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    const { error } = await supabase
      .from("quiz_participants")
      .update({ finished_quiz: true })
      .eq("session_id", sessionId)
      .eq("user_id", user.id)

    if (error) throw error

    // Get quiz title for notification
    const { data: sessionData, error: sessionDataError } = await supabase
      .from("quiz_sessions")
      .select("quizzes(title), session_code")
      .eq("id", sessionId)
      .single()

    if (sessionDataError) console.error("Error fetching session data for notification:", sessionDataError.message)

    await createNotification({
      userId: user.id,
      title: "Quiz Completed!",
      message: `You have finished the quiz "${sessionData?.quizzes?.title || "Unknown Quiz"}".`,
      link: `/dashboard/join-quiz/${sessionData?.session_code}/leaderboard`,
    })

    return { success: true, message: "Quiz finished for participant." }
  } catch (error: any) {
    console.error("Error finishing quiz for participant:", error.message)
    return { success: false, message: `Failed to finish quiz: ${error.message}` }
  }
}

export async function updateQuizSessionQuestionIndex(sessionId: string, newIndex: number) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    const { data: session, error: sessionFetchError } = await supabase
      .from("quiz_sessions")
      .select("host_id, status, quizzes(title)")
      .eq("id", sessionId)
      .single()

    if (sessionFetchError || !session || session.host_id !== user.id) {
      throw new Error("Session not found or you are not the host.")
    }
    if (session.status !== "in_progress") {
      throw new Error("Quiz session is not in 'in_progress' status.")
    }

    const { error } = await supabase
      .from("quiz_sessions")
      .update({ current_question_index: newIndex })
      .eq("id", sessionId)

    if (error) throw error

    // No specific notification for question index change, as it's real-time for participants.
    // Host gets toast via UI.

    return { success: true, message: "Question index updated." }
  } catch (error: any) {
    console.error("Error updating question index:", error.message)
    return { success: false, message: `Failed to update question index: ${error.message}` }
  }
}

export async function getRandomPublicQuiz() {
  const supabase = createServerClient()

  try {
    const { data: countData, error: countError } = await supabase
      .from("quizzes")
      .select("count", { count: "exact" })
      .eq("is_public", true)
      .eq("status", "published")
      .single()

    if (countError) throw countError

    const totalPublicQuizzes = countData.count || 0

    if (totalPublicQuizzes === 0) {
      return { success: false, message: "No public quizzes available.", quiz: null }
    }

    const randomIndex = Math.floor(Math.random() * totalPublicQuizzes)

    const { data: quiz, error: quizError } = await supabase
      .from("quizzes")
      .select("id, title, description, category, users(username, full_name, avatar_url)")
      .eq("is_public", true)
      .eq("status", "published")
      .range(randomIndex, randomIndex) // Select only one random row
      .single()

    if (quizError) throw quizError

    return { success: true, message: "Random quiz fetched.", quiz }
  } catch (error: any) {
    console.error("Error fetching random public quiz:", error.message)
    return { success: false, message: `Failed to fetch random quiz: ${error.message}`, quiz: null }
  }
}

export async function getQuizAnalytics(quizId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    redirect("/login")
  }

  try {
    // Verify user owns the quiz
    const { data: quizCheck, error: quizCheckError } = await supabase
      .from("quizzes")
      .select("id, title, description, questions(id, question_text)")
      .eq("id", quizId)
      .eq("created_by", user.id)
      .single()

    if (quizCheckError || !quizCheck) {
      throw new Error("Quiz not found or you don't have permission to view analytics.")
    }

    // Fetch all sessions for this quiz
    const { data: sessions, error: sessionsError } = await supabase
      .from("quiz_sessions")
      .select(
        `
      id,
      created_at,
      status,
      mode,
      quiz_participants (
        id,
        user_id,
        username,
        full_name,
        score,
        finished_quiz,
        participant_answers (
          is_correct,
          question_id,
          time_taken_ms
        )
      )
    `,
      )
      .eq("quiz_id", quizId)
      .order("created_at", { ascending: false })

    if (sessionsError) throw sessionsError

    // Process data for analytics
    const totalPlays = sessions.length
    let totalScoreSum = 0
    let totalParticipants = 0
    let totalFinishedParticipants = 0

    sessions.forEach((session) => {
      session.quiz_participants.forEach((participant) => {
        totalScoreSum += participant.score
        totalParticipants++
        if (participant.finished_quiz) {
          totalFinishedParticipants++
        }
      })
    })

    const averageScorePerParticipant = totalParticipants > 0 ? totalScoreSum / totalParticipants : 0

    return {
      success: true,
      quiz: quizCheck,
      totalPlays,
      totalParticipants,
      totalFinishedParticipants,
      averageScorePerParticipant: Number.parseFloat(averageScorePerParticipant.toFixed(2)),
      sessions,
    }
  } catch (error: any) {
    console.error("Error fetching quiz analytics:", error.message)
    return { success: false, message: `Failed to fetch analytics: ${error.message}`, quiz: null, sessions: [] }
  }
}

export async function getSessionAnalyticsDetails(sessionId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    redirect("/login")
  }

  try {
    // Verify user is host of this session
    const { data: sessionCheck, error: sessionCheckError } = await supabase
      .from("quiz_sessions")
      .select(
        `
        id,
        created_at,
        status,
        mode,
        quizzes (id, title, questions(id, question_text, answers(id, answer_text, is_correct)))
      `,
      )
      .eq("id", sessionId)
      .eq("host_id", user.id)
      .single()

    if (sessionCheckError || !sessionCheck || !sessionCheck.quizzes) {
      throw new Error("Session not found or you are not the host.")
    }

    const { data: participants, error: participantsError } = await supabase
      .from("quiz_participants")
      .select(
        `
      id,
      user_id,
      username,
      full_name,
      avatar_url,
      score,
      finished_quiz,
      participant_answers (
        is_correct,
        question_id,
        selected_answer_id,
        time_taken_ms
      )
    `,
      )
      .eq("session_id", sessionId)
      .order("score", { ascending: false })

    if (participantsError) throw participantsError

    // Map questions for easy lookup
    const questionsMap = new Map(
      sessionCheck.quizzes.questions.map((q: any) => [
        q.id,
        {
          text: q.question_text,
          answers: new Map(q.answers.map((a: any) => [a.id, { text: a.answer_text, is_correct: a.is_correct }])),
        },
      ]),
    )

    // Calculate question-level stats
    const questionStats = new Map<
      string,
      {
        text: string
        correctCount: number
        incorrectCount: number
        totalTime: number
        answerCounts: Map<string, number>
      }
    >()

    participants.forEach((participant) => {
      participant.participant_answers.forEach((ans) => {
        const qId = ans.question_id
        if (!questionStats.has(qId)) {
          questionStats.set(qId, {
            text: questionsMap.get(qId)?.text || "Unknown Question",
            correctCount: 0,
            incorrectCount: 0,
            totalTime: 0,
            answerCounts: new Map(),
          })
        }
        const stats = questionStats.get(qId)!
        if (ans.is_correct) {
          stats.correctCount++
        } else {
          stats.incorrectCount++
        }
        stats.totalTime += ans.time_taken_ms || 0
        stats.answerCounts.set(ans.selected_answer_id, (stats.answerCounts.get(ans.selected_answer_id) || 0) + 1)
      })
    })

    const formattedQuestionStats = Array.from(questionStats.entries()).map(([qId, stats]) => ({
      questionId: qId,
      questionText: stats.text,
      correctCount: stats.correctCount,
      incorrectCount: stats.incorrectCount,
      averageTimeMs: stats.totalTime / (stats.correctCount + stats.incorrectCount) || 0,
      answerDistribution: Array.from(stats.answerCounts.entries()).map(([ansId, count]) => ({
        answerId: ansId,
        answerText: questionsMap.get(qId)?.answers.get(ansId)?.text || "Unknown Answer",
        isCorrect: questionsMap.get(qId)?.answers.get(ansId)?.is_correct || false,
        count: count,
      })),
    }))

    return {
      success: true,
      session: sessionCheck,
      participants,
      questionStats: formattedQuestionStats,
    }
  } catch (error: any) {
    console.error("Error fetching session analytics details:", error.message)
    return {
      success: false,
      message: `Failed to fetch session details: ${error.message}`,
      session: null,
      participants: [],
      questionStats: [],
    }
  }
}
