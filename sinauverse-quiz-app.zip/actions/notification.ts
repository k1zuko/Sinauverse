"use server"

import { createServerClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

interface NotificationData {
  userId: string
  title: string
  message: string
  link?: string
}

export async function createNotification({ userId, title, message, link }: NotificationData) {
  const supabase = createServerClient()

  try {
    const { error } = await supabase.from("notifications").insert({
      user_id: userId,
      title,
      message,
      link,
    })

    if (error) {
      console.error("Error creating notification:", error.message)
      return { success: false, message: "Failed to create notification." }
    }

    // Revalidate paths that might display notifications (e.g., header, notifications page)
    revalidatePath("/dashboard", "layout")
    revalidatePath("/dashboard/notifications")

    return { success: true, message: "Notification created successfully." }
  } catch (error: any) {
    console.error("Unexpected error creating notification:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}

export async function getNotifications() {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required.", notifications: [] }
  }

  try {
    const { data: notifications, error } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(10) // Fetch recent notifications for the bell

    if (error) {
      console.error("Error fetching notifications:", error.message)
      return { success: false, message: "Failed to fetch notifications.", notifications: [] }
    }

    return { success: true, notifications }
  } catch (error: any) {
    console.error("Unexpected error fetching notifications:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}`, notifications: [] }
  }
}

export async function getUnreadNotificationCount() {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required.", count: 0 }
  }

  try {
    const { count, error } = await supabase
      .from("notifications")
      .select("*", { count: "exact", head: true })
      .eq("user_id", user.id)
      .is("read_at", null)

    if (error) {
      console.error("Error fetching unread notification count:", error.message)
      return { success: false, message: "Failed to fetch unread count.", count: 0 }
    }

    return { success: true, count: count || 0 }
  } catch (error: any) {
    console.error("Unexpected error fetching unread notification count:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}`, count: 0 }
  }
}

export async function markNotificationAsRead(notificationId: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    const { error } = await supabase
      .from("notifications")
      .update({ read_at: new Date().toISOString() })
      .eq("id", notificationId)
      .eq("user_id", user.id) // Ensure user can only mark their own notifications

    if (error) {
      console.error("Error marking notification as read:", error.message)
      return { success: false, message: "Failed to mark notification as read." }
    }

    revalidatePath("/dashboard", "layout")
    revalidatePath("/dashboard/notifications")

    return { success: true, message: "Notification marked as read." }
  } catch (error: any) {
    console.error("Unexpected error marking notification as read:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}

export async function markAllNotificationsAsRead() {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    const { error } = await supabase
      .from("notifications")
      .update({ read_at: new Date().toISOString() })
      .eq("user_id", user.id)
      .is("read_at", null) // Only mark unread ones

    if (error) {
      console.error("Error marking all notifications as read:", error.message)
      return { success: false, message: "Failed to mark all notifications as read." }
    }

    revalidatePath("/dashboard", "layout")
    revalidatePath("/dashboard/notifications")

    return { success: true, message: "All notifications marked as read." }
  } catch (error: any) {
    console.error("Unexpected error marking all notifications as read:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}
