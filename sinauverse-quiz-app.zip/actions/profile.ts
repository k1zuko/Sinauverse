"use server"

import { createServerClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { createNotification } from "./notification" // Import createNotification

export async function updateProfile(formData: FormData) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    redirect("/login")
  }

  const full_name = formData.get("full_name") as string
  const username = formData.get("username") as string
  const website = formData.get("website") as string
  const avatar_url = formData.get("avatar_url") as string // Assuming this comes from a file upload action

  try {
    const { error } = await supabase
      .from("users")
      .update({
        full_name,
        username,
        website,
        avatar_url,
        updated_at: new Date().toISOString(),
      })
      .eq("id", user.id)

    if (error) {
      console.error("Error updating profile:", error.message)
      return { success: false, message: `Failed to update profile: ${error.message}` }
    }

    // Create notification for profile update
    await createNotification({
      userId: user.id,
      title: "Profile Updated!",
      message: "Your profile information has been successfully updated.",
      link: "/dashboard/settings",
    })

    revalidatePath("/dashboard/settings")
    return { success: true, message: "Profile updated successfully!" }
  } catch (error: any) {
    console.error("Unexpected error updating profile:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}

export async function getProfile() {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    redirect("/login")
  }

  try {
    const { data: profile, error } = await supabase
      .from("users")
      .select("full_name, username, website, avatar_url")
      .eq("id", user.id)
      .single()

    if (error) {
      console.error("Error fetching profile:", error.message)
      return { success: false, message: `Failed to fetch profile: ${error.message}`, profile: null }
    }

    return { success: true, profile }
  } catch (error: any) {
    console.error("Unexpected error fetching profile:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}`, profile: null }
  }
}
