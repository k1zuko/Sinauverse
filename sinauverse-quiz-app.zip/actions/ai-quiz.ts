"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { createServerClient } from "@/lib/supabase"

interface GeneratedAnswer {
  answer_text: string
  is_correct: boolean
}

interface GeneratedQuestion {
  question_text: string
  answers: GeneratedAnswer[]
}

interface AIQuizGenerationResult {
  success: boolean
  message: string
  questions?: GeneratedQuestion[]
}

export async function generateQuizQuestions(topic: string): Promise<AIQuizGenerationResult> {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required to generate quizzes." }
  }

  if (!topic || topic.trim() === "") {
    return { success: false, message: "Please provide a topic for AI generation." }
  }

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"), // Using GPT-4o model
      prompt: `Generate 5 multiple-choice quiz questions about "${topic}". Each question should have 4 answers, with exactly one correct answer. Provide the output as a JSON array of objects, where each object has a "question_text" string and an "answers" array. Each answer object should have "answer_text" string and "is_correct" boolean. Ensure the JSON is valid and can be directly parsed.`,
      temperature: 0.7, // Adjust for creativity vs. factual accuracy
    })

    // Attempt to parse the JSON output
    let generatedQuestions: GeneratedQuestion[]
    try {
      generatedQuestions = JSON.parse(text)
    } catch (parseError) {
      console.error("Failed to parse AI response as JSON:", parseError)
      console.error("Raw AI response:", text)
      return { success: false, message: "AI generated an invalid response. Please try again or refine your topic." }
    }

    // Basic validation of the generated structure
    if (!Array.isArray(generatedQuestions) || generatedQuestions.length === 0) {
      return { success: false, message: "AI did not generate any questions or the format was unexpected." }
    }

    for (const q of generatedQuestions) {
      if (!q.question_text || !Array.isArray(q.answers) || q.answers.length < 2) {
        return {
          success: false,
          message: "AI generated questions in an unexpected format. Missing question text or answers.",
        }
      }
      if (q.answers.filter((a) => a.is_correct).length !== 1) {
        // This is a common issue with AI, sometimes it generates multiple correct answers or none.
        // For now, we'll return an error. In a real app, you might try to fix it or re-prompt.
        return {
          success: false,
          message:
            "AI generated questions with an incorrect number of correct answers. Each question must have exactly one correct answer.",
        }
      }
    }

    return { success: true, message: "Questions generated successfully!", questions: generatedQuestions }
  } catch (error: any) {
    console.error("Error generating quiz questions with AI:", error.message)
    return {
      success: false,
      message: `Failed to generate questions: ${error.message}. Please ensure your OPENAI_API_KEY is set.`,
    }
  }
}
