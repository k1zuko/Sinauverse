"use server"

import { createServerClient } from "@/lib/supabase"
import { v4 as uuidv4 } from "uuid"
import { createNotification } from "./notification" // Import createNotification

export async function uploadImage(formData: FormData, bucketName: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  const file = formData.get("file") as File

  if (!file || file.size === 0) {
    return { success: false, message: "No file provided." }
  }

  const fileExt = file.name.split(".").pop()
  const fileName = `${uuidv4()}.${fileExt}`
  const filePath = `${user.id}/${fileName}` // Store images under user's ID

  try {
    const { data, error } = await supabase.storage.from(bucketName).upload(filePath, file, {
      cacheControl: "3600",
      upsert: false,
    })

    if (error) {
      console.error("Error uploading image:", error.message)
      return { success: false, message: `Failed to upload image: ${error.message}` }
    }

    const { data: publicUrlData } = supabase.storage.from(bucketName).getPublicUrl(filePath)

    // Create notification for image upload
    await createNotification({
      userId: user.id,
      title: "Image Uploaded!",
      message: `Your image "${file.name}" has been successfully uploaded.`,
    })

    return { success: true, message: "Image uploaded successfully!", url: publicUrlData.publicUrl }
  } catch (error: any) {
    console.error("Unexpected error uploading image:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}

export async function deleteImage(url: string, bucketName: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    // Extract the path from the public URL
    const urlParts = url.split("/")
    const filePath = urlParts.slice(urlParts.indexOf(bucketName) + 1).join("/")

    // Ensure the user is trying to delete their own file
    if (!filePath.startsWith(`${user.id}/`)) {
      return { success: false, message: "You can only delete your own images." }
    }

    const { error } = await supabase.storage.from(bucketName).remove([filePath])

    if (error) {
      console.error("Error deleting image:", error.message)
      return { success: false, message: `Failed to delete image: ${error.message}` }
    }

    // Create notification for image deletion
    await createNotification({
      userId: user.id,
      title: "Image Deleted",
      message: `An image has been successfully deleted from your storage.`,
    })

    return { success: true, message: "Image deleted successfully!" }
  } catch (error: any) {
    console.error("Unexpected error deleting image:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}
