"use server"

import { revalidatePath } from "next/cache"
import { createServerClient } from "@/lib/supabase"
import { createNotification } from "./notification" // Import createNotification

export async function createCategory(name: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  if (!name || name.trim() === "") {
    return { success: false, message: "Category name cannot be empty." }
  }

  try {
    const { data, error } = await supabase.from("categories").insert({ name }).select().single()

    if (error) {
      if (error.code === "23505") {
        // Unique violation
        return { success: false, message: `Category "${name}" already exists.` }
      }
      console.error("Error creating category:", error.message)
      return { success: false, message: `Failed to create category: ${error.message}` }
    }

    // Create notification for category creation
    await createNotification({
      userId: user.id,
      title: "New Category Added!",
      message: `The quiz category "${name}" has been successfully created.`,
      link: "/dashboard/settings/categories",
    })

    revalidatePath("/dashboard/settings/categories")
    revalidatePath("/dashboard/create-quiz") // Revalidate quiz creation page to update category list
    return { success: true, message: `Category "${name}" created successfully!`, category: data }
  } catch (error: any) {
    console.error("Unexpected error creating category:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}

export async function getQuizCategories() {
  const supabase = createServerClient()

  try {
    const { data: categories, error } = await supabase
      .from("categories")
      .select("id, name")
      .order("name", { ascending: true })

    if (error) {
      console.error("Error fetching categories:", error.message)
      return { success: false, message: `Failed to fetch categories: ${error.message}`, categories: [] }
    }

    return { success: true, categories }
  } catch (error: any) {
    console.error("Unexpected error fetching categories:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}`, categories: [] }
  }
}

export async function updateCategory(id: string, newName: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  if (!newName || newName.trim() === "") {
    return { success: false, message: "Category name cannot be empty." }
  }

  try {
    const { error } = await supabase.from("categories").update({ name: newName }).eq("id", id)

    if (error) {
      if (error.code === "23505") {
        return { success: false, message: `Category "${newName}" already exists.` }
      }
      console.error("Error updating category:", error.message)
      return { success: false, message: `Failed to update category: ${error.message}` }
    }

    // Create notification for category update
    await createNotification({
      userId: user.id,
      title: "Category Updated!",
      message: `The category has been renamed to "${newName}".`,
      link: "/dashboard/settings/categories",
    })

    revalidatePath("/dashboard/settings/categories")
    revalidatePath("/dashboard/create-quiz") // Revalidate quiz creation page to update category list
    return { success: true, message: `Category updated to "${newName}" successfully!` }
  } catch (error: any) {
    console.error("Unexpected error updating category:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}

export async function deleteCategory(id: string) {
  const supabase = createServerClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return { success: false, message: "Authentication required." }
  }

  try {
    // Get category name for notification before deleting
    const { data: categoryNameData, error: categoryNameError } = await supabase
      .from("categories")
      .select("name")
      .eq("id", id)
      .single()

    if (categoryNameError) throw categoryNameError

    const { error } = await supabase.from("categories").delete().eq("id", id)

    if (error) {
      console.error("Error deleting category:", error.message)
      return { success: false, message: `Failed to delete category: ${error.message}` }
    }

    // Create notification for category deletion
    await createNotification({
      userId: user.id,
      title: "Category Deleted",
      message: `The category "${categoryNameData?.name || "Unknown Category"}" has been removed.`,
      link: "/dashboard/settings/categories",
    })

    revalidatePath("/dashboard/settings/categories")
    revalidatePath("/dashboard/create-quiz") // Revalidate quiz creation page to update category list
    return { success: true, message: "Category deleted successfully!" }
  } catch (error: any) {
    console.error("Unexpected error deleting category:", error.message)
    return { success: false, message: `An unexpected error occurred: ${error.message}` }
  }
}
