"use client"

import { useState, useEffect, use } from "react"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Play, Users, Copy, Check, Crown } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"

export default function HostGamePage({ params }: { params: Promise<{ roomId: string }> }) {
  const resolvedParams = use(params)
  const { user, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [room, setRoom] = useState<any>(null)
  const [participants, setParticipants] = useState<any[]>([])
  const [copied, setCopied] = useState(false)
  const [starting, setStarting] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
      return
    }

    if (user) {
      fetchRoomData()
      subscribeToParticipants()
    }
  }, [user, loading, resolvedParams.roomId])

  const fetchRoomData = async () => {
    const { data, error } = await supabase
      .from("game_rooms")
      .select(`
        *,
        quizzes (
          id,
          title,
          description,
          questions (id)
        )
      `)
      .eq("id", resolvedParams.roomId)
      .single()

    if (error) {
      setError("Room tidak ditemukan")
      return
    }

    if (data.host_id !== user?.id) {
      setError("Anda bukan host dari room ini")
      return
    }

    setRoom(data)
    fetchParticipants()
  }

  const fetchParticipants = async () => {
    const { data } = await supabase
      .from("game_participants")
      .select("*")
      .eq("room_id", resolvedParams.roomId)
      .order("joined_at", { ascending: true })

    if (data) {
      setParticipants(data)
    }
  }

  const subscribeToParticipants = () => {
    const channel = supabase
      .channel(`room-${resolvedParams.roomId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "game_participants",
          filter: `room_id=eq.${resolvedParams.roomId}`,
        },
        () => {
          fetchParticipants()
        },
      )
      .subscribe()

    return channel
  }

  const copyRoomCode = () => {
    if (room) {
      navigator.clipboard.writeText(room.room_code)
      setCopied(true)
      toast({
        title: "Kode room disalin!",
        description: `Kode ${room.room_code} telah disalin ke clipboard`,
      })
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const startGame = async () => {
    if (!room || participants.length === 0) {
      toast({
        title: "Tidak bisa memulai game",
        description: "Minimal harus ada 1 pemain untuk memulai game",
        variant: "destructive",
      })
      return
    }

    setStarting(true)

    try {
      const { error } = await supabase
        .from("game_rooms")
        .update({
          status: "playing",
          started_at: new Date().toISOString(),
        })
        .eq("id", resolvedParams.roomId)

      if (error) {
        setError("Gagal memulai game")
        setStarting(false)
        return
      }

      // Redirect to game
      router.push(`/game/${resolvedParams.roomId}`)
    } catch (err) {
      setError("Terjadi kesalahan yang tidak terduga")
      setStarting(false)
    }
  }

  const removeParticipant = async (participantId: string) => {
    const { error } = await supabase.from("game_participants").delete().eq("id", participantId)

    if (error) {
      toast({
        title: "Error",
        description: "Gagal mengeluarkan pemain",
        variant: "destructive",
      })
    } else {
      toast({
        title: "Pemain dikeluarkan",
        description: "Pemain telah dikeluarkan dari room",
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-2xl">Loading...</div>
      </div>
    )
  }

  if (!user || !room) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Room Tidak Ditemukan</h2>
            <p className="text-gray-600 mb-6">Room yang Anda cari tidak ditemukan atau Anda bukan host.</p>
            <Button onClick={() => router.push("/dashboard")}>Kembali ke Dashboard</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-600 via-blue-500 to-purple-600">
      {/* Header */}
      <header className="relative z-10 px-4 lg:px-6 h-16 flex items-center bg-white/10 backdrop-blur-sm">
        <div className="flex items-center gap-2 text-white">
          <Crown className="w-8 h-8" />
          <span className="font-bold text-xl">Host Lobby</span>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Room Info */}
          <Card className="border-0 shadow-2xl">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">{room.quizzes?.title}</CardTitle>
              <CardDescription>{room.quizzes?.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Room Code */}
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2">Kode Room</p>
                <div className="flex items-center justify-center gap-2">
                  <div className="text-4xl font-bold tracking-widest bg-gray-100 px-6 py-3 rounded-lg">
                    {room.room_code}
                  </div>
                  <Button variant="outline" size="sm" onClick={copyRoomCode}>
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2">Bagikan kode ini kepada pemain</p>
              </div>

              {/* Quiz Info */}
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="text-xl font-bold text-blue-600">{room.quizzes?.questions?.length || 0}</div>
                  <div className="text-sm text-blue-600">Pertanyaan</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="text-xl font-bold text-green-600">{participants.length}</div>
                  <div className="text-sm text-green-600">Pemain</div>
                </div>
              </div>
              {user?.id === room?.host_id && room?.status === 'waiting' && (
  <button onClick={startGame}>Mulai Game</button>
)}

              {/* Start Game Button */}
              <Button
                onClick={startGame}
                disabled={starting || participants.length === 0}
                className="w-full bg-green-600 hover:bg-green-700 text-lg py-6"
              >
                {starting ? (
                  "Memulai Game..."
                ) : (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Mulai Game ({participants.length} pemain)
                  </>
                )}
              </Button>

              {participants.length === 0 && (
                <p className="text-center text-sm text-gray-500">
                  Menunggu pemain bergabung...
                  <br />
                  Bagikan kode room kepada pemain lain
                </p>
              )}
            </CardContent>
          </Card>

          {/* Participants List */}
          <Card className="border-0 shadow-2xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Pemain ({participants.length})
              </CardTitle>
              <CardDescription>Daftar pemain yang telah bergabung</CardDescription>
            </CardHeader>
            <CardContent>
              {participants.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Belum ada pemain yang bergabung</p>
                  <p className="text-sm text-gray-400 mt-2">Bagikan kode room untuk mengundang pemain</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {participants.map((participant, index) => (
                    <div key={participant.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-semibold">{participant.nickname}</p>
                          <p className="text-xs text-gray-500">
                            Bergabung {new Date(participant.joined_at).toLocaleTimeString("id-ID")}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeParticipant(participant.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        Keluarkan
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <Card className="mt-8 bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-6">
            <div className="text-white">
              <h3 className="font-semibold mb-3">Cara Mengundang Pemain:</h3>
              <ol className="space-y-2 text-sm text-white/90">
                <li>
                  1. Bagikan kode room <strong>{room.room_code}</strong> kepada pemain lain
                </li>
                <li>2. Pemain dapat bergabung melalui halaman "Join Game" di website</li>
                <li>3. Tunggu hingga semua pemain bergabung</li>
                <li>4. Klik "Mulai Game" untuk memulai quiz</li>
              </ol>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
