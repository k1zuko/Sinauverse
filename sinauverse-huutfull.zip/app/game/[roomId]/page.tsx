"use client"

import { useState, useEffect, use } from "react"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Trophy, Clock, Users, Crown, Home } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"

const answerColors = [
  "bg-red-500 hover:bg-red-600",
  "bg-blue-500 hover:bg-blue-600",
  "bg-yellow-500 hover:bg-yellow-600",
  "bg-green-500 hover:bg-green-600",
]

const answerShapes = ["△", "◇", "○", "□"]

export default function GamePage({ params }: { params: Promise<{ roomId: string }> }) {
  const resolvedParams = use(params)
  const { user, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [room, setRoom] = useState<any>(null)
  const [questions, setQuestions] = useState<any[]>([])
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [participants, setParticipants] = useState<any[]>([])
  const [myParticipant, setMyParticipant] = useState<any>(null)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [timeLeft, setTimeLeft] = useState(20)
  const [gameState, setGameState] = useState<"waiting" | "playing" | "finished">("waiting")
  const [isHost, setIsHost] = useState(false)
  const [leaderboard, setLeaderboard] = useState<any[]>([])

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
      return
    }

    if (user) {
      fetchGameData()
      subscribeToGameUpdates()
    }
  }, [user, loading, resolvedParams.roomId])

  // Timer effect
  useEffect(() => {
    if (gameState === "playing" && timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && !showResult && gameState === "playing") {
      handleTimeUp()
    }
  }, [timeLeft, gameState, showResult])


  const fetchGameData = async () => {
    // Fetch room data
    const { data: roomData, error: roomError } = await supabase
      .from("game_rooms")
      .select(`
        *,
        quizzes (
          id,
          title,
          questions (
            id,
            question_text,
            time_limit,
            points,
            order_index,
            answer_options (
              id,
              option_text,
              is_correct,
              option_index
            )
          )
        )
      `)
      .eq("id", resolvedParams.roomId)
      .single()

    if (roomError) {
      toast({
        title: "Error",
        description: "Room tidak ditemukan",
        variant: "destructive",
      })
      router.push("/dashboard")
      return
    }

    setRoom(roomData)
    setIsHost(roomData.host_id === user?.id)
    setGameState(roomData.status)
    setCurrentQuestion(roomData.current_question)

    // Sort questions by order
    const sortedQuestions = roomData.quizzes.questions.sort((a: any, b: any) => a.order_index - b.order_index)
    setQuestions(sortedQuestions)

    // Set timer for current question
    if (sortedQuestions[roomData.current_question]) {
      setTimeLeft(sortedQuestions[roomData.current_question].time_limit)
    }

    // Fetch participants
    fetchParticipants()
  }

  const fetchParticipants = async () => {
    const { data } = await supabase
      .from("game_participants")
      .select("*")
      .eq("room_id", resolvedParams.roomId)
      .order("score", { ascending: false })

    if (data) {
      setParticipants(data)
      const myData = data.find((p) => p.user_id === user?.id)
      setMyParticipant(myData)
    }
  }

  const subscribeToGameUpdates = () => {
    const channel = supabase
      .channel(`game-${resolvedParams.roomId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "game_rooms",
          filter: `id=eq.${resolvedParams.roomId}`,
        },
        (payload) => {
          const newData = payload.new as any
          setGameState(newData.status)
          setCurrentQuestion(newData.current_question)

          if (questions[newData.current_question]) {
            setTimeLeft(questions[newData.current_question].time_limit)
            setSelectedAnswer(null)
            setShowResult(false)
          }
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "game_participants",
          filter: `room_id=eq.${resolvedParams.roomId}`,
        },
        () => {
          fetchParticipants()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  const handleAnswerSelect = async (answerIndex: number) => {
    if (selectedAnswer !== null || showResult || !myParticipant) return

    setSelectedAnswer(answerIndex)
    const question = questions[currentQuestion]
    const selectedOption = question.answer_options.find((opt: any) => opt.option_index === answerIndex)
    const isCorrect = selectedOption?.is_correct || false

    // Calculate points based on speed
    const timeBonus = Math.max(0, timeLeft / question.time_limit)
    const points = isCorrect ? Math.floor(question.points * (0.5 + 0.5 * timeBonus)) : 0

    // Save answer to database
    await supabase.from("game_answers").insert({
      room_id: resolvedParams.roomId,
      participant_id: myParticipant.id,
      question_id: question.id,
      selected_option_id: selectedOption?.id,
      is_correct: isCorrect,
      points_earned: points,
      answer_time: question.time_limit - timeLeft,
    })

    // Update participant score
    if (isCorrect) {
      await supabase
        .from("game_participants")
        .update({ score: myParticipant.score + points })
        .eq("id", myParticipant.id)
    }

    setShowResult(true)

    // Auto advance after showing result
    setTimeout(() => {
      if (isHost) {
        nextQuestion()
      }
    }, 3000)
  }

  const handleTimeUp = () => {
    setShowResult(true)
    setTimeout(() => {
      if (isHost) {
        nextQuestion()
      }
    }, 2000)
  }

  const nextQuestion = async () => {
    if (currentQuestion < questions.length - 1) {
      // Move to next question
      await supabase
        .from("game_rooms")
        .update({ current_question: currentQuestion + 1 })
        .eq("id", resolvedParams.roomId)
    } else {
      // End game
      await supabase
        .from("game_rooms")
        .update({
          status: "finished",
          finished_at: new Date().toISOString(),
        })
        .eq("id", resolvedParams.roomId)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-2xl">Loading...</div>
      </div>
    )
  }

  if (!room || !questions.length) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-2xl">Loading game...</div>
      </div>
    )
  }

  if (gameState === "waiting") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-4">Menunggu Host</h2>
            <p className="text-gray-600 mb-6">Game akan dimulai sebentar lagi...</p>
            <div className="animate-pulse">
              <Users className="w-12 h-12 mx-auto text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (gameState === "finished") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-500 to-blue-500 flex items-center justify-center p-4">
        <div className="w-full max-w-2xl">
          <Card className="border-0 shadow-2xl">
            <CardContent className="p-8 text-center">
              <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-6">Game Selesai!</h2>

              {/* Final Leaderboard */}
              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <h3 className="text-xl font-semibold mb-4">Leaderboard Final</h3>
                <div className="space-y-3">
                  {participants.slice(0, 5).map((participant, index) => (
                    <div key={participant.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${index === 0
                              ? "bg-yellow-500"
                              : index === 1
                                ? "bg-gray-400"
                                : index === 2
                                  ? "bg-orange-500"
                                  : "bg-gray-300"
                            }`}
                        >
                          {index + 1}
                        </div>
                        <span className="font-semibold">{participant.nickname}</span>
                      </div>
                      <span className="font-bold">{participant.score.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-4 justify-center">
                <Button onClick={() => router.push("/dashboard")}>
                  <Home className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
                {isHost && <Button onClick={() => router.push(`/play/${room.quiz_id}`)}>Main Lagi</Button>}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const question = questions[currentQuestion]
  const progress = ((currentQuestion + 1) / questions.length) * 100

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-6xl mx-auto p-4">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg p-6 text-white mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-4">
              {isHost && <Crown className="w-6 h-6" />}
              <div>
                <div className="text-lg font-semibold">
                  Pertanyaan {currentQuestion + 1} dari {questions.length}
                </div>
                <div className="text-sm opacity-90">{room.quizzes.title}</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span className="text-sm">{participants.length}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <span className="text-2xl font-bold">{timeLeft}</span>
              </div>
            </div>
          </div>
          <Progress value={progress} className="h-2 bg-white/20" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Question */}
          <div className="lg:col-span-3">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8 leading-tight">
                  {question.question_text}
                </h2>

                {/* Answer Options */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
                  {question.answer_options
                    .sort((a: any, b: any) => a.option_index - b.option_index)
                    .map((option: any, index: number) => {
                      let buttonClass = `${answerColors[index]} text-white text-xl font-bold py-6 px-8 rounded-2xl transition-all duration-300 transform hover:scale-105 relative overflow-hidden`

                      if (showResult) {
                        if (option.is_correct) {
                          buttonClass =
                            "bg-green-500 text-white text-xl font-bold py-6 px-8 rounded-2xl relative overflow-hidden ring-4 ring-green-300 animate-pulse"
                        } else if (index === selectedAnswer) {
                          buttonClass =
                            "bg-red-500 text-white text-xl font-bold py-6 px-8 rounded-2xl relative overflow-hidden ring-4 ring-red-300"
                        } else {
                          buttonClass =
                            "bg-gray-400 text-white text-xl font-bold py-6 px-8 rounded-2xl relative overflow-hidden opacity-50"
                        }
                      }

                      return (
                        <Button
                          key={option.id}
                          onClick={() => handleAnswerSelect(index)}
                          disabled={selectedAnswer !== null}
                          className={buttonClass}
                        >
                          <span className="text-3xl mr-3">{answerShapes[index]}</span>
                          {option.option_text}
                        </Button>
                      )
                    })}
                </div>

                {/* My Score */}
                {myParticipant && (
                  <div className="mt-8">
                    <div className="inline-flex items-center gap-2 bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full font-bold">
                      <Trophy className="w-5 h-5" />
                      Poin Saya: {myParticipant.score.toLocaleString()}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Leaderboard */}
          <div className="lg:col-span-1">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  Leaderboard
                </h3>
                <div className="space-y-3">
                  {participants.slice(0, 10).map((participant, index) => (
                    <div
                      key={participant.id}
                      className={`flex items-center justify-between p-2 rounded-lg ${participant.id === myParticipant?.id ? "bg-blue-50 border border-blue-200" : "bg-gray-50"
                        }`}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${index === 0
                              ? "bg-yellow-500"
                              : index === 1
                                ? "bg-gray-400"
                                : index === 2
                                  ? "bg-orange-500"
                                  : "bg-gray-300"
                            }`}
                        >
                          {index + 1}
                        </div>
                        <span className="text-sm font-medium truncate">{participant.nickname}</span>
                      </div>
                      <span className="text-sm font-bold">{participant.score.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
