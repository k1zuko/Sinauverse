"use client"

import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Header } from "@/components/layout/header"
import { LoadingSpinner } from "@/components/layout/loading-spinner"
import {
  Plus,
  Play,
  Users,
  Trophy,
  Trash2,
  Calendar,
  Search,
  Filter,
  BookOpen,
  Globe,
  Lock,
  Eye,
  Clock,
  Star,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import type { Database } from "@/types/database"
import Swal from "sweetalert2"

type Quiz = Database["public"]["Tables"]["quizzes"]["Row"] & {
  questions: { id: string }[]
  profiles: { username: string; full_name: string } | null
  _count?: { game_rooms: number }
}

type GameRoom = Database["public"]["Tables"]["game_rooms"]["Row"] & {
  quizzes: { title: string } | null
  game_participants: { id: string }[]
}

export default function DashboardPage() {
  const { user, profile, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  // State management
  const [allQuizzes, setAllQuizzes] = useState<Quiz[]>([])
  const [myQuizzes, setMyQuizzes] = useState<Quiz[]>([])
  const [recentQuizzes, setRecentQuizzes] = useState<Quiz[]>([])
  const [recentGames, setRecentGames] = useState<GameRoom[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dataLoading, setDataLoading] = useState(true)

  const [stats, setStats] = useState({
    totalQuizzes: 0,
    totalGames: 0,
    totalPlayers: 0,
    totalPlays: 0,
  })

  useEffect(() => {
    if (loading) return
    if (!user) {
      router.push("/auth/login")
      return
    }
    if (user && dataLoading) {
      fetchDashboardData()
    }
  }, [user, loading, router])

  const fetchDashboardData = async () => {
    if (!user) return

    try {
      // Fetch all public quizzes
      const { data: publicQuizzes } = await supabase
        .from("quizzes")
        .select(`
          *,
          questions (id),
          profiles (username, full_name)
        `)
        .eq("status", "public")
        .eq("working_status", "published")
        .order("created_at", { ascending: false })

      // Fetch user's own quizzes (both public and private)
      const { data: userQuizzes } = await supabase
        .from("quizzes")
        .select(`
          *,
          questions (id),
          profiles (username, full_name)
        `)
        .eq("creator_id", user.id)
        .order("created_at", { ascending: false })

      // Fetch recent popular quizzes
      const { data: popularQuizzes } = await supabase
        .from("quizzes")
        .select(`
          *,
          questions (id),
          profiles (username, full_name)
        `)
        .eq("status", "public")
        .eq("working_status", "published")
        .order("created_at", { ascending: false })
        .limit(6)

      // Fetch recent games
      const { data: gamesData } = await supabase
        .from("game_rooms")
        .select(`
          *,
          quizzes (title),
          game_participants (id)
        `)
        .eq("host_id", user.id)
        .order("created_at", { ascending: false })
        .limit(5)

      // Set state
      setAllQuizzes(publicQuizzes || [])
      setMyQuizzes(userQuizzes || [])
      setRecentQuizzes(popularQuizzes || [])
      setRecentGames(gamesData || [])

      // Calculate stats
      const totalGames = gamesData?.length || 0
      const totalPlayers = gamesData?.reduce((acc, game) => acc + (game.game_participants?.length || 0), 0) || 0

      setStats({
        totalQuizzes: userQuizzes?.length || 0,
        totalGames,
        totalPlayers,
        totalPlays: totalGames, // Simplified for now
      })
    } catch (error) {
      console.error("Error fetching dashboard data:", error)
      toast({
        title: "Error",
        description: "Gagal memuat data dashboard",
        variant: "destructive",
      })
    } finally {
      setDataLoading(false)
    }
  }

  const deleteQuiz = async (quizId: string) => {
    const result = await Swal.fire({
      title: "Hapus Kuis?",
      text: "Kuis dan semua pertanyaannya akan dihapus secara permanen.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#e3342f",
      cancelButtonColor: "#6c757d",
      confirmButtonText: "Ya, hapus",
      cancelButtonText: "Batal",
    })

    if (!result.isConfirmed) return

    try {
      const { error } = await supabase.from("quizzes").delete().eq("id", quizId)
      if (error) throw error

      await Swal.fire({
        title: "Berhasil!",
        text: "Kuis berhasil dihapus.",
        icon: "success",
        timer: 1500,
        showConfirmButton: false,
      })

      fetchDashboardData()
    } catch (err) {
      console.error("Error deleting quiz:", err)
      await Swal.fire({
        title: "Error",
        text: "Gagal menghapus kuis.",
        icon: "error",
      })
    }
  }

  const filteredQuizzes = (quizzes: Quiz[]) => {
    return quizzes.filter((quiz) => {
      const matchesSearch =
        quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        quiz.description?.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesStatus = statusFilter === "all" || quiz.status === statusFilter
      return matchesSearch && matchesStatus
    })
  }

  if (loading || dataLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <Header />
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <LoadingSpinner size="lg" text="Memuat dashboard..." />
        </div>
      </div>
    )
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="relative overflow-hidden bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 rounded-3xl p-8 mb-8 text-white">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
              <div className="mb-6 md:mb-0">
                <h1 className="text-4xl font-bold mb-2">
                  Selamat datang, {profile?.full_name || profile?.username}! 👋
                </h1>
                <p className="text-blue-100 text-lg">Kelola kuis Anda dan ciptakan pengalaman belajar yang menarik</p>
              </div>
              <div className="flex gap-3">
                <Button size="lg" className="bg-white text-purple-600 hover:bg-white/90" asChild>
                  <Link href="/create">
                    <Plus className="w-5 h-5 mr-2" />
                    Buat Kuis
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10 bg-transparent"
                  asChild
                >
                  <Link href="/join">
                    <Users className="w-5 h-5 mr-2" />
                    Join Game
                  </Link>
                </Button>
              </div>
            </div>
          </div>

          {/* Decorative elements */}
          <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/10 rounded-full"></div>
          <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-white/5 rounded-full"></div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Kuis Saya</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalQuizzes}</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Game Dimainkan</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalGames}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Play className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Pemain</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalPlayers}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Popularitas</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalPlays}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card
            className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white hover:shadow-xl transition-all duration-300 cursor-pointer"
            asChild
          >
            <Link href="/create">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Plus className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Buat Kuis Baru</h3>
                    <p className="text-purple-100 text-sm">Mulai membuat kuis interaktif</p>
                  </div>
                </div>
              </CardContent>
            </Link>
          </Card>

          <Card
            className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white hover:shadow-xl transition-all duration-300 cursor-pointer"
            asChild
          >
            <Link href="/host">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Play className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Host Game</h3>
                    <p className="text-blue-100 text-sm">Mulai sesi kuis dengan pemain</p>
                  </div>
                </div>
              </CardContent>
            </Link>
          </Card>

          <Card
            className="border-0 shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white hover:shadow-xl transition-all duration-300 cursor-pointer"
            asChild
          >
            <Link href="/join">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Join Game</h3>
                    <p className="text-green-100 text-sm">Bergabung dengan game lain</p>
                  </div>
                </div>
              </CardContent>
            </Link>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="my-quizzes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="my-quizzes">Kuis Saya</TabsTrigger>
            <TabsTrigger value="all-quizzes">Semua Kuis</TabsTrigger>
            <TabsTrigger value="recent">Terbaru</TabsTrigger>
            <TabsTrigger value="games">Game History</TabsTrigger>
          </TabsList>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4 bg-white/80 backdrop-blur-sm rounded-xl p-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Cari kuis..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-0 bg-white/50"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48 border-0 bg-white/50">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="public">Public</SelectItem>
                <SelectItem value="private">Private</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* My Quizzes Tab */}
          <TabsContent value="my-quizzes" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="w-5 h-5" />
                      Kuis Saya ({myQuizzes.length})
                    </CardTitle>
                    <CardDescription>Kelola semua kuis yang telah Anda buat</CardDescription>
                  </div>
                  <Button asChild>
                    <Link href="/create">
                      <Plus className="w-4 h-4 mr-2" />
                      Buat Baru
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {filteredQuizzes(myQuizzes).length === 0 ? (
                  <div className="text-center py-12">
                    <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">Belum ada kuis</h3>
                    <p className="text-gray-500 mb-6">Mulai membuat kuis pertama Anda</p>
                    <Button asChild>
                      <Link href="/create">
                        <Plus className="w-4 h-4 mr-2" />
                        Buat Kuis Pertama
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredQuizzes(myQuizzes).map((quiz) => (
                      <Card
                        key={quiz.id}
                        className="border-0 shadow-md hover:shadow-lg transition-all duration-300 bg-white"
                      >
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg text-gray-900 mb-2 line-clamp-2">{quiz.title}</h3>
                              <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                                {quiz.description || "Tidak ada deskripsi"}
                              </p>
                            </div>
                            <div className="flex gap-1 ml-2">
                              <Badge variant={quiz.status === "public" ? "default" : "secondary"} className="text-xs">
                                {quiz.status === "public" ? (
                                  <>
                                    <Globe className="w-3 h-3 mr-1" />
                                    Public
                                  </>
                                ) : (
                                  <>
                                    <Lock className="w-3 h-3 mr-1" />
                                    Private
                                  </>
                                )}
                              </Badge>
                            </div>
                          </div>

                          <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                            <span className="flex items-center gap-1">
                              <BookOpen className="w-3 h-3" />
                              {quiz.questions?.length || 0} soal
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {new Date(quiz.created_at).toLocaleDateString("id-ID")}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <Button size="sm" className="flex-1" asChild>
                              <Link href={`/play/${quiz.id}`}>
                                <Play className="w-3 h-3 mr-1" />
                                Main
                              </Link>
                            </Button>
                            <Button size="sm" variant="outline" asChild>
                              <Link href={`/host?quiz=${quiz.id}`}>
                                <Users className="w-3 h-3 mr-1" />
                                Host
                              </Link>
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteQuiz(quiz.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* All Quizzes Tab */}
          <TabsContent value="all-quizzes" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  Semua Kuis Public ({allQuizzes.length})
                </CardTitle>
                <CardDescription>Jelajahi kuis yang dibuat oleh komunitas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredQuizzes(allQuizzes).map((quiz) => (
                    <Card
                      key={quiz.id}
                      className="border-0 shadow-md hover:shadow-lg transition-all duration-300 bg-white"
                    >
                      <CardContent className="p-6">
                        <div className="mb-4">
                          <h3 className="font-semibold text-lg text-gray-900 mb-2 line-clamp-2">{quiz.title}</h3>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                            {quiz.description || "Tidak ada deskripsi"}
                          </p>
                          <p className="text-xs text-gray-500">
                            Oleh: {quiz.profiles?.full_name || quiz.profiles?.username || "Unknown"}
                          </p>
                        </div>

                        <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                          <span className="flex items-center gap-1">
                            <BookOpen className="w-3 h-3" />
                            {quiz.questions?.length || 0} soal
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(quiz.created_at).toLocaleDateString("id-ID")}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button size="sm" className="flex-1" asChild>
                            <Link href={`/play/${quiz.id}`}>
                              <Play className="w-3 h-3 mr-1" />
                              Main
                            </Link>
                          </Button>
                          <Button size="sm" variant="outline" asChild>
                            <Link href={`/host?quiz=${quiz.id}`}>
                              <Users className="w-3 h-3 mr-1" />
                              Host
                            </Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Recent Quizzes Tab */}
          <TabsContent value="recent" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5" />
                  Kuis Terbaru & Populer
                </CardTitle>
                <CardDescription>Kuis terbaru yang sedang trending</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recentQuizzes.map((quiz) => (
                    <Card
                      key={quiz.id}
                      className="border-0 shadow-md hover:shadow-lg transition-all duration-300 bg-white"
                    >
                      <CardContent className="p-6">
                        <div className="mb-4">
                          <h3 className="font-semibold text-lg text-gray-900 mb-2 line-clamp-2">{quiz.title}</h3>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                            {quiz.description || "Tidak ada deskripsi"}
                          </p>
                          <p className="text-xs text-gray-500">
                            Oleh: {quiz.profiles?.full_name || quiz.profiles?.username || "Unknown"}
                          </p>
                        </div>

                        <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                          <span className="flex items-center gap-1">
                            <BookOpen className="w-3 h-3" />
                            {quiz.questions?.length || 0} soal
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Baru
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button size="sm" className="flex-1" asChild>
                            <Link href={`/play/${quiz.id}`}>
                              <Play className="w-3 h-3 mr-1" />
                              Main
                            </Link>
                          </Button>
                          <Button size="sm" variant="outline" asChild>
                            <Link href={`/host?quiz=${quiz.id}`}>
                              <Users className="w-3 h-3 mr-1" />
                              Host
                            </Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Games History Tab */}
          <TabsContent value="games" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  Riwayat Game ({recentGames.length})
                </CardTitle>
                <CardDescription>Game yang baru saja Anda host</CardDescription>
              </CardHeader>
              <CardContent>
                {recentGames.length === 0 ? (
                  <div className="text-center py-12">
                    <Trophy className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">Belum ada game</h3>
                    <p className="text-gray-500 mb-6">Mulai host game pertama Anda</p>
                    <Button asChild>
                      <Link href="/host">
                        <Play className="w-4 h-4 mr-2" />
                        Host Game
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentGames.map((game) => (
                      <Card
                        key={game.id}
                        className="border-0 shadow-sm hover:shadow-md transition-all duration-300 bg-white"
                      >
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-gray-900 mb-1">
                                {game.quizzes?.title || "Unknown Quiz"}
                              </h3>
                              <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                                <span className="flex items-center gap-1">
                                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                                  Kode: {game.room_code}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Users className="w-4 h-4" />
                                  {game.game_participants?.length || 0} pemain
                                </span>
                                <Badge
                                  variant={
                                    game.status === "waiting"
                                      ? "secondary"
                                      : game.status === "playing"
                                        ? "default"
                                        : "outline"
                                  }
                                >
                                  {game.status}
                                </Badge>
                              </div>
                              <p className="text-xs text-gray-500 flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {new Date(game.created_at).toLocaleString("id-ID")}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              {game.status === "waiting" && (
                                <Button size="sm" asChild>
                                  <Link href={`/host/${game.id}`}>
                                    <Play className="w-3 h-3 mr-1" />
                                    Lanjutkan
                                  </Link>
                                </Button>
                              )}
                              {game.status === "finished" && (
                                <Button size="sm" variant="outline" asChild>
                                  <Link href={`/host/${game.id}`}>
                                    <Eye className="w-3 h-3 mr-1" />
                                    Lihat Hasil
                                  </Link>
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
