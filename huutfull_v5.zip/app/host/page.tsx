"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Header } from "@/components/layout/header"
import { LoadingSpinner } from "@/components/layout/loading-spinner"
import { Play, Users, BookOpen, Search, Globe, Lock, Calendar, Clock, Trophy, ArrowRight } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"
import type { Database } from "@/types/database"

type Quiz = Database["public"]["Tables"]["quizzes"]["Row"] & {
  questions: { id: string }[]
  profiles: { username: string; full_name: string } | null
}

export default function HostPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  const [quizzes, setQuizzes] = useState<Quiz[]>([])
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null)
  const [gameMode, setGameMode] = useState<"solo" | "multiplayer">("multiplayer")
  const [searchTerm, setSearchTerm] = useState("")
  const [dataLoading, setDataLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (loading) return
    if (!user) {
      router.push("/auth/login")
      return
    }
    fetchQuizzes()
  }, [user, loading])

  useEffect(() => {
    // Auto-select quiz from URL parameter
    const quizId = searchParams.get("quiz")
    if (quizId && quizzes.length > 0) {
      const quiz = quizzes.find((q) => q.id === quizId)
      if (quiz) {
        setSelectedQuiz(quiz)
      }
    }
  }, [searchParams, quizzes])

  const fetchQuizzes = async () => {
    if (!user) return

    try {
      // Fetch user's published quizzes and public quizzes
      const { data: userQuizzes } = await supabase
        .from("quizzes")
        .select(`
          *,
          questions (id),
          profiles (username, full_name)
        `)
        .eq("creator_id", user.id)
        .eq("working_status", "published")
        .order("created_at", { ascending: false })

      const { data: publicQuizzes } = await supabase
        .from("quizzes")
        .select(`
          *,
          questions (id),
          profiles (username, full_name)
        `)
        .eq("status", "public")
        .eq("working_status", "published")
        .neq("creator_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20)

      const allQuizzes = [...(userQuizzes || []), ...(publicQuizzes || [])]
      setQuizzes(allQuizzes)
    } catch (error) {
      console.error("Error fetching quizzes:", error)
      toast({
        title: "Error",
        description: "Gagal memuat daftar quiz",
        variant: "destructive",
      })
    } finally {
      setDataLoading(false)
    }
  }

  const createGameRoom = async () => {
    if (!selectedQuiz) {
      setError("Pilih quiz terlebih dahulu")
      return
    }

    setCreating(true)
    setError("")

    try {
      // Generate room code
      const roomCode = Math.floor(100000 + Math.random() * 900000).toString()

      // Create game room
      const { data: room, error: roomError } = await supabase
        .from("game_rooms")
        .insert({
          quiz_id: selectedQuiz.id,
          host_id: user!.id,
          room_code: roomCode,
          mode: gameMode,
          status: "waiting",
        })
        .select()
        .single()

      if (roomError) {
        setError("Gagal membuat room game")
        setCreating(false)
        return
      }

      toast({
        title: "Room berhasil dibuat!",
        description: `Kode room: ${roomCode}`,
      })

      // Redirect to host room page
      router.push(`/host/${room.id}`)
    } catch (err) {
      console.error("Error creating game room:", err)
      setError("Terjadi kesalahan yang tidak terduga")
    } finally {
      setCreating(false)
    }
  }

  const filteredQuizzes = quizzes.filter(
    (quiz) =>
      quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quiz.description?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (loading || dataLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <Header />
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <LoadingSpinner size="lg" text="Memuat quiz..." />
        </div>
      </div>
    )
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-3xl p-8 mb-8 text-white">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10">
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Play className="w-8 h-8" />
              </div>
              <h1 className="text-4xl font-bold mb-2">Host Game Quiz</h1>
              <p className="text-blue-100 text-lg">Pilih quiz dan mulai sesi interaktif dengan pemain</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quiz Selection */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  Pilih Quiz ({filteredQuizzes.length})
                </CardTitle>
                <CardDescription>Pilih quiz yang ingin Anda host untuk dimainkan</CardDescription>

                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Cari quiz..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardHeader>
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {filteredQuizzes.length === 0 ? (
                  <div className="text-center py-12">
                    <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">Tidak ada quiz tersedia</h3>
                    <p className="text-gray-500 mb-6">Buat quiz terlebih dahulu untuk memulai game</p>
                    <Button asChild>
                      <a href="/create">Buat Quiz Baru</a>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {filteredQuizzes.map((quiz) => (
                      <Card
                        key={quiz.id}
                        className={`cursor-pointer transition-all duration-300 ${
                          selectedQuiz?.id === quiz.id ? "ring-2 ring-blue-500 bg-blue-50" : "hover:shadow-md bg-white"
                        }`}
                        onClick={() => setSelectedQuiz(quiz)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg text-gray-900 mb-2">{quiz.title}</h3>
                              <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                                {quiz.description || "Tidak ada deskripsi"}
                              </p>
                              <div className="flex items-center gap-4 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                  <BookOpen className="w-3 h-3" />
                                  {quiz.questions?.length || 0} soal
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  {new Date(quiz.created_at).toLocaleDateString("id-ID")}
                                </span>
                                <span className="flex items-center gap-1">
                                  {quiz.creator_id === user?.id
                                    ? "Milik Anda"
                                    : `Oleh ${quiz.profiles?.full_name || quiz.profiles?.username}`}
                                </span>
                              </div>
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <Badge variant={quiz.status === "public" ? "default" : "secondary"}>
                                {quiz.status === "public" ? (
                                  <>
                                    <Globe className="w-3 h-3 mr-1" />
                                    Public
                                  </>
                                ) : (
                                  <>
                                    <Lock className="w-3 h-3 mr-1" />
                                    Private
                                  </>
                                )}
                              </Badge>
                              {selectedQuiz?.id === quiz.id && (
                                <Badge variant="default" className="bg-blue-500">
                                  Terpilih
                                </Badge>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Game Settings */}
          <div className="lg:col-span-1">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Pengaturan Game
                </CardTitle>
                <CardDescription>Atur mode permainan dan mulai sesi</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Selected Quiz Info */}
                {selectedQuiz ? (
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2">Quiz Terpilih</h4>
                    <p className="text-sm text-blue-800 font-medium mb-1">{selectedQuiz.title}</p>
                    <div className="flex items-center gap-3 text-xs text-blue-600">
                      <span className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        {selectedQuiz.questions?.length || 0} soal
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />~{(((selectedQuiz.questions?.length || 0) * 30) / 60).toFixed(0)}{" "}
                        menit
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <p className="text-sm text-gray-600 text-center">Pilih quiz terlebih dahulu</p>
                  </div>
                )}

                {/* Game Mode Selection */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-700">Mode Permainan</label>
                  <Select value={gameMode} onValueChange={(value: "solo" | "multiplayer") => setGameMode(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="solo">
                        <div className="flex items-center gap-2">
                          <Trophy className="w-4 h-4" />
                          <div>
                            <p className="font-medium">Solo Mode</p>
                            <p className="text-xs text-gray-500">Pemain bermain sendiri</p>
                          </div>
                        </div>
                      </SelectItem>
                      <SelectItem value="multiplayer">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4" />
                          <div>
                            <p className="font-medium">Multiplayer Mode</p>
                            <p className="text-xs text-gray-500">Kompetisi real-time</p>
                          </div>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Mode Description */}
                <div className="p-3 bg-gray-50 rounded-lg">
                  <h5 className="font-medium text-gray-900 mb-1">
                    {gameMode === "solo" ? "Solo Mode" : "Multiplayer Mode"}
                  </h5>
                  <p className="text-xs text-gray-600">
                    {gameMode === "solo"
                      ? "Pemain dapat bermain dengan kecepatan mereka sendiri tanpa kompetisi langsung."
                      : "Pemain berkompetisi secara real-time dengan leaderboard langsung dan skor berdasarkan kecepatan."}
                  </p>
                </div>

                {/* Create Room Button */}
                <Button
                  onClick={createGameRoom}
                  disabled={!selectedQuiz || creating}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  size="lg"
                >
                  {creating ? (
                    "Membuat Room..."
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Buat Room Game
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>

                {/* Instructions */}
                <div className="text-xs text-gray-500 space-y-1">
                  <p>• Setelah room dibuat, Anda akan mendapat kode room</p>
                  <p>• Bagikan kode tersebut kepada pemain</p>
                  <p>• Pemain dapat bergabung melalui halaman Join Game</p>
                  <p>• Anda dapat memulai game setelah pemain bergabung</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
