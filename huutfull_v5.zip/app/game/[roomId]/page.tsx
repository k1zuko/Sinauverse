"use client"

import { useState, useEffect, use, useRef, useCallback } from "react"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Trophy, Clock, Users, Home, ChevronLeft, ChevronRight, CheckCircle, BookOpen, Target, Zap } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"

const answerColors = [
  "bg-red-500 hover:bg-red-600",
  "bg-blue-500 hover:bg-blue-600",
  "bg-yellow-500 hover:bg-yellow-600",
  "bg-green-500 hover:bg-green-600",
]

const answerShapes = ["△", "◇", "○", "□"]

export default function GamePage({ params }: { params: Promise<{ roomId: string }> }) {
  const resolvedParams = use(params)
  const { user, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  // Core game state
  const [room, setRoom] = useState<any>(null)
  const [questions, setQuestions] = useState<any[]>([])
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [participants, setParticipants] = useState<any[]>([])
  const [myParticipant, setMyParticipant] = useState<any>(null)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [timeLeft, setTimeLeft] = useState(20)
  const [gameState, setGameState] = useState<"waiting" | "playing" | "finished">("waiting")
  const [hasAnswered, setHasAnswered] = useState(false)
  const [gameMode, setGameMode] = useState<"solo" | "multiplayer" | "practice">("multiplayer")
  const [isFinished, setIsFinished] = useState(false)

  // E-learning style state
  const [answeredQuestions, setAnsweredQuestions] = useState<Set<number>>(new Set())
  const [savedAnswers, setSavedAnswers] = useState<{ [key: number]: number }>({})
  const [canNavigate, setCanNavigate] = useState(false)

  // Refs for preventing stale closures and managing timers
  const gameStateRef = useRef(gameState)
  const currentQuestionRef = useRef(currentQuestion)
  const selectedAnswerRef = useRef(selectedAnswer)
  const showResultRef = useRef(showResult)
  const hasAnsweredRef = useRef(hasAnswered)
  const subscriptionRef = useRef<any>(null)
  const isInitialized = useRef(false)
  const autoAdvanceTimer = useRef<NodeJS.Timeout | null>(null)

  // Update refs when state changes
  useEffect(() => {
    gameStateRef.current = gameState
  }, [gameState])
  useEffect(() => {
    currentQuestionRef.current = currentQuestion
  }, [currentQuestion])
  useEffect(() => {
    selectedAnswerRef.current = selectedAnswer
  }, [selectedAnswer])
  useEffect(() => {
    showResultRef.current = showResult
  }, [showResult])
  useEffect(() => {
    hasAnsweredRef.current = hasAnswered
  }, [hasAnswered])

  // Initialize game data
  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
      return
    }

    if (user && !isInitialized.current) {
      isInitialized.current = true
      initializeGame()
    }

    return () => {
      cleanup()
    }
  }, [user, loading, resolvedParams.roomId])

  // Load saved answers from localStorage
  useEffect(() => {
    if (room && user) {
      const savedKey = `quiz_answers_${room.id}_${user.id}`
      const saved = localStorage.getItem(savedKey)
      if (saved) {
        try {
          const parsedAnswers = JSON.parse(saved)
          setSavedAnswers(parsedAnswers)
          setAnsweredQuestions(new Set(Object.keys(parsedAnswers).map(Number)))
        } catch (error) {
          console.error("Error loading saved answers:", error)
        }
      }
    }
  }, [room, user])

  // Timer for regular game mode
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (gameMode !== "practice" && gameState === "playing" && timeLeft > 0 && !showResult && !canNavigate) {
      timer = setTimeout(() => {
        setTimeLeft((prev) => {
          const newTime = prev - 1
          if (newTime === 0 && !showResultRef.current && !hasAnsweredRef.current) {
            handleTimeUp()
          }
          return newTime
        })
      }, 1000)
    }

    return () => {
      if (timer) clearTimeout(timer)
    }
  }, [timeLeft, gameState, showResult, gameMode, canNavigate])

  const cleanup = useCallback(() => {
    console.log("Cleaning up game page...")

    if (autoAdvanceTimer.current) {
      clearTimeout(autoAdvanceTimer.current)
      autoAdvanceTimer.current = null
    }

    if (subscriptionRef.current) {
      supabase.removeChannel(subscriptionRef.current)
      subscriptionRef.current = null
    }
  }, [])

  const initializeGame = async () => {
    try {
      console.log("Initializing game for room:", resolvedParams.roomId)
      await fetchGameData()
      setupSubscriptions()
    } catch (error) {
      console.error("Error initializing game:", error)
    }
  }

  const fetchGameData = async () => {
    try {
      console.log("Fetching game data...")

      const { data: roomData, error: roomError } = await supabase
        .from("game_rooms")
        .select(`
          *,
          quizzes (
            id,
            title,
            questions (
              id,
              question_text,
              time_limit,
              points,
              order_index,
              answer_options (
                id,
                option_text,
                is_correct,
                option_index
              )
            )
          )
        `)
        .eq("id", resolvedParams.roomId)
        .single()

      if (roomError) {
        console.error("Room error:", roomError)
        toast({
          title: "Error",
          description: "Room tidak ditemukan",
          variant: "destructive",
        })
        router.push("/dashboard")
        return
      }

      console.log("Room data fetched:", roomData)

      setRoom(roomData)
      setGameState(roomData.status)
      setGameMode(roomData.mode || "multiplayer")
      setCurrentQuestion(0) // Always start from first question in e-learning style

      // Sort questions by order
      const sortedQuestions = roomData.quizzes.questions.sort((a: any, b: any) => a.order_index - b.order_index)
      setQuestions(sortedQuestions)

      // Set navigation mode based on game mode
      setCanNavigate(roomData.mode === "practice" || roomData.mode === "solo")

      // Set initial timer
      if (sortedQuestions.length > 0) {
        setTimeLeft(sortedQuestions[0].time_limit || 20)
      }

      // Fetch participants
      await fetchParticipants()
    } catch (error) {
      console.error("Error fetching game data:", error)
    }
  }

  const fetchParticipants = async () => {
    try {
      const { data } = await supabase
        .from("game_participants")
        .select("*")
        .eq("room_id", resolvedParams.roomId)
        .order("score", { ascending: false })

      if (data) {
        setParticipants(data)
        const myData = data.find((p) => p.user_id === user?.id)
        setMyParticipant(myData)
        setIsFinished(myData?.is_finished || false)
      }
    } catch (error) {
      console.error("Error fetching participants:", error)
    }
  }

  const setupSubscriptions = useCallback(() => {
    if (canNavigate) return // No real-time updates needed for e-learning style

    console.log("Setting up real-time subscriptions...")

    if (subscriptionRef.current) {
      supabase.removeChannel(subscriptionRef.current)
    }

    const channel = supabase
      .channel(`game-${resolvedParams.roomId}-${Date.now()}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "game_rooms",
          filter: `id=eq.${resolvedParams.roomId}`,
        },
        (payload) => {
          console.log("Room update received:", payload)
          const newData = payload.new as any

          if (newData.status !== gameStateRef.current) {
            console.log("Game state changed from", gameStateRef.current, "to", newData.status)
            setGameState(newData.status)
          }
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "game_participants",
          filter: `room_id=eq.${resolvedParams.roomId}`,
        },
        () => {
          fetchParticipants()
        },
      )
      .subscribe()

    subscriptionRef.current = channel
  }, [resolvedParams.roomId, canNavigate])

  // Save answer to localStorage and database
  const saveAnswer = async (questionIndex: number, answerIndex: number) => {
    if (!room || !user || !questions[questionIndex]) return

    const question = questions[questionIndex]
    const selectedOption = question.answer_options.find((opt: any) => opt.option_index === answerIndex)
    const isCorrect = selectedOption?.is_correct || false

    // Save to localStorage
    const savedKey = `quiz_answers_${room.id}_${user.id}`
    const newSavedAnswers = { ...savedAnswers, [questionIndex]: answerIndex }
    setSavedAnswers(newSavedAnswers)
    setAnsweredQuestions((prev) => new Set([...prev, questionIndex]))
    localStorage.setItem(savedKey, JSON.stringify(newSavedAnswers))

    // Calculate points
    const timeBonus = canNavigate ? 1 : Math.max(0.1, timeLeft / question.time_limit)
    const points = isCorrect ? Math.floor(question.points * timeBonus) : 0

    try {
      // Save to database
      const { data: existingAnswer } = await supabase
        .from("game_answers")
        .select("id")
        .eq("room_id", resolvedParams.roomId)
        .eq("participant_id", myParticipant?.id)
        .eq("question_id", question.id)
        .maybeSingle()

      if (existingAnswer) {
        await supabase
          .from("game_answers")
          .update({
            selected_option_id: selectedOption?.id,
            is_correct: isCorrect,
            points_earned: points,
            answer_time: canNavigate ? 0 : question.time_limit - timeLeft,
          })
          .eq("id", existingAnswer.id)
      } else {
        await supabase.from("game_answers").insert({
          room_id: resolvedParams.roomId,
          participant_id: myParticipant?.id,
          question_id: question.id,
          selected_option_id: selectedOption?.id,
          is_correct: isCorrect,
          points_earned: points,
          answer_time: canNavigate ? 0 : question.time_limit - timeLeft,
        })
      }

      // Update participant score if correct
      if (isCorrect && myParticipant) {
        await supabase
          .from("game_participants")
          .update({ score: myParticipant.score + points })
          .eq("id", myParticipant.id)
      }
    } catch (error) {
      console.error("Error saving answer:", error)
    }
  }

  const handleAnswerSelect = async (answerIndex: number) => {
    if (hasAnswered || isFinished) return

    setSelectedAnswer(answerIndex)
    setHasAnswered(true)

    // Save answer
    await saveAnswer(currentQuestion, answerIndex)

    if (canNavigate) {
      // E-learning style: just show result, allow navigation
      setShowResult(true)
    } else {
      // Traditional style: show result and auto-advance
      setShowResult(true)
      autoAdvanceTimer.current = setTimeout(() => {
        nextQuestion()
      }, 3000)
    }
  }

  const handleTimeUp = useCallback(() => {
    if (!showResultRef.current && !hasAnsweredRef.current) {
      console.log("⏰ Time up, showing result")
      setShowResult(true)
      setHasAnswered(true)

      if (!canNavigate) {
        autoAdvanceTimer.current = setTimeout(() => {
          nextQuestion()
        }, 2000)
      }
    }
  }, [canNavigate])

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      resetQuestionState()
    } else {
      finishGame()
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      resetQuestionState()
    }
  }

  const goToQuestion = (questionIndex: number) => {
    if (questionIndex >= 0 && questionIndex < questions.length) {
      setCurrentQuestion(questionIndex)
      resetQuestionState()
    }
  }

  const resetQuestionState = () => {
    setSelectedAnswer(null)
    setShowResult(false)
    setHasAnswered(false)

    if (questions[currentQuestion]) {
      setTimeLeft(questions[currentQuestion].time_limit || 20)
    }

    // Load saved answer if exists
    if (savedAnswers[currentQuestion] !== undefined) {
      setSelectedAnswer(savedAnswers[currentQuestion])
      setHasAnswered(true)
      if (canNavigate) {
        setShowResult(true)
      }
    }
  }

  const finishGame = async () => {
    if (!myParticipant) return

    try {
      // Calculate total score
      const { data: answers } = await supabase
        .from("game_answers")
        .select("points_earned")
        .eq("room_id", resolvedParams.roomId)
        .eq("participant_id", myParticipant.id)

      const totalScore = answers?.reduce((acc, answer) => acc + answer.points_earned, 0) || 0

      // Update participant as finished
      await supabase
        .from("game_participants")
        .update({
          is_finished: true,
          score: totalScore,
          finished_at: new Date().toISOString(),
        })
        .eq("id", myParticipant.id)

      setIsFinished(true)
      setGameState("finished")

      toast({
        title: "Quiz Selesai!",
        description: `Skor akhir Anda: ${totalScore} poin`,
      })

      // Clear saved answers
      const savedKey = `quiz_answers_${room.id}_${user.id}`
      localStorage.removeItem(savedKey)
    } catch (error) {
      console.error("Error finishing game:", error)
      toast({
        title: "Error",
        description: "Gagal menyelesaikan quiz",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-2xl">Loading...</div>
      </div>
    )
  }

  if (!room || !questions.length) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-2xl">Loading game...</div>
      </div>
    )
  }

  if (gameState === "waiting") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center border-0 shadow-2xl">
          <CardContent className="p-8">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-4 text-white">Menunggu Host</h2>
            <p className="text-purple-100 mb-6">Game akan dimulai sebentar lagi...</p>
            <div className="animate-pulse">
              <div className="w-12 h-12 bg-white/20 rounded-full mx-auto"></div>
            </div>
            <div className="mt-6 p-4 bg-white/10 rounded-lg">
              <p className="text-sm text-purple-100">
                Room: {room.room_code} | Mode: {gameMode}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (gameState === "finished" || isFinished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-500 to-blue-500 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          <Card className="border-0 shadow-2xl">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                <h2 className="text-3xl font-bold mb-6">Quiz Selesai!</h2>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                {/* Leaderboard */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold mb-4">🏆 Leaderboard Final</h3>
                  <div className="space-y-3">
                    {participants.slice(0, 5).map((participant, index) => (
                      <div key={participant.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                              index === 0
                                ? "bg-yellow-500"
                                : index === 1
                                  ? "bg-gray-400"
                                  : index === 2
                                    ? "bg-orange-500"
                                    : "bg-gray-300"
                            }`}
                          >
                            {index + 1}
                          </div>
                          <span className="font-semibold">{participant.nickname}</span>
                          {index === 0 && <span className="text-yellow-600">👑</span>}
                        </div>
                        <span className="font-bold">{participant.score.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Question Recap */}
                <div className="bg-gray-50 rounded-lg p-6 max-h-96 overflow-y-auto">
                  <h3 className="text-xl font-semibold mb-4">📝 Rekap Jawaban</h3>
                  <div className="space-y-4">
                    {questions.map((question, qIndex) => {
                      const myAnswer = savedAnswers[qIndex]
                      const correctAnswer = question.answer_options.find((opt: any) => opt.is_correct)
                      const mySelectedOption = question.answer_options.find((opt: any) => opt.option_index === myAnswer)

                      return (
                        <div key={question.id} className="bg-white rounded-lg p-4 border">
                          <div className="flex items-start gap-2 mb-3">
                            <Badge variant="secondary" className="text-xs">
                              {qIndex + 1}
                            </Badge>
                            <p className="text-sm font-medium">{question.question_text}</p>
                          </div>

                          <div className="ml-6 space-y-2 text-xs">
                            <div className="flex items-center gap-2">
                              <span className="text-green-600 font-semibold">✓ Benar:</span>
                              <span>{correctAnswer?.option_text}</span>
                            </div>

                            {myAnswer !== undefined && (
                              <div className="flex items-center gap-2">
                                <span
                                  className={`font-semibold ${
                                    mySelectedOption?.is_correct ? "text-green-600" : "text-red-600"
                                  }`}
                                >
                                  {mySelectedOption?.is_correct ? "✓" : "✗"} Jawaban Anda:
                                </span>
                                <span>{mySelectedOption?.option_text}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* My Final Position */}
              {myParticipant && (
                <div className="bg-blue-50 rounded-lg p-4 mb-6">
                  <h4 className="font-semibold text-blue-800 mb-2">Posisi Anda</h4>
                  <div className="flex items-center justify-center gap-4">
                    <div className="text-2xl font-bold text-blue-600">
                      #{participants.findIndex((p) => p.id === myParticipant.id) + 1}
                    </div>
                    <div className="text-lg text-blue-700">{myParticipant.score.toLocaleString()} poin</div>
                  </div>
                </div>
              )}

              <div className="text-center">
                <Button onClick={() => router.push("/dashboard")} className="bg-blue-600 hover:bg-blue-700">
                  <Home className="w-4 h-4 mr-2" />
                  Kembali ke Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Make sure we have a valid question
  if (!questions[currentQuestion]) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-2xl">Loading question...</div>
      </div>
    )
  }

  const question = questions[currentQuestion]
  const progress = ((currentQuestion + 1) / questions.length) * 100
  const allQuestionsAnswered = questions.every((_, index) => answeredQuestions.has(index))

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-6xl mx-auto p-4">
        {/* Header */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">{room.quizzes.title}</h1>
                <p className="text-sm text-gray-600">
                  Pertanyaan {currentQuestion + 1} dari {questions.length}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">{participants.length}</span>
              </div>
              {!canNavigate && (
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-orange-500" />
                  <span className="text-2xl font-bold text-orange-600">{timeLeft}</span>
                </div>
              )}
            </div>
          </div>
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between text-xs text-gray-500 mt-2">
            <span>Progress: {Math.round(progress)}%</span>
            <span>
              Dijawab: {answeredQuestions.size}/{questions.length}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Question Content */}
          <div className="lg:col-span-3">
            <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
              <CardContent className="p-8">
                {/* Question */}
                <div className="text-center mb-8">
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <Badge variant="outline" className="text-sm">
                      Soal {currentQuestion + 1}
                    </Badge>
                    {answeredQuestions.has(currentQuestion) && (
                      <Badge variant="default" className="bg-green-500">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Terjawab
                      </Badge>
                    )}
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6 leading-tight">
                    {question.question_text}
                  </h2>
                </div>

                {/* Answer Options */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto mb-8">
                  {question.answer_options
                    .sort((a: any, b: any) => a.option_index - b.option_index)
                    .map((option: any, index: number) => {
                      const isSelected = selectedAnswer === index
                      const isCorrect = option.is_correct
                      const savedAnswer = savedAnswers[currentQuestion]
                      const wasPreviouslySelected = savedAnswer === index

                      let buttonClass = `${answerColors[index]} text-white text-lg font-semibold py-6 px-6 rounded-2xl transition-all duration-300 transform hover:scale-105 relative overflow-hidden min-h-[80px] flex items-center justify-center`

                      if (showResult) {
                        if (isCorrect) {
                          buttonClass =
                            "bg-green-500 text-white text-lg font-semibold py-6 px-6 rounded-2xl relative overflow-hidden ring-4 ring-green-300 animate-pulse min-h-[80px] flex items-center justify-center"
                        } else if (isSelected || wasPreviouslySelected) {
                          buttonClass =
                            "bg-red-500 text-white text-lg font-semibold py-6 px-6 rounded-2xl relative overflow-hidden ring-4 ring-red-300 min-h-[80px] flex items-center justify-center"
                        } else {
                          buttonClass =
                            "bg-gray-400 text-white text-lg font-semibold py-6 px-6 rounded-2xl relative overflow-hidden opacity-50 min-h-[80px] flex items-center justify-center"
                        }
                      } else if (wasPreviouslySelected) {
                        buttonClass += " ring-4 ring-white shadow-2xl scale-105"
                      }

                      return (
                        <Button
                          key={`${question.id}-${option.id}`}
                          onClick={() => handleAnswerSelect(index)}
                          disabled={hasAnswered || isFinished}
                          className={buttonClass}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{answerShapes[index]}</span>
                            <span className="flex-1 text-left">{option.option_text}</span>
                            {(isSelected || wasPreviouslySelected) && showResult && (
                              <CheckCircle className="w-5 h-5 ml-2" />
                            )}
                          </div>
                        </Button>
                      )
                    })}
                </div>

                {/* Result Display */}
                {showResult && (
                  <div className="text-center mb-6">
                    <div className="p-4 rounded-xl bg-gradient-to-r from-blue-50 to-purple-50 border">
                      {selectedAnswer !== null && (
                        <div className="mb-3">
                          {questions[currentQuestion].answer_options[selectedAnswer]?.is_correct ? (
                            <div className="flex items-center justify-center gap-2 text-green-600 font-bold text-xl">
                              <Target className="w-6 h-6" />
                              Benar! Excellent!
                            </div>
                          ) : (
                            <div className="flex items-center justify-center gap-2 text-red-600 font-bold text-xl">
                              <Zap className="w-6 h-6" />
                              Kurang tepat, coba lagi!
                            </div>
                          )}
                        </div>
                      )}
                      {canNavigate && (
                        <p className="text-sm text-gray-600">Gunakan navigasi untuk melanjutkan ke soal berikutnya</p>
                      )}
                    </div>
                  </div>
                )}

                {/* Navigation Controls (E-learning style) */}
                {canNavigate && (
                  <div className="flex justify-between items-center mt-8">
                    <Button
                      onClick={prevQuestion}
                      disabled={currentQuestion === 0}
                      variant="outline"
                      className="flex items-center gap-2 bg-transparent"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Sebelumnya
                    </Button>

                    <div className="flex gap-2">
                      {allQuestionsAnswered && !isFinished && (
                        <Button onClick={finishGame} className="bg-green-600 hover:bg-green-700 px-8">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Selesai Quiz
                        </Button>
                      )}
                    </div>

                    <Button
                      onClick={nextQuestion}
                      disabled={currentQuestion === questions.length - 1}
                      variant="outline"
                      className="flex items-center gap-2 bg-transparent"
                    >
                      Selanjutnya
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                )}

                {/* Question Navigation Grid */}
                {canNavigate && (
                  <div className="flex justify-center mt-6">
                    <div className="flex flex-wrap gap-2 max-w-md">
                      {questions.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => goToQuestion(index)}
                          className={`w-10 h-10 rounded-lg text-sm font-bold transition-all ${
                            index === currentQuestion
                              ? "bg-blue-500 text-white"
                              : answeredQuestions.has(index)
                                ? "bg-green-500 text-white"
                                : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                          }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* My Score */}
                {myParticipant && (
                  <div className="mt-8 text-center">
                    <div className="inline-flex items-center gap-2 bg-yellow-100 text-yellow-800 px-6 py-3 rounded-full font-bold">
                      <Trophy className="w-5 h-5" />
                      Poin Saya: {myParticipant.score.toLocaleString()}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Leaderboard */}
            <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  Leaderboard
                </h3>
                <div className="space-y-3">
                  {participants.slice(0, 8).map((participant, index) => (
                    <div
                      key={participant.id}
                      className={`flex items-center justify-between p-3 rounded-lg ${
                        participant.id === myParticipant?.id ? "bg-blue-50 border border-blue-200" : "bg-gray-50"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                            index === 0
                              ? "bg-yellow-500"
                              : index === 1
                                ? "bg-gray-400"
                                : index === 2
                                  ? "bg-orange-500"
                                  : "bg-gray-300"
                          }`}
                        >
                          {index + 1}
                        </div>
                        <span className="text-sm font-medium truncate">{participant.nickname}</span>
                      </div>
                      <span className="text-sm font-bold">{participant.score.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Progress Summary */}
            <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Progress</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Soal Dijawab</span>
                    <span className="font-bold">
                      {answeredQuestions.size}/{questions.length}
                    </span>
                  </div>
                  <Progress value={(answeredQuestions.size / questions.length) * 100} className="h-2" />
                  <div className="text-xs text-gray-500 text-center">
                    {Math.round((answeredQuestions.size / questions.length) * 100)}% selesai
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
