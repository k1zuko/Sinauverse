"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, Save, Play, ArrowLeft, Globe, Lock, FileText, Eye } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"

interface Question {
  id?: string
  question_text: string
  time_limit: number
  points: number
  options: {
    option_text: string
    is_correct: boolean
  }[]
}

export default function CreateQuizPage() {
  const { user, profile, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")

  const [quizData, setQuizData] = useState({
    title: "",
    description: "",
    status: "public" as "public" | "private",
    working_status: "draft" as "draft" | "published",
    category: "general",
  })

  const [questions, setQuestions] = useState<Question[]>([
    {
      question_text: "",
      time_limit: 20,
      points: 1000,
      options: [
        { option_text: "", is_correct: false },
        { option_text: "", is_correct: false },
        { option_text: "", is_correct: false },
        { option_text: "", is_correct: false },
      ],
    },
  ])

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
    }
  }, [user, loading])

  const addQuestion = () => {
    setQuestions([
      ...questions,
      {
        question_text: "",
        time_limit: 20,
        points: 1000,
        options: [
          { option_text: "", is_correct: false },
          { option_text: "", is_correct: false },
          { option_text: "", is_correct: false },
          { option_text: "", is_correct: false },
        ],
      },
    ])
  }

  const removeQuestion = (index: number) => {
    if (questions.length > 1) {
      setQuestions(questions.filter((_, i) => i !== index))
    }
  }

  const updateQuestion = (index: number, field: string, value: any) => {
    const updatedQuestions = [...questions]
    updatedQuestions[index] = { ...updatedQuestions[index], [field]: value }
    setQuestions(updatedQuestions)
  }

  const updateOption = (questionIndex: number, optionIndex: number, field: string, value: any) => {
    const updatedQuestions = [...questions]
    updatedQuestions[questionIndex].options[optionIndex] = {
      ...updatedQuestions[questionIndex].options[optionIndex],
      [field]: value,
    }

    if (field === "is_correct" && value === true) {
      updatedQuestions[questionIndex].options.forEach((option, i) => {
        if (i !== optionIndex) {
          option.is_correct = false
        }
      })
    }

    setQuestions(updatedQuestions)
  }

  const validateQuiz = () => {
    if (!quizData.title.trim()) {
      setError("Judul quiz harus diisi")
      return false
    }

    for (let i = 0; i < questions.length; i++) {
      const question = questions[i]
      if (!question.question_text.trim()) {
        setError(`Pertanyaan ${i + 1} harus diisi`)
        return false
      }

      const hasCorrectAnswer = question.options.some((option) => option.is_correct)
      if (!hasCorrectAnswer) {
        setError(`Pertanyaan ${i + 1} harus memiliki jawaban yang benar`)
        return false
      }

      const emptyOptions = question.options.filter((option) => !option.option_text.trim())
      if (emptyOptions.length > 0) {
        setError(`Semua pilihan jawaban pada pertanyaan ${i + 1} harus diisi`)
        return false
      }
    }

    return true
  }

  const saveQuiz = async (publishNow = false) => {
    if (!validateQuiz()) return

    setSaving(true)
    setError("")

    const finalWorkingStatus = publishNow ? "published" : quizData.working_status

    try {
      const { data: quiz, error: quizError } = await supabase
        .from("quizzes")
        .insert({
          title: quizData.title,
          description: quizData.description,
          creator_id: user!.id,
          status: quizData.status,
          working_status: finalWorkingStatus,
          category: quizData.category,
        })
        .select()
        .single()

      if (quizError) {
        setError("Gagal menyimpan quiz")
        setSaving(false)
        return
      }

      for (let i = 0; i < questions.length; i++) {
        const question = questions[i]

        const { data: questionData, error: questionError } = await supabase
          .from("questions")
          .insert({
            quiz_id: quiz.id,
            question_text: question.question_text,
            time_limit: question.time_limit,
            points: question.points,
            order_index: i + 1,
          })
          .select()
          .single()

        if (questionError) {
          setError(`Gagal menyimpan pertanyaan ${i + 1}`)
          setSaving(false)
          return
        }

        const optionsData = question.options.map((option, optionIndex) => ({
          question_id: questionData.id,
          option_text: option.option_text,
          is_correct: option.is_correct,
          option_index: optionIndex,
        }))

        const { error: optionsError } = await supabase.from("answer_options").insert(optionsData)

        if (optionsError) {
          setError(`Gagal menyimpan pilihan jawaban untuk pertanyaan ${i + 1}`)
          setSaving(false)
          return
        }
      }

      toast({
        title: publishNow ? "Quiz berhasil dipublikasi!" : "Quiz berhasil disimpan!",
        description: `Quiz "${quizData.title}" telah ${publishNow ? "dipublikasi" : "disimpan sebagai draft"} dengan ${questions.length} pertanyaan`,
      })

      router.push("/dashboard")
    } catch (err) {
      setError("Terjadi kesalahan yang tidak terduga")
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-2xl">Loading...</div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-4">
              <Link href="/dashboard" className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-5 h-5" />
                Kembali
              </Link>
              <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-bold text-xl text-gray-900">Buat Quiz Baru</span>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={quizData.status === "public" ? "default" : "secondary"}>
                    {quizData.status === "public" ? (
                      <>
                        <Globe className="w-3 h-3 mr-1" />
                        Public
                      </>
                    ) : (
                      <>
                        <Lock className="w-3 h-3 mr-1" />
                        Private
                      </>
                    )}
                  </Badge>
                  <Badge variant={quizData.working_status === "published" ? "default" : "outline"}>
                    {quizData.working_status === "published" ? (
                      <>
                        <Eye className="w-3 h-3 mr-1" />
                        Published
                      </>
                    ) : (
                      <>
                        <FileText className="w-3 h-3 mr-1" />
                        Draft
                      </>
                    )}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-gray-700">Hi, {profile?.username}</span>
              <Button onClick={() => saveQuiz(false)} disabled={saving} variant="outline">
                <Save className="w-4 h-4 mr-2" />
                {saving ? "Menyimpan..." : "Simpan Draft"}
              </Button>
              <Button onClick={() => saveQuiz(true)} disabled={saving} className="bg-purple-600 hover:bg-purple-700">
                <Play className="w-4 h-4 mr-2" />
                {saving ? "Mempublikasi..." : "Publikasi Quiz"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Quiz Settings */}
        <Card className="mb-8 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Pengaturan Quiz</CardTitle>
            <CardDescription>Atur informasi dasar dan pengaturan quiz Anda</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="title">Judul Quiz *</Label>
                <Input
                  id="title"
                  placeholder="Masukkan judul quiz yang menarik"
                  value={quizData.title}
                  onChange={(e) => setQuizData({ ...quizData, title: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Kategori</Label>
                <Select
                  value={quizData.category}
                  onValueChange={(value) => setQuizData({ ...quizData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">Umum</SelectItem>
                    <SelectItem value="education">Pendidikan</SelectItem>
                    <SelectItem value="science">Sains</SelectItem>
                    <SelectItem value="history">Sejarah</SelectItem>
                    <SelectItem value="sports">Olahraga</SelectItem>
                    <SelectItem value="entertainment">Hiburan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Deskripsi</Label>
              <Textarea
                id="description"
                placeholder="Jelaskan tentang quiz ini..."
                value={quizData.description}
                onChange={(e) => setQuizData({ ...quizData, description: e.target.value })}
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Visibilitas Quiz</Label>
                    <p className="text-sm text-gray-500">
                      {quizData.status === "public"
                        ? "Semua orang dapat melihat dan memainkan quiz ini"
                        : "Hanya Anda yang dapat melihat quiz ini"}
                    </p>
                  </div>
                  <Switch
                    checked={quizData.status === "public"}
                    onCheckedChange={(checked) => setQuizData({ ...quizData, status: checked ? "public" : "private" })}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Status Publikasi</Label>
                    <p className="text-sm text-gray-500">
                      {quizData.working_status === "published" ? "Quiz siap dimainkan" : "Simpan sebagai draft"}
                    </p>
                  </div>
                  <Switch
                    checked={quizData.working_status === "published"}
                    onCheckedChange={(checked) =>
                      setQuizData({ ...quizData, working_status: checked ? "published" : "draft" })
                    }
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Questions */}
        <div className="space-y-6">
          {questions.map((question, questionIndex) => (
            <Card key={questionIndex} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                      <span className="text-purple-600 font-bold">{questionIndex + 1}</span>
                    </div>
                    Pertanyaan {questionIndex + 1}
                  </CardTitle>
                  {questions.length > 1 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeQuestion(questionIndex)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Pertanyaan *</Label>
                  <Textarea
                    placeholder="Tulis pertanyaan Anda di sini..."
                    value={question.question_text}
                    onChange={(e) => updateQuestion(questionIndex, "question_text", e.target.value)}
                    rows={3}
                    className="text-lg"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Waktu (detik)</Label>
                    <Input
                      type="number"
                      min="10"
                      max="120"
                      value={question.time_limit}
                      onChange={(e) => updateQuestion(questionIndex, "time_limit", Number.parseInt(e.target.value))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Poin</Label>
                    <Input
                      type="number"
                      min="100"
                      max="2000"
                      step="100"
                      value={question.points}
                      onChange={(e) => updateQuestion(questionIndex, "points", Number.parseInt(e.target.value))}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <Label>Pilihan Jawaban *</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {question.options.map((option, optionIndex) => (
                      <div
                        key={optionIndex}
                        className={`flex items-center gap-3 p-4 border-2 rounded-xl transition-all ${
                          option.is_correct ? "border-green-500 bg-green-50" : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <input
                          type="radio"
                          name={`correct-${questionIndex}`}
                          checked={option.is_correct}
                          onChange={(e) => updateOption(questionIndex, optionIndex, "is_correct", e.target.checked)}
                          className="text-green-600 w-4 h-4"
                        />
                        <Input
                          placeholder={`Pilihan ${String.fromCharCode(65 + optionIndex)}`}
                          value={option.option_text}
                          onChange={(e) => updateOption(questionIndex, optionIndex, "option_text", e.target.value)}
                          className={`border-0 bg-transparent ${option.is_correct ? "font-semibold" : ""}`}
                        />
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    Pilih jawaban yang benar dengan mencentang radio button
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Add Question Button */}
        <div className="text-center mt-8">
          <Button onClick={addQuestion} variant="outline" size="lg" className="border-dashed border-2 bg-transparent">
            <Plus className="w-5 h-5 mr-2" />
            Tambah Pertanyaan
          </Button>
        </div>

        {/* Save Buttons */}
        <div className="flex justify-center gap-4 mt-8 pb-8">
          <Button
            onClick={() => saveQuiz(false)}
            disabled={saving}
            size="lg"
            variant="outline"
            className="min-w-[150px]"
          >
            <Save className="w-5 h-5 mr-2" />
            {saving ? "Menyimpan..." : "Simpan Draft"}
          </Button>
          <Button
            onClick={() => saveQuiz(true)}
            disabled={saving}
            size="lg"
            className="bg-purple-600 hover:bg-purple-700 min-w-[150px]"
          >
            <Play className="w-5 h-5 mr-2" />
            {saving ? "Mempublikasi..." : "Publikasi Quiz"}
          </Button>
        </div>
      </div>
    </div>
  )
}
