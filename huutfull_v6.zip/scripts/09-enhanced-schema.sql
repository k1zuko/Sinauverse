-- Enhanced schema for Kahoot-like quiz application
-- Add roles, avatars, game modes, and detailed statistics

-- Add role enum if not exists
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('host', 'player');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Add game mode enum if not exists
DO $$ BEGIN
    CREATE TYPE game_mode AS ENUM ('classic', 'practice');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Update profiles table with enhanced fields
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS role user_role DEFAULT 'player',
ADD COLUMN IF NOT EXISTS avatar_seed TEXT DEFAULT '',
ADD COLUMN IF NOT EXISTS total_games_played INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_score INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS best_score INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS created_quizzes INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS hosted_games INTEGER DEFAULT 0;

-- Update quizzes table with game mode
ALTER TABLE quizzes 
ADD COLUMN IF NOT EXISTS game_mode game_mode DEFAULT 'classic',
ADD COLUMN IF NOT EXISTS total_time_limit INTEGER DEFAULT 0, -- for practice mode
ADD COLUMN IF NOT EXISTS allow_back_navigation BOOLEAN DEFAULT false, -- for practice mode
ADD COLUMN IF NOT EXISTS show_correct_answer BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS randomize_questions BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS randomize_options BOOLEAN DEFAULT false;

-- Update game_rooms table
ALTER TABLE game_rooms 
ADD COLUMN IF NOT EXISTS game_mode game_mode DEFAULT 'classic',
ADD COLUMN IF NOT EXISTS max_participants INTEGER DEFAULT 50,
ADD COLUMN IF NOT EXISTS allow_late_join BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS show_leaderboard BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS auto_advance BOOLEAN DEFAULT true;

-- Update game_participants table
ALTER TABLE game_participants 
ADD COLUMN IF NOT EXISTS avatar_seed TEXT DEFAULT '',
ADD COLUMN IF NOT EXISTS current_question INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS time_spent INTEGER DEFAULT 0, -- total time spent in seconds
ADD COLUMN IF NOT EXISTS correct_answers INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS wrong_answers INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS fastest_answer_time INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS position INTEGER DEFAULT 0; -- final position in game

-- Create game_statistics table for detailed analytics
CREATE TABLE IF NOT EXISTS game_statistics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    room_id UUID REFERENCES game_rooms(id) ON DELETE CASCADE,
    participant_id UUID REFERENCES game_participants(id) ON DELETE CASCADE,
    question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
    question_order INTEGER NOT NULL,
    answer_time INTEGER NOT NULL, -- time taken to answer in seconds
    is_correct BOOLEAN NOT NULL,
    points_earned INTEGER DEFAULT 0,
    selected_option_index INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_achievements table
CREATE TABLE IF NOT EXISTS user_achievements (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    achievement_type TEXT NOT NULL, -- 'first_game', 'high_scorer', 'regular_player', etc.
    achievement_data JSONB DEFAULT '{}',
    earned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, achievement_type)
);

-- Create quiz_analytics table
CREATE TABLE IF NOT EXISTS quiz_analytics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    quiz_id UUID REFERENCES quizzes(id) ON DELETE CASCADE,
    total_plays INTEGER DEFAULT 0,
    total_participants INTEGER DEFAULT 0,
    average_score DECIMAL(10,2) DEFAULT 0,
    average_completion_time INTEGER DEFAULT 0,
    most_difficult_question_id UUID REFERENCES questions(id),
    easiest_question_id UUID REFERENCES questions(id),
    last_played_at TIMESTAMP WITH TIME ZONE,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_game_statistics_room_id ON game_statistics(room_id);
CREATE INDEX IF NOT EXISTS idx_game_statistics_participant_id ON game_statistics(participant_id);
CREATE INDEX IF NOT EXISTS idx_game_statistics_question_id ON game_statistics(question_id);
CREATE INDEX IF NOT EXISTS idx_user_achievements_user_id ON user_achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_quiz_analytics_quiz_id ON quiz_analytics(quiz_id);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_game_rooms_game_mode ON game_rooms(game_mode);
CREATE INDEX IF NOT EXISTS idx_quizzes_game_mode ON quizzes(game_mode);

-- Update RLS policies for new tables
ALTER TABLE game_statistics ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_analytics ENABLE ROW LEVEL SECURITY;

-- Game statistics policies
CREATE POLICY "Users can view game statistics for their games" ON game_statistics
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM game_participants gp 
            WHERE gp.id = participant_id AND gp.user_id = auth.uid()
        ) OR
        EXISTS (
            SELECT 1 FROM game_rooms gr 
            WHERE gr.id = room_id AND gr.host_id = auth.uid()
        )
    );

CREATE POLICY "System can insert game statistics" ON game_statistics
    FOR INSERT WITH CHECK (true);

-- User achievements policies
CREATE POLICY "Users can view their own achievements" ON user_achievements
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "System can manage achievements" ON user_achievements
    FOR ALL USING (true);

-- Quiz analytics policies
CREATE POLICY "Quiz creators can view analytics" ON quiz_analytics
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM quizzes q 
            WHERE q.id = quiz_id AND q.creator_id = auth.uid()
        )
    );

CREATE POLICY "System can manage quiz analytics" ON quiz_analytics
    FOR ALL USING (true);

-- Function to generate avatar seed
CREATE OR REPLACE FUNCTION generate_avatar_seed()
RETURNS TEXT AS $$
BEGIN
    RETURN substring(md5(random()::text) from 1 for 8);
END;
$$ LANGUAGE plpgsql;

-- Function to update user statistics
CREATE OR REPLACE FUNCTION update_user_statistics()
RETURNS TRIGGER AS $$
BEGIN
    -- Update profile statistics when game participation ends
    IF TG_OP = 'UPDATE' AND OLD.score != NEW.score THEN
        UPDATE profiles 
        SET 
            total_score = total_score + (NEW.score - OLD.score),
            best_score = GREATEST(best_score, NEW.score)
        WHERE id = NEW.user_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for user statistics
DROP TRIGGER IF EXISTS trigger_update_user_statistics ON game_participants;
CREATE TRIGGER trigger_update_user_statistics
    AFTER UPDATE ON game_participants
    FOR EACH ROW
    EXECUTE FUNCTION update_user_statistics();

-- Function to award achievements
CREATE OR REPLACE FUNCTION check_and_award_achievements(user_uuid UUID)
RETURNS VOID AS $$
DECLARE
    games_played INTEGER;
    total_score INTEGER;
    best_score INTEGER;
BEGIN
    -- Get user stats
    SELECT total_games_played, p.total_score, p.best_score 
    INTO games_played, total_score, best_score
    FROM profiles p WHERE id = user_uuid;
    
    -- Award first game achievement
    IF games_played >= 1 THEN
        INSERT INTO user_achievements (user_id, achievement_type, achievement_data)
        VALUES (user_uuid, 'first_game', '{"description": "Played first game"}')
        ON CONFLICT (user_id, achievement_type) DO NOTHING;
    END IF;
    
    -- Award regular player achievement
    IF games_played >= 10 THEN
        INSERT INTO user_achievements (user_id, achievement_type, achievement_data)
        VALUES (user_uuid, 'regular_player', '{"description": "Played 10+ games"}')
        ON CONFLICT (user_id, achievement_type) DO NOTHING;
    END IF;
    
    -- Award high scorer achievement
    IF best_score >= 1000 THEN
        INSERT INTO user_achievements (user_id, achievement_type, achievement_data)
        VALUES (user_uuid, 'high_scorer', '{"description": "Scored 1000+ points"}')
        ON CONFLICT (user_id, achievement_type) DO NOTHING;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Update existing profiles with avatar seeds
UPDATE profiles 
SET avatar_seed = generate_avatar_seed() 
WHERE avatar_seed = '' OR avatar_seed IS NULL;

-- Update existing game_participants with avatar seeds
UPDATE game_participants 
SET avatar_seed = generate_avatar_seed() 
WHERE avatar_seed = '' OR avatar_seed IS NULL;
