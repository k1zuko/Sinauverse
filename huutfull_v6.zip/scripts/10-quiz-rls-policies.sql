-- Enable RLS for quizzes table
ALTER TABLE quizzes ENABLE ROW LEVEL SECURITY;

-- Policy for SELECT:
-- Allow anyone to view public quizzes
-- Allow authenticated users to view their own quizzes (private or public)
CREATE POLICY "Allow public quizzes to be viewed by anyone" ON quizzes
  FOR SELECT USING (is_public = TRUE);

CREATE POLICY "Allow authenticated users to view their own quizzes" ON quizzes
  FOR SELECT USING (auth.uid() = creator_id);

-- Policy for INSERT:
-- Allow authenticated users to create quizzes
CREATE POLICY "Allow authenticated users to create quizzes" ON quizzes
  FOR INSERT WITH CHECK (auth.uid() = creator_id);

-- Policy for UPDATE:
-- Allow quiz creators to update their own quizzes
CREATE POLICY "Allow quiz creators to update their own quizzes" ON quizzes
  FOR UPDATE USING (auth.uid() = creator_id);

-- Policy for DELETE:
-- Allow quiz creators to delete their own quizzes
CREATE POLICY "Allow quiz creators to delete their own quizzes" ON quizzes
  FOR DELETE USING (auth.uid() = creator_id);
