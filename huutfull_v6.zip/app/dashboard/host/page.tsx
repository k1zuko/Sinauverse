"use client"

import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { LoadingSpinner } from "@/components/layout/loading-spinner"
import { AvatarGenerator } from "@/components/ui/avatar-generator"
import { Plus, Play, Users, Trophy, Edit, Trash2, Calendar, BarChart3, Clock, Target } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import type { Database } from "@/types/database"

type Quiz = Database["public"]["Tables"]["quizzes"]["Row"] & {
  questions: { id: string }[]
}

type GameRoom = Database["public"]["Tables"]["game_rooms"]["Row"] & {
  quizzes: { title: string } | null
  game_participants: { id: string; nickname: string; avatar_seed: string }[]
}

export default function HostDashboardPage() {
  const { user, profile, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [quizzes, setQuizzes] = useState<Quiz[]>([])
  const [activeGames, setActiveGames] = useState<GameRoom[]>([])
  const [recentGames, setRecentGames] = useState<GameRoom[]>([])
  const [stats, setStats] = useState({
    totalQuizzes: 0,
    totalGamesHosted: 0,
    totalPlayers: 0,
    avgPlayersPerGame: 0,
  })
  const [dataLoading, setDataLoading] = useState(true)

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
      return
    }

    if (!loading && user && profile?.role !== "host") {
      router.push("/dashboard/player")
      return
    }

    if (user && profile?.role === "host") {
      fetchHostData()
    }
  }, [user, profile, loading, router])

  const fetchHostData = async () => {
    if (!user) return

    try {
      // Fetch host's quizzes
      const { data: quizzesData } = await supabase
        .from("quizzes")
        .select(`
          *,
          questions (id)
        `)
        .eq("creator_id", user.id)
        .order("created_at", { ascending: false })

      if (quizzesData) {
        setQuizzes(quizzesData)
      }

      // Fetch active games
      const { data: activeGamesData } = await supabase
        .from("game_rooms")
        .select(`
          *,
          quizzes (title),
          game_participants (id, nickname, avatar_seed)
        `)
        .eq("host_id", user.id)
        .in("status", ["waiting", "active"])
        .order("created_at", { ascending: false })

      if (activeGamesData) {
        setActiveGames(activeGamesData)
      }

      // Fetch recent completed games
      const { data: recentGamesData } = await supabase
        .from("game_rooms")
        .select(`
          *,
          quizzes (title),
          game_participants (id, nickname, avatar_seed)
        `)
        .eq("host_id", user.id)
        .eq("status", "finished")
        .order("finished_at", { ascending: false })
        .limit(5)

      if (recentGamesData) {
        setRecentGames(recentGamesData)
      }

      // Calculate stats
      const allGames = [...(activeGamesData || []), ...(recentGamesData || [])]
      const totalPlayers = allGames.reduce((acc, game) => acc + (game.game_participants?.length || 0), 0)

      setStats({
        totalQuizzes: quizzesData?.length || 0,
        totalGamesHosted: allGames.length,
        totalPlayers,
        avgPlayersPerGame: allGames.length > 0 ? Math.round(totalPlayers / allGames.length) : 0,
      })
    } catch (error) {
      console.error("Error fetching host data:", error)
      toast({
        title: "Error",
        description: "Gagal memuat data dashboard",
        variant: "destructive",
      })
    } finally {
      setDataLoading(false)
    }
  }

  const deleteQuiz = async (quizId: string) => {
    if (!confirm("Apakah Anda yakin ingin menghapus kuis ini?")) return

    try {
      const { error } = await supabase.from("quizzes").delete().eq("id", quizId)

      if (error) {
        toast({
          title: "Error",
          description: "Gagal menghapus kuis",
          variant: "destructive",
        })
      } else {
        toast({
          title: "Berhasil",
          description: "Kuis berhasil dihapus",
        })
        fetchHostData()
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Terjadi kesalahan saat menghapus kuis",
        variant: "destructive",
      })
    }
  }

  if (loading || dataLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <LoadingSpinner size="lg" text="Memuat dashboard host..." />
        </div>
      </div>
    )
  }

  if (!user || profile?.role !== "host") {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8 flex items-center gap-4">
          <AvatarGenerator seed={profile?.avatar_seed || ""} size={64} />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Selamat datang, Host {profile?.full_name || profile?.username}! 🎯
            </h1>
            <p className="text-gray-600">Kelola kuis Anda dan pantau permainan secara real-time</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Kuis</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalQuizzes}</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Game Dihost</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalGamesHosted}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Play className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Pemain</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalPlayers}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Rata-rata Pemain</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.avgPlayersPerGame}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Games */}
        {activeGames.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-green-600" />
                Game Aktif
              </CardTitle>
              <CardDescription>Game yang sedang berlangsung atau menunggu pemain</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeGames.map((game) => (
                  <div
                    key={game.id}
                    className="flex items-center justify-between p-4 border rounded-lg bg-green-50 border-green-200"
                  >
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{game.quizzes?.title}</h3>
                      <p className="text-sm text-gray-600">
                        Kode: <span className="font-mono font-bold">{game.room_code}</span> •
                        {game.game_participants?.length || 0} pemain • Status:{" "}
                        <span className="capitalize">{game.status}</span>
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        {game.game_participants?.slice(0, 5).map((participant, index) => (
                          <AvatarGenerator
                            key={participant.id}
                            seed={participant.avatar_seed}
                            size={24}
                            className="border-2 border-white"
                          />
                        ))}
                        {(game.game_participants?.length || 0) > 5 && (
                          <span className="text-xs text-gray-500">
                            +{(game.game_participants?.length || 0) - 5} lainnya
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" asChild>
                        <Link href={`/host/${game.id}`}>{game.status === "waiting" ? "Mulai Game" : "Lanjutkan"}</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* My Quizzes */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Kuis Saya</CardTitle>
                  <CardDescription>Kelola kuis yang telah Anda buat</CardDescription>
                </div>
                <Button asChild>
                  <Link href="/create">
                    <Plus className="w-4 h-4 mr-2" />
                    Buat Baru
                  </Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {quizzes.length === 0 ? (
                <div className="text-center py-8">
                  <Trophy className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 mb-4">Belum ada kuis</p>
                  <Button asChild>
                    <Link href="/create">Buat Kuis Pertama</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {quizzes.map((quiz) => (
                    <div
                      key={quiz.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{quiz.title}</h3>
                        <p className="text-sm text-gray-600">
                          {quiz.questions?.length || 0} soal • Mode:{" "}
                          <span className="capitalize">{quiz.game_mode}</span> • Dibuat{" "}
                          {new Date(quiz.created_at).toLocaleDateString("id-ID")}
                        </p>
                        {quiz.description && <p className="text-xs text-gray-500 mt-1">{quiz.description}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button size="sm" asChild>
                          <Link href={`/play/${quiz.id}`}>
                            <Play className="w-4 h-4 mr-1" />
                            Host
                          </Link>
                        </Button>
                        <Button size="sm" variant="outline" asChild>
                          <Link href={`/edit/${quiz.id}`}>
                            <Edit className="w-4 h-4" />
                          </Link>
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteQuiz(quiz.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Games */}
          <Card>
            <CardHeader>
              <CardTitle>Game Terbaru</CardTitle>
              <CardDescription>Riwayat game yang baru saja selesai</CardDescription>
            </CardHeader>
            <CardContent>
              {recentGames.length === 0 ? (
                <div className="text-center py-8">
                  <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Belum ada game yang selesai</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {recentGames.map((game) => (
                    <div
                      key={game.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{game.quizzes?.title}</h3>
                        <p className="text-sm text-gray-600">
                          {game.game_participants?.length || 0} pemain • Mode:{" "}
                          <span className="capitalize">{game.game_mode}</span>
                        </p>
                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                          <Calendar className="w-3 h-3" />
                          {game.finished_at ? new Date(game.finished_at).toLocaleString("id-ID") : "Selesai"}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button size="sm" variant="outline" asChild>
                          <Link href={`/results/${game.id}`}>
                            <BarChart3 className="w-4 h-4 mr-1" />
                            Hasil
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Aksi Cepat Host</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button className="h-20 text-left justify-start bg-transparent hover:bg-gray-50" variant="outline" asChild>
              <Link href="/create">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Plus className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-semibold">Buat Kuis Baru</p>
                    <p className="text-sm text-gray-600">Mulai membuat kuis interaktif</p>
                  </div>
                </div>
              </Link>
            </Button>

            <Button className="h-20 text-left justify-start bg-transparent hover:bg-gray-50" variant="outline" asChild>
              <Link href="/analytics">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-semibold">Analytics</p>
                    <p className="text-sm text-gray-600">Lihat statistik detail</p>
                  </div>
                </div>
              </Link>
            </Button>

            <Button className="h-20 text-left justify-start bg-transparent hover:bg-gray-50" variant="outline" asChild>
              <Link href="/demo">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Play className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="font-semibold">Demo Game</p>
                    <p className="text-sm text-gray-600">Coba fitur demo interaktif</p>
                  </div>
                </div>
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
