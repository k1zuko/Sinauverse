"use client"

import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { LoadingSpinner } from "@/components/layout/loading-spinner"
import { AvatarGenerator } from "@/components/ui/avatar-generator"
import { Play, Users, Trophy, Calendar, Target, Zap, Award, TrendingUp } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import type { Database } from "@/types/database"

type GameParticipation = Database["public"]["Tables"]["game_participants"]["Row"] & {
  game_rooms: {
    id: string
    status: string
    finished_at: string | null
    game_mode: string
    quizzes: { title: string } | null
  } | null
}

export default function PlayerDashboardPage() {
  const { user, profile, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [gameHistory, setGameHistory] = useState<GameParticipation[]>([])
  const [activeGames, setActiveGames] = useState<GameParticipation[]>([])
  const [stats, setStats] = useState({
    totalGamesPlayed: 0,
    totalScore: 0,
    averageScore: 0,
    bestScore: 0,
    classicGames: 0,
    practiceGames: 0,
  })
  const [dataLoading, setDataLoading] = useState(true)

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
      return
    }

    if (!loading && user && profile?.role !== "player") {
      router.push("/dashboard/host")
      return
    }

    if (user && profile?.role === "player") {
      fetchPlayerData()
    }
  }, [user, profile, loading, router])

  const fetchPlayerData = async () => {
    if (!user) return

    try {
      // Fetch player's game participations
      const { data: participationsData } = await supabase
        .from("game_participants")
        .select(`
          *,
          game_rooms (
            id,
            status,
            finished_at,
            game_mode,
            quizzes (title)
          )
        `)
        .eq("user_id", user.id)
        .order("joined_at", { ascending: false })

      if (participationsData) {
        const active = participationsData.filter(
          (p) => p.game_rooms?.status === "waiting" || p.game_rooms?.status === "active",
        )
        const completed = participationsData.filter((p) => p.game_rooms?.status === "finished")

        setActiveGames(active)
        setGameHistory(completed)

        // Calculate stats
        const totalScore = participationsData.reduce((acc, p) => acc + p.score, 0)
        const scores = participationsData.map((p) => p.score).filter((s) => s > 0)
        const bestScore = scores.length > 0 ? Math.max(...scores) : 0
        const averageScore = scores.length > 0 ? Math.round(totalScore / scores.length) : 0

        const classicGames = participationsData.filter((p) => p.game_rooms?.game_mode === "classic").length
        const practiceGames = participationsData.filter((p) => p.game_rooms?.game_mode === "practice").length

        setStats({
          totalGamesPlayed: participationsData.length,
          totalScore,
          averageScore,
          bestScore,
          classicGames,
          practiceGames,
        })
      }
    } catch (error) {
      console.error("Error fetching player data:", error)
      toast({
        title: "Error",
        description: "Gagal memuat data dashboard",
        variant: "destructive",
      })
    } finally {
      setDataLoading(false)
    }
  }

  if (loading || dataLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <LoadingSpinner size="lg" text="Memuat dashboard player..." />
        </div>
      </div>
    )
  }

  if (!user || profile?.role !== "player") {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8 flex items-center gap-4">
          <AvatarGenerator seed={profile?.avatar_seed || ""} size={64} />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Halo, {profile?.full_name || profile?.username}! 🎮</h1>
            <p className="text-gray-600">Siap untuk tantangan quiz berikutnya?</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Game Dimainkan</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalGamesPlayed}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Play className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Skor</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalScore.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Skor Terbaik</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.bestScore.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Award className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Rata-rata Skor</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.averageScore.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Game Mode Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Mode Classic</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.classicGames} game</p>
                  <p className="text-xs text-gray-500">Real-time competitive</p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <Zap className="w-6 h-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Mode Practice</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.practiceGames} game</p>
                  <p className="text-xs text-gray-500">Self-paced learning</p>
                </div>
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-indigo-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Games */}
        {activeGames.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="w-5 h-5 text-green-600" />
                Game Aktif
              </CardTitle>
              <CardDescription>Game yang sedang Anda ikuti</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeGames.map((participation) => (
                  <div
                    key={participation.id}
                    className="flex items-center justify-between p-4 border rounded-lg bg-green-50 border-green-200"
                  >
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{participation.game_rooms?.quizzes?.title}</h3>
                      <p className="text-sm text-gray-600">
                        Mode: <span className="capitalize">{participation.game_rooms?.game_mode}</span> • Status:{" "}
                        <span className="capitalize">{participation.game_rooms?.status}</span> • Skor saat ini:{" "}
                        {participation.score}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" asChild>
                        <Link href={`/game/${participation.game_rooms?.id}`}>
                          {participation.game_rooms?.status === "waiting" ? "Menunggu..." : "Lanjutkan"}
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Games */}
          <Card>
            <CardHeader>
              <CardTitle>Riwayat Game</CardTitle>
              <CardDescription>Game yang baru saja Anda selesaikan</CardDescription>
            </CardHeader>
            <CardContent>
              {gameHistory.length === 0 ? (
                <div className="text-center py-8">
                  <Trophy className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 mb-4">Belum ada game yang dimainkan</p>
                  <Button asChild>
                    <Link href="/join">Ikut Game Pertama</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {gameHistory.slice(0, 10).map((participation) => (
                    <div
                      key={participation.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{participation.game_rooms?.quizzes?.title}</h3>
                        <p className="text-sm text-gray-600">
                          Skor: <span className="font-bold">{participation.score}</span> • Mode:{" "}
                          <span className="capitalize">{participation.game_rooms?.game_mode}</span>
                        </p>
                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                          <Calendar className="w-3 h-3" />
                          {participation.game_rooms?.finished_at
                            ? new Date(participation.game_rooms.finished_at).toLocaleString("id-ID")
                            : "Selesai"}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {participation.score > 0 && (
                          <div className="text-right">
                            <div className="text-lg font-bold text-green-600">{participation.score}</div>
                            <div className="text-xs text-gray-500">poin</div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Achievement & Progress */}
          <Card>
            <CardHeader>
              <CardTitle>Pencapaian</CardTitle>
              <CardDescription>Progress dan milestone Anda</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Games Played Progress */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">Game Dimainkan</span>
                    <span className="text-sm text-gray-500">{stats.totalGamesPlayed}/50</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min((stats.totalGamesPlayed / 50) * 100, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {50 - stats.totalGamesPlayed > 0
                      ? `${50 - stats.totalGamesPlayed} game lagi untuk mencapai milestone`
                      : "Milestone tercapai! 🎉"}
                  </p>
                </div>

                {/* Score Progress */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">Total Skor</span>
                    <span className="text-sm text-gray-500">{stats.totalScore.toLocaleString()}/10,000</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min((stats.totalScore / 10000) * 100, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {10000 - stats.totalScore > 0
                      ? `${(10000 - stats.totalScore).toLocaleString()} poin lagi untuk mencapai milestone`
                      : "Milestone tercapai! 🏆"}
                  </p>
                </div>

                {/* Badges */}
                <div>
                  <h4 className="text-sm font-medium mb-3">Badge</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div
                      className={`text-center p-3 rounded-lg border ${stats.totalGamesPlayed >= 1 ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"}`}
                    >
                      <Play
                        className={`w-6 h-6 mx-auto mb-1 ${stats.totalGamesPlayed >= 1 ? "text-green-600" : "text-gray-400"}`}
                      />
                      <p className="text-xs font-medium">First Game</p>
                    </div>
                    <div
                      className={`text-center p-3 rounded-lg border ${stats.totalGamesPlayed >= 10 ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"}`}
                    >
                      <Users
                        className={`w-6 h-6 mx-auto mb-1 ${stats.totalGamesPlayed >= 10 ? "text-blue-600" : "text-gray-400"}`}
                      />
                      <p className="text-xs font-medium">Regular</p>
                    </div>
                    <div
                      className={`text-center p-3 rounded-lg border ${stats.bestScore >= 1000 ? "bg-yellow-50 border-yellow-200" : "bg-gray-50 border-gray-200"}`}
                    >
                      <Trophy
                        className={`w-6 h-6 mx-auto mb-1 ${stats.bestScore >= 1000 ? "text-yellow-600" : "text-gray-400"}`}
                      />
                      <p className="text-xs font-medium">High Scorer</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Aksi Cepat Player</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button className="h-20 text-left justify-start bg-transparent hover:bg-gray-50" variant="outline" asChild>
              <Link href="/join">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-semibold">Join Game</p>
                    <p className="text-sm text-gray-600">Masukkan kode untuk bergabung</p>
                  </div>
                </div>
              </Link>
            </Button>

            <Button className="h-20 text-left justify-start bg-transparent hover:bg-gray-50" variant="outline" asChild>
              <Link href="/demo">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Play className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="font-semibold">Demo Game</p>
                    <p className="text-sm text-gray-600">Coba fitur demo interaktif</p>
                  </div>
                </div>
              </Link>
            </Button>

            <Button className="h-20 text-left justify-start bg-transparent hover:bg-gray-50" variant="outline" asChild>
              <Link href="/leaderboard">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-semibold">Leaderboard</p>
                    <p className="text-sm text-gray-600">Lihat ranking pemain</p>
                  </div>
                </div>
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
