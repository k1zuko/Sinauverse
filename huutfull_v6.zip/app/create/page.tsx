"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Header } from "@/components/layout/header"
import { LoadingSpinner } from "@/components/layout/loading-spinner"
import { Plus, Trash2, Save, Clock, Target, Zap, BookOpen, ArrowLeft, ArrowRight } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"

interface Question {
  id: string
  question_text: string
  question_type: "multiple_choice" | "true_false"
  time_limit: number
  points: number
  order_index: number
  answer_options: {
    id: string
    option_text: string
    is_correct: boolean
    option_index: number
  }[]
}

interface QuizForm {
  title: string
  description: string
  is_public: boolean // Added is_public
  game_mode: "classic" | "practice"
  total_time_limit: number
  allow_back_navigation: boolean
  show_correct_answer: boolean
  randomize_questions: boolean
  randomize_options: boolean
}

export default function CreateQuizPage() {
  const { user, profile, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [quizForm, setQuizForm] = useState<QuizForm>({
    title: "",
    description: "",
    is_public: true, // Default to public
    game_mode: "classic",
    total_time_limit: 300, // 5 minutes default for practice mode
    allow_back_navigation: false,
    show_correct_answer: true,
    randomize_questions: false,
    randomize_options: false,
  })

  const [questions, setQuestions] = useState<Question[]>([])
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
      return
    }

    if (!loading && user && profile?.role !== "host") {
      router.push("/dashboard/player")
      return
    }

    // Initialize with one empty question if no questions exist
    if (questions.length === 0) {
      addNewQuestion()
    }
  }, [user, profile, loading, router])

  const addNewQuestion = () => {
    const newQuestion: Question = {
      id: `temp-${Date.now()}`,
      question_text: "",
      question_type: "multiple_choice",
      time_limit: 20,
      points: 100,
      order_index: questions.length,
      answer_options: [
        { id: `temp-opt-${Date.now()}-0`, option_text: "", is_correct: false, option_index: 0 },
        { id: `temp-opt-${Date.now()}-1`, option_text: "", is_correct: false, option_index: 1 },
        { id: `temp-opt-${Date.now()}-2`, option_text: "", is_correct: false, option_index: 2 },
        { id: `temp-opt-${Date.now()}-3`, option_text: "", is_correct: false, option_index: 3 },
      ],
    }

    setQuestions([...questions, newQuestion])
    setCurrentQuestionIndex(questions.length)
  }

  const updateQuestion = (index: number, updates: Partial<Question>) => {
    const updatedQuestions = [...questions]
    updatedQuestions[index] = { ...updatedQuestions[index], ...updates }
    setQuestions(updatedQuestions)
  }

  const updateQuestionOption = (
    questionIndex: number,
    optionIndex: number,
    updates: Partial<Question["answer_options"][0]>,
  ) => {
    const updatedQuestions = [...questions]
    updatedQuestions[questionIndex].answer_options[optionIndex] = {
      ...updatedQuestions[questionIndex].answer_options[optionIndex],
      ...updates,
    }
    setQuestions(updatedQuestions)
  }

  const setCorrectAnswer = (questionIndex: number, optionIndex: number) => {
    const updatedQuestions = [...questions]
    updatedQuestions[questionIndex].answer_options.forEach((option, idx) => {
      option.is_correct = idx === optionIndex
    })
    setQuestions(updatedQuestions)
  }

  const deleteQuestion = (index: number) => {
    if (questions.length <= 1) {
      toast({
        title: "Error",
        description: "Quiz harus memiliki minimal 1 pertanyaan",
        variant: "destructive",
      })
      return
    }

    const updatedQuestions = questions.filter((_, i) => i !== index)
    setQuestions(updatedQuestions)

    if (currentQuestionIndex >= updatedQuestions.length) {
      setCurrentQuestionIndex(updatedQuestions.length - 1)
    }
  }

  const validateQuiz = (): string | null => {
    if (!quizForm.title.trim()) return "Judul quiz harus diisi"
    if (questions.length === 0) return "Quiz harus memiliki minimal 1 pertanyaan"

    for (let i = 0; i < questions.length; i++) {
      const question = questions[i]
      if (!question.question_text.trim()) return `Pertanyaan ${i + 1} harus diisi`

      const hasCorrectAnswer = question.answer_options.some((opt) => opt.is_correct)
      if (!hasCorrectAnswer) return `Pertanyaan ${i + 1} harus memiliki jawaban yang benar`

      const hasEmptyOption = question.answer_options.some((opt) => !opt.option_text.trim())
      if (hasEmptyOption) {
        // For true/false, options are pre-filled, so no need to check for empty options
        if (question.question_type === "multiple_choice") {
          return `Semua pilihan jawaban pada pertanyaan ${i + 1} harus diisi`
        }
      }
    }

    return null
  }

  const saveQuiz = async () => {
    const validationError = validateQuiz()
    if (validationError) {
      setError(validationError)
      return
    }

    setSaving(true)
    setError("")

    try {
      // Create quiz
      const { data: quizData, error: quizError } = await supabase
        .from("quizzes")
        .insert({
          title: quizForm.title,
          description: quizForm.description,
          creator_id: user!.id,
          is_public: quizForm.is_public, // Pass is_public
          game_mode: quizForm.game_mode,
          total_time_limit: quizForm.game_mode === "practice" ? quizForm.total_time_limit : null,
          allow_back_navigation: quizForm.allow_back_navigation,
          show_correct_answer: quizForm.show_correct_answer,
          randomize_questions: quizForm.randomize_questions,
          randomize_options: quizForm.randomize_options,
        })
        .select()
        .single()

      if (quizError) throw quizError

      // Create questions
      for (let i = 0; i < questions.length; i++) {
        const question = questions[i]

        const { data: questionData, error: questionError } = await supabase
          .from("questions")
          .insert({
            quiz_id: quizData.id,
            question_text: question.question_text,
            question_type: question.question_type,
            time_limit: question.time_limit,
            points: question.points,
            order_index: i,
          })
          .select()
          .single()

        if (questionError) throw questionError

        // Create answer options
        const optionsToInsert = question.answer_options.map((option, idx) => ({
          question_id: questionData.id,
          option_text: option.option_text,
          is_correct: option.is_correct,
          option_index: idx,
        }))

        const { error: optionsError } = await supabase.from("answer_options").insert(optionsToInsert)

        if (optionsError) throw optionsError
      }

      toast({
        title: "Quiz Berhasil Disimpan!",
        description: `Quiz "${quizForm.title}" telah dibuat dengan ${questions.length} pertanyaan.`,
      })

      router.push("/dashboard/host")
    } catch (error: any) {
      console.error("Error saving quiz:", error)
      setError(error.message || "Gagal menyimpan quiz")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <LoadingSpinner size="lg" text="Loading..." />
        </div>
      </div>
    )
  }

  if (!user || profile?.role !== "host") {
    return null
  }

  const currentQuestion = questions[currentQuestionIndex]

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Buat Quiz Baru</h1>
          <p className="text-gray-600">Buat quiz interaktif untuk dimainkan bersama</p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quiz Settings */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Pengaturan Quiz</CardTitle>
                <CardDescription>Konfigurasi dasar quiz Anda</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Judul Quiz</Label>
                  <Input
                    id="title"
                    placeholder="Masukkan judul quiz"
                    value={quizForm.title}
                    onChange={(e) => setQuizForm({ ...quizForm, title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Deskripsi</Label>
                  <Textarea
                    id="description"
                    placeholder="Deskripsi singkat tentang quiz"
                    value={quizForm.description}
                    onChange={(e) => setQuizForm({ ...quizForm, description: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="isPublic" className="text-sm">
                    Publikasikan Quiz
                  </Label>
                  <Switch
                    id="isPublic"
                    checked={quizForm.is_public}
                    onCheckedChange={(checked) => setQuizForm({ ...quizForm, is_public: checked })}
                  />
                </div>

                <div className="space-y-3">
                  <Label>Mode Permainan</Label>
                  <RadioGroup
                    value={quizForm.game_mode}
                    onValueChange={(value: "classic" | "practice") => setQuizForm({ ...quizForm, game_mode: value })}
                  >
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="classic" id="classic" />
                      <Label htmlFor="classic" className="flex-1 cursor-pointer">
                        <div className="flex items-center gap-2">
                          <Zap className="w-4 h-4 text-red-500" />
                          <div>
                            <div className="font-medium">Classic Mode</div>
                            <div className="text-xs text-gray-500">Real-time, timer per soal, seperti Kahoot</div>
                          </div>
                        </div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="practice" id="practice" />
                      <Label htmlFor="practice" className="flex-1 cursor-pointer">
                        <div className="flex items-center gap-2">
                          <Target className="w-4 h-4 text-blue-500" />
                          <div>
                            <div className="font-medium">Practice Mode</div>
                            <div className="text-xs text-gray-500">Self-paced, timer keseluruhan</div>
                          </div>
                        </div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {quizForm.game_mode === "practice" && (
                  <div className="space-y-2">
                    <Label htmlFor="totalTime">Total Waktu (detik)</Label>
                    <Input
                      id="totalTime"
                      type="number"
                      min="60"
                      max="3600"
                      value={quizForm.total_time_limit}
                      onChange={(e) =>
                        setQuizForm({ ...quizForm, total_time_limit: Number.parseInt(e.target.value) || 300 })
                      }
                    />
                    <p className="text-xs text-gray-500">
                      {Math.floor(quizForm.total_time_limit / 60)} menit {quizForm.total_time_limit % 60} detik
                    </p>
                  </div>
                )}

                <div className="space-y-4 pt-4 border-t">
                  <h4 className="font-medium">Opsi Tambahan</h4>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="showAnswer" className="text-sm">
                      Tampilkan jawaban benar
                    </Label>
                    <Switch
                      id="showAnswer"
                      checked={quizForm.show_correct_answer}
                      onCheckedChange={(checked) => setQuizForm({ ...quizForm, show_correct_answer: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="randomizeQuestions" className="text-sm">
                      Acak urutan soal
                    </Label>
                    <Switch
                      id="randomizeQuestions"
                      checked={quizForm.randomize_questions}
                      onCheckedChange={(checked) => setQuizForm({ ...quizForm, randomize_questions: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="randomizeOptions" className="text-sm">
                      Acak pilihan jawaban
                    </Label>
                    <Switch
                      id="randomizeOptions"
                      checked={quizForm.randomize_options}
                      onCheckedChange={(checked) => setQuizForm({ ...quizForm, randomize_options: checked })}
                    />
                  </div>

                  {quizForm.game_mode === "practice" && (
                    <div className="flex items-center justify-between">
                      <Label htmlFor="allowBack" className="text-sm">
                        Izinkan navigasi mundur
                      </Label>
                      <Switch
                        id="allowBack"
                        checked={quizForm.allow_back_navigation}
                        onCheckedChange={(checked) => setQuizForm({ ...quizForm, allow_back_navigation: checked })}
                      />
                    </div>
                  )}
                </div>

                <div className="pt-4 space-y-2">
                  <Button onClick={saveQuiz} disabled={saving} className="w-full">
                    {saving ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Menyimpan...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Simpan Quiz
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-gray-500 text-center">
                    {questions.length} pertanyaan • Mode {quizForm.game_mode}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Question Editor */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>
                      Pertanyaan {currentQuestionIndex + 1} dari {questions.length}
                    </CardTitle>
                    <CardDescription>Edit pertanyaan dan pilihan jawaban</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
                      disabled={currentQuestionIndex === 0}
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentQuestionIndex(Math.min(questions.length - 1, currentQuestionIndex + 1))}
                      disabled={currentQuestionIndex === questions.length - 1}
                    >
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {currentQuestion && (
                  <>
                    {/* Question Settings */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Tipe Soal</Label>
                        <Select
                          value={currentQuestion.question_type}
                          onValueChange={(value: "multiple_choice" | "true_false") => {
                            if (value === "true_false") {
                              updateQuestion(currentQuestionIndex, {
                                question_type: value,
                                answer_options: [
                                  {
                                    id: `temp-opt-${Date.now()}-0`,
                                    option_text: "Benar",
                                    is_correct: false,
                                    option_index: 0,
                                  },
                                  {
                                    id: `temp-opt-${Date.now()}-1`,
                                    option_text: "Salah",
                                    is_correct: false,
                                    option_index: 1,
                                  },
                                ],
                              })
                            } else {
                              updateQuestion(currentQuestionIndex, {
                                question_type: value,
                                answer_options: [
                                  {
                                    id: `temp-opt-${Date.now()}-0`,
                                    option_text: "",
                                    is_correct: false,
                                    option_index: 0,
                                  },
                                  {
                                    id: `temp-opt-${Date.now()}-1`,
                                    option_text: "",
                                    is_correct: false,
                                    option_index: 1,
                                  },
                                  {
                                    id: `temp-opt-${Date.now()}-2`,
                                    option_text: "",
                                    is_correct: false,
                                    option_index: 2,
                                  },
                                  {
                                    id: `temp-opt-${Date.now()}-3`,
                                    option_text: "",
                                    is_correct: false,
                                    option_index: 3,
                                  },
                                ],
                              })
                            }
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="multiple_choice">Pilihan Ganda</SelectItem>
                            <SelectItem value="true_false">Benar/Salah</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {quizForm.game_mode === "classic" && (
                        <div className="space-y-2">
                          <Label>Waktu (detik)</Label>
                          <Input
                            type="number"
                            min="5"
                            max="120"
                            value={currentQuestion.time_limit}
                            onChange={(e) =>
                              updateQuestion(currentQuestionIndex, {
                                time_limit: Number.parseInt(e.target.value) || 20,
                              })
                            }
                          />
                        </div>
                      )}

                      <div className="space-y-2">
                        <Label>Poin</Label>
                        <Input
                          type="number"
                          min="10"
                          max="1000"
                          step="10"
                          value={currentQuestion.points}
                          onChange={(e) =>
                            updateQuestion(currentQuestionIndex, { points: Number.parseInt(e.target.value) || 100 })
                          }
                        />
                      </div>
                    </div>

                    {/* Question Text */}
                    <div className="space-y-2">
                      <Label>Pertanyaan</Label>
                      <Textarea
                        placeholder="Tulis pertanyaan Anda di sini..."
                        value={currentQuestion.question_text}
                        onChange={(e) => updateQuestion(currentQuestionIndex, { question_text: e.target.value })}
                        rows={3}
                        className="text-lg"
                      />
                    </div>

                    {/* Answer Options */}
                    <div className="space-y-4">
                      <Label>Pilihan Jawaban</Label>
                      {currentQuestion.question_type === "multiple_choice" ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {currentQuestion.answer_options.map((option, optionIndex) => (
                            <div
                              key={option.id}
                              className={`p-4 border-2 rounded-lg transition-colors ${
                                option.is_correct
                                  ? "border-green-500 bg-green-50"
                                  : "border-gray-200 hover:border-gray-300"
                              }`}
                            >
                              <div className="flex items-center gap-3 mb-2">
                                <div
                                  className={`w-6 h-6 rounded-full flex items-center justify-center text-white font-bold ${
                                    ["bg-red-500", "bg-blue-500", "bg-yellow-500", "bg-green-500"][optionIndex]
                                  }`}
                                >
                                  {String.fromCharCode(65 + optionIndex)}
                                </div>
                                <Button
                                  variant={option.is_correct ? "default" : "outline"}
                                  size="sm"
                                  onClick={() => setCorrectAnswer(currentQuestionIndex, optionIndex)}
                                >
                                  {option.is_correct ? "Jawaban Benar" : "Tandai Benar"}
                                </Button>
                              </div>
                              <Input
                                placeholder={`Pilihan ${String.fromCharCode(65 + optionIndex)}`}
                                value={option.option_text}
                                onChange={(e) =>
                                  updateQuestionOption(currentQuestionIndex, optionIndex, {
                                    option_text: e.target.value,
                                  })
                                }
                              />
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-4">
                          <div
                            className={`p-4 border-2 rounded-lg transition-colors cursor-pointer ${
                              currentQuestion.answer_options[0].is_correct
                                ? "border-green-500 bg-green-50"
                                : "border-gray-200 hover:border-gray-300"
                            }`}
                            onClick={() => setCorrectAnswer(currentQuestionIndex, 0)}
                          >
                            <div className="text-center">
                              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-xl mx-auto mb-2">
                                ✓
                              </div>
                              <p className="font-semibold">BENAR</p>
                              {currentQuestion.answer_options[0].is_correct && (
                                <p className="text-sm text-green-600 mt-1">Jawaban yang benar</p>
                              )}
                            </div>
                          </div>
                          <div
                            className={`p-4 border-2 rounded-lg transition-colors cursor-pointer ${
                              currentQuestion.answer_options[1].is_correct
                                ? "border-green-500 bg-green-50"
                                : "border-gray-200 hover:border-gray-300"
                            }`}
                            onClick={() => setCorrectAnswer(currentQuestionIndex, 1)}
                          >
                            <div className="text-center">
                              <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center text-white font-bold text-xl mx-auto mb-2">
                                ✗
                              </div>
                              <p className="font-semibold">SALAH</p>
                              {currentQuestion.answer_options[1].is_correct && (
                                <p className="text-sm text-green-600 mt-1">Jawaban yang benar</p>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Question Actions */}
                    <div className="flex items-center justify-between pt-4 border-t">
                      <Button
                        variant="outline"
                        onClick={() => deleteQuestion(currentQuestionIndex)}
                        disabled={questions.length <= 1}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Hapus Pertanyaan
                      </Button>

                      <Button onClick={addNewQuestion}>
                        <Plus className="w-4 h-4 mr-2" />
                        Tambah Pertanyaan
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Questions Overview */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  Ringkasan Pertanyaan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {questions.map((question, index) => (
                    <div
                      key={question.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        index === currentQuestionIndex
                          ? "border-blue-500 bg-blue-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setCurrentQuestionIndex(index)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-sm">Q{index + 1}</span>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          {quizForm.game_mode === "classic" && (
                            <>
                              <Clock className="w-3 h-3" />
                              {question.time_limit}s
                            </>
                          )}
                          <span>•</span>
                          {question.points}pt
                        </div>
                      </div>
                      <p className="text-sm text-gray-700 line-clamp-2">
                        {question.question_text || "Pertanyaan belum diisi..."}
                      </p>
                      <div className="mt-2 flex items-center gap-1">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            question.answer_options.some((opt) => opt.is_correct) ? "bg-green-500" : "bg-red-500"
                          }`}
                        />
                        <span className="text-xs text-gray-500">
                          {question.answer_options.some((opt) => opt.is_correct) ? "Siap" : "Perlu jawaban"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
