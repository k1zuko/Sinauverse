"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AvatarGenerator } from "@/components/ui/avatar-generator"
import { UserPlus, Mail, Lock, User, Crown, Users, Shuffle } from "lucide-react"
import Link from "next/link"
import { supabase } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"

export default function RegisterPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: "",
    username: "",
    role: "player" as "host" | "player",
  })
  const [avatarSeed, setAvatarSeed] = useState(() => Math.random().toString(36).substring(7))
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const generateNewAvatar = () => {
    setAvatarSeed(Math.random().toString(36).substring(7))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError("Password tidak cocok")
      setLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError("Password minimal 6 karakter")
      setLoading(false)
      return
    }

    if (!formData.fullName.trim()) {
      setError("Nama lengkap harus diisi")
      setLoading(false)
      return
    }

    if (!formData.username.trim()) {
      setError("Username harus diisi")
      setLoading(false)
      return
    }

    try {
      // Check if username already exists
      const { data: existingUser } = await supabase
        .from("profiles")
        .select("username")
        .eq("username", formData.username.toLowerCase())
        .single()

      if (existingUser) {
        setError("Username sudah digunakan")
        setLoading(false)
        return
      }

      // Sign up user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName,
            username: formData.username.toLowerCase(),
            role: formData.role,
            avatar_seed: avatarSeed,
          },
        },
      })

      if (authError) {
        setError(authError.message)
        setLoading(false)
        return
      }

      if (authData.user) {
        toast({
          title: "Registrasi Berhasil!",
          description: "Silakan cek email Anda untuk verifikasi akun.",
        })

        // Redirect based on role
        if (formData.role === "host") {
          router.push("/dashboard/host")
        } else {
          router.push("/dashboard/player")
        }
      }
    } catch (error: any) {
      setError(error.message || "Terjadi kesalahan saat registrasi")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-500 to-pink-400 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-2xl">
        <CardHeader className="space-y-1 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <UserPlus className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold">Daftar Akun Baru</CardTitle>
          <CardDescription>Bergabung dengan Sinauverse dan mulai petualangan quiz Anda!</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Avatar Selection */}
            <div className="space-y-2">
              <Label>Avatar Anda</Label>
              <div className="flex items-center gap-4 p-4 border rounded-lg bg-gray-50">
                <AvatarGenerator seed={avatarSeed} size={64} />
                <div className="flex-1">
                  <p className="text-sm font-medium">Avatar Unik Anda</p>
                  <p className="text-xs text-gray-600">Avatar ini akan mewakili Anda dalam game</p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={generateNewAvatar}
                    className="mt-2 bg-transparent"
                  >
                    <Shuffle className="w-3 h-3 mr-1" />
                    Ganti Avatar
                  </Button>
                </div>
              </div>
            </div>

            {/* Role Selection */}
            <div className="space-y-3">
              <Label>Pilih Peran Anda</Label>
              <RadioGroup
                value={formData.role}
                onValueChange={(value: "host" | "player") => setFormData({ ...formData, role: value })}
                className="grid grid-cols-2 gap-4"
              >
                <div>
                  <RadioGroupItem value="player" id="player" className="peer sr-only" />
                  <Label
                    htmlFor="player"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                  >
                    <Users className="mb-3 h-6 w-6" />
                    <div className="text-center">
                      <div className="font-semibold">Player</div>
                      <div className="text-xs text-muted-foreground">Ikut quiz dan bermain</div>
                    </div>
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="host" id="host" className="peer sr-only" />
                  <Label
                    htmlFor="host"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                  >
                    <Crown className="mb-3 h-6 w-6" />
                    <div className="text-center">
                      <div className="font-semibold">Host</div>
                      <div className="text-xs text-muted-foreground">Buat dan kelola quiz</div>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Personal Information */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Nama Lengkap</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="Nama lengkap"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value.toLowerCase() })}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Account Information */}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="nama@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Minimal 6 karakter"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Konfirmasi Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Ulangi password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              disabled={loading}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Mendaftar...
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Daftar Sekarang
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Sudah punya akun?{" "}
              <Link href="/auth/login" className="text-purple-600 hover:underline font-medium">
                Masuk di sini
              </Link>
            </p>
          </div>

          {/* Role Information */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">Perbedaan Peran:</h4>
            <div className="space-y-2 text-sm text-blue-800">
              <div className="flex items-start gap-2">
                <Crown className="w-4 h-4 mt-0.5 text-blue-600" />
                <div>
                  <strong>Host:</strong> Dapat membuat quiz, mengelola game, melihat statistik real-time, dan mengontrol
                  jalannya permainan.
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Users className="w-4 h-4 mt-0.5 text-blue-600" />
                <div>
                  <strong>Player:</strong> Dapat bergabung ke game, bermain quiz, melihat progress pribadi, dan
                  berkompetisi dengan pemain lain.
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
