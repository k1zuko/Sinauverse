export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string | null
          full_name: string | null
          avatar_seed: string | null
          role: "host" | "player"
          total_games_played: number
          total_score: number
          best_score: number
          created_quizzes: number
          hosted_games: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username?: string | null
          full_name?: string | null
          avatar_seed?: string | null
          role?: "host" | "player"
          total_games_played?: number
          total_score?: number
          best_score?: number
          created_quizzes?: number
          hosted_games?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string | null
          full_name?: string | null
          avatar_seed?: string | null
          role?: "host" | "player"
          total_games_played?: number
          total_score?: number
          best_score?: number
          created_quizzes?: number
          hosted_games?: number
          created_at?: string
          updated_at?: string
        }
      }
      quizzes: {
        Row: {
          id: string
          title: string
          description: string | null
          creator_id: string
          is_public: boolean // Added is_public
          game_mode: "classic" | "practice"
          total_time_limit: number | null
          allow_back_navigation: boolean
          show_correct_answer: boolean
          randomize_questions: boolean
          randomize_options: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          creator_id: string
          is_public?: boolean // Added is_public
          game_mode?: "classic" | "practice"
          total_time_limit?: number | null
          allow_back_navigation?: boolean
          show_correct_answer?: boolean
          randomize_questions?: boolean
          randomize_options?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          creator_id?: string
          is_public?: boolean // Added is_public
          game_mode?: "classic" | "practice"
          total_time_limit?: number | null
          allow_back_navigation?: boolean
          show_correct_answer?: boolean
          randomize_questions?: boolean
          randomize_options?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      questions: {
        Row: {
          id: string
          quiz_id: string
          question_text: string
          question_type: "multiple_choice" | "true_false"
          time_limit: number
          points: number
          order_index: number
          created_at: string
        }
        Insert: {
          id?: string
          quiz_id: string
          question_text: string
          question_type?: "multiple_choice" | "true_false"
          time_limit?: number
          points?: number
          order_index: number
          created_at?: string
        }
        Update: {
          id?: string
          quiz_id?: string
          question_text?: string
          question_type?: "multiple_choice" | "true_false"
          time_limit?: number
          points?: number
          order_index?: number
          created_at?: string
        }
      }
      answer_options: {
        Row: {
          id: string
          question_id: string
          option_text: string
          is_correct: boolean
          option_index: number
          created_at: string
        }
        Insert: {
          id?: string
          question_id: string
          option_text: string
          is_correct?: boolean
          option_index: number
          created_at?: string
        }
        Update: {
          id?: string
          question_id?: string
          option_text?: string
          is_correct?: boolean
          option_index?: number
          created_at?: string
        }
      }
      game_rooms: {
        Row: {
          id: string
          room_code: string
          host_id: string
          quiz_id: string
          status: "waiting" | "active" | "finished"
          game_mode: "classic" | "practice"
          max_participants: number
          allow_late_join: boolean
          show_leaderboard: boolean
          auto_advance: boolean
          current_question: number
          started_at: string | null
          finished_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          room_code: string
          host_id: string
          quiz_id: string
          status?: "waiting" | "active" | "finished"
          game_mode?: "classic" | "practice"
          max_participants?: number
          allow_late_join?: boolean
          show_leaderboard?: boolean
          auto_advance?: boolean
          current_question?: number
          started_at?: string | null
          finished_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          room_code?: string
          host_id?: string
          quiz_id?: string
          status?: "waiting" | "active" | "finished"
          game_mode?: "classic" | "practice"
          max_participants?: number
          allow_late_join?: boolean
          show_leaderboard?: boolean
          auto_advance?: boolean
          current_question?: number
          started_at?: string | null
          finished_at?: string | null
          created_at?: string
        }
      }
      game_participants: {
        Row: {
          id: string
          room_id: string
          user_id: string | null
          nickname: string
          avatar_seed: string
          score: number
          current_question: number
          time_spent: number
          correct_answers: number
          wrong_answers: number
          fastest_answer_time: number
          position: number
          joined_at: string
        }
        Insert: {
          id?: string
          room_id: string
          user_id?: string | null
          nickname: string
          avatar_seed?: string
          score?: number
          current_question?: number
          time_spent?: number
          correct_answers?: number
          wrong_answers?: number
          fastest_answer_time?: number
          position?: number
          joined_at?: string
        }
        Update: {
          id?: string
          room_id?: string
          user_id?: string | null
          nickname?: string
          avatar_seed?: string
          score?: number
          current_question?: number
          time_spent?: number
          correct_answers?: number
          wrong_answers?: number
          fastest_answer_time?: number
          position?: number
          joined_at?: string
        }
      }
      game_answers: {
        Row: {
          id: string
          room_id: string
          participant_id: string
          question_id: string
          selected_option_id: string | null
          is_correct: boolean
          points_earned: number
          answer_time: number
          created_at: string
        }
        Insert: {
          id?: string
          room_id: string
          participant_id: string
          question_id: string
          selected_option_id?: string | null
          is_correct?: boolean
          points_earned?: number
          answer_time?: number
          created_at?: string
        }
        Update: {
          id?: string
          room_id?: string
          participant_id?: string
          question_id?: string
          selected_option_id?: string | null
          is_correct?: boolean
          points_earned?: number
          answer_time?: number
          created_at?: string
        }
      }
      game_statistics: {
        Row: {
          id: string
          room_id: string
          participant_id: string
          question_id: string
          question_order: number
          answer_time: number
          is_correct: boolean
          points_earned: number
          selected_option_index: number | null
          created_at: string
        }
        Insert: {
          id?: string
          room_id: string
          participant_id: string
          question_id: string
          question_order: number
          answer_time: number
          is_correct: boolean
          points_earned?: number
          selected_option_index?: number | null
          created_at?: string
        }
        Update: {
          id?: string
          room_id?: string
          participant_id?: string
          question_id?: string
          question_order?: number
          answer_time?: number
          is_correct?: boolean
          points_earned?: number
          selected_option_index?: number | null
          created_at?: string
        }
      }
      user_achievements: {
        Row: {
          id: string
          user_id: string
          achievement_type: string
          achievement_data: Json
          earned_at: string
        }
        Insert: {
          id?: string
          user_id: string
          achievement_type: string
          achievement_data?: Json
          earned_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          achievement_type?: string
          achievement_data?: Json
          earned_at?: string
        }
      }
      quiz_analytics: {
        Row: {
          id: string
          quiz_id: string
          total_plays: number
          total_participants: number
          average_score: number
          average_completion_time: number
          most_difficult_question_id: string | null
          easiest_question_id: string | null
          last_played_at: string | null
          updated_at: string
        }
        Insert: {
          id?: string
          quiz_id: string
          total_plays?: number
          total_participants?: number
          average_score?: number
          average_completion_time?: number
          most_difficult_question_id?: string | null
          easiest_question_id?: string | null
          last_played_at?: string | null
          updated_at?: string
        }
        Update: {
          id?: string
          quiz_id?: string
          total_plays?: number
          total_participants?: number
          average_score?: number
          average_completion_time?: number
          most_difficult_question_id?: string | null
          easiest_question_id?: string | null
          last_played_at?: string | null
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      game_mode: "classic" | "practice"
      user_role: "host" | "player"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
