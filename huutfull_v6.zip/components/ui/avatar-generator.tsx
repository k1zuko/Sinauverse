"use client"

import { useMemo } from "react"
import { cn } from "@/lib/utils"

interface AvatarGeneratorProps {
  seed: string
  size?: number
  className?: string
  style?:
    | "fun-emoji"
    | "avataaars"
    | "big-smile"
    | "bottts"
    | "identicon"
    | "initials"
    | "lorelei"
    | "micah"
    | "miniavs"
    | "open-peeps"
    | "personas"
    | "pixel-art"
}

export function AvatarGenerator({ seed, size = 40, className, style = "fun-emoji" }: AvatarGeneratorProps) {
  const avatarUrl = useMemo(() => {
    if (!seed) return ""

    // Use DiceBear API for generating avatars
    const baseUrl = "https://api.dicebear.com/7.x"
    return `${baseUrl}/${style}/svg?seed=${encodeURIComponent(seed)}&size=${size}&backgroundColor=transparent`
  }, [seed, size, style])

  if (!seed) {
    return (
      <div
        className={cn("rounded-full bg-gray-200 flex items-center justify-center text-gray-500", className)}
        style={{ width: size, height: size }}
      >
        <span className="text-xs">?</span>
      </div>
    )
  }

  return (
    <div className={cn("rounded-full overflow-hidden bg-gray-100", className)} style={{ width: size, height: size }}>
      <img
        src={avatarUrl || "/placeholder.svg"}
        alt={`Avatar for ${seed}`}
        width={size}
        height={size}
        className="w-full h-full object-cover"
        onError={(e) => {
          // Fallback to initials style if the primary style fails
          const target = e.target as HTMLImageElement
          target.src = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(seed)}&size=${size}&backgroundColor=6366f1&color=ffffff`
        }}
      />
    </div>
  )
}
