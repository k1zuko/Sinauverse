import { cn } from "@/lib/utils"

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg"
  text?: string
  className?: string
}

export function LoadingSpinner({ size = "md", text, className }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-8 h-8",
    lg: "w-12 h-12",
  }

  return (
    <div className={cn("flex flex-col items-center justify-center gap-3", className)}>
      <div className={cn("border-4 border-gray-200 border-t-blue-600 rounded-full animate-spin", sizeClasses[size])} />
      {text && <p className="text-gray-600 text-sm font-medium">{text}</p>}
    </div>
  )
}
