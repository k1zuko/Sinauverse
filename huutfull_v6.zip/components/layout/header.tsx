"use client"

import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { AvatarGenerator } from "@/components/ui/avatar-generator"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Play, User, LogOut, Settings, Crown, Users } from "lucide-react"
import Link from "next/link"

export function Header() {
  const { user, profile, signOut } = useAuth()
  const router = useRouter()

  const handleSignOut = async () => {
    await signOut()
    router.push("/")
  }

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
              <Play className="w-5 h-5 text-white fill-current" />
            </div>
            <span className="text-xl font-bold text-gray-900">Sinauverse</span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {user && profile ? (
              <>
                <Link href="/dashboard" className="text-gray-600 hover:text-gray-900 font-medium">
                  Dashboard
                </Link>
                {profile.role === "host" && (
                  <Link href="/create" className="text-gray-600 hover:text-gray-900 font-medium">
                    Buat Kuis
                  </Link>
                )}
                <Link href="/join" className="text-gray-600 hover:text-gray-900 font-medium">
                  Join Game
                </Link>
              </>
            ) : (
              <>
                <Link href="/demo" className="text-gray-600 hover:text-gray-900 font-medium">
                  Demo
                </Link>
                <Link href="/join" className="text-gray-600 hover:text-gray-900 font-medium">
                  Join Game
                </Link>
              </>
            )}
          </nav>

          {/* User Menu */}
          <div className="flex items-center gap-4">
            {user && profile ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2 h-auto p-2">
                    <AvatarGenerator seed={profile.avatar_seed || ""} size={32} />
                    <div className="hidden sm:block text-left">
                      <p className="text-sm font-medium">{profile.full_name || profile.username}</p>
                      <p className="text-xs text-gray-500 flex items-center gap-1">
                        {profile.role === "host" ? (
                          <>
                            <Crown className="w-3 h-3" />
                            Host
                          </>
                        ) : (
                          <>
                            <Users className="w-3 h-3" />
                            Player
                          </>
                        )}
                      </p>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard" className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      Pengaturan Profil
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-red-600 focus:text-red-600">
                    <LogOut className="w-4 h-4 mr-2" />
                    Keluar
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-3">
                <Button variant="ghost" asChild>
                  <Link href="/auth/login">Masuk</Link>
                </Button>
                <Button asChild>
                  <Link href="/auth/register">Daftar</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
